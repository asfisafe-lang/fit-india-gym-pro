import { useEffect, useRef, useState } from 'react';
import { Icon } from './ui';
import type { IconName } from '../lib/icons';

export function PhotoCapture({
  onCapture,
}: {
  onCapture: (dataUrl: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [streaming, setStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const startCamera = async () => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: 480, height: 480 },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
      setStreaming(true);
    } catch (e: any) {
      setError(
        e?.name === 'NotAllowedError'
          ? 'Camera permission denied. Please allow camera access.'
          : 'Could not access camera. Check device permissions.'
      );
    }
  };

  const openModal = () => {
    setOpen(true);
    setStreaming(false);
    setError(null);
  };

  const stop = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setStreaming(false);
  };

  const closeModal = () => {
    stop();
    setOpen(false);
  };

  const capture = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const size = Math.min(video.videoWidth, video.videoHeight) || 480;
    const canvas = document.createElement('canvas');
    canvas.width = 320;
    canvas.height = 320;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const sx = (video.videoWidth - size) / 2;
    const sy = (video.videoHeight - size) / 2;
    ctx.drawImage(video, sx, sy, size, size, 0, 0, 320, 320);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    onCapture(dataUrl);
    closeModal();
  };

  // Start camera after modal is rendered
  useEffect(() => {
    if (!open) return;
    const timer = setTimeout(() => {
      startCamera();
    }, 100);
    return () => {
      clearTimeout(timer);
      stop();
    };
  }, [open]);

  // Cleanup on unmount
  useEffect(() => {
    return () => stop();
  }, []);

  return (
    <>
      <button
        type="button"
        onClick={openModal}
        className="flex h-full w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-ink-600 bg-ink-900/40 p-4 text-center transition hover:border-gold-400 hover:bg-ink-800/40"
      >
        <div className="rounded-full bg-gold-500/10 p-3 text-gold-300">
          <Icon name="Camera" className="h-6 w-6" />
        </div>
        <p className="text-xs font-semibold text-neutral-300">Click Photo</p>
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-ink-950/85 backdrop-blur-sm"
            onClick={closeModal}
          />
          <div className="relative z-10 w-full max-w-sm animate-fade-in-up card overflow-hidden">
            <div className="flex items-center justify-between border-b border-ink-700 px-5 py-3">
              <h3 className="font-display text-sm font-semibold gold-text">
                Capture Photo
              </h3>
              <button
                onClick={closeModal}
                className="rounded-lg p-1.5 text-neutral-400 hover:bg-ink-700"
              >
                <Icon name="X" className="h-5 w-5" />
              </button>
            </div>
            <div className="p-4">
              {error ? (
                <div className="flex flex-col items-center gap-3 py-8 text-center">
                  <Icon name="AlertCircle" className="h-10 w-10 text-rose-400" />
                  <p className="text-sm text-neutral-300">{error}</p>
                  <button
                    type="button"
                    onClick={startCamera}
                    className="btn-outline"
                  >
                    <Icon name="RefreshCw" className="h-4 w-4" />
                    Retry
                  </button>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-3">
                  <div className="overflow-hidden rounded-xl border-2 border-gold-400/40 bg-ink-950">
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="h-64 w-64 object-cover"
                    />
                  </div>
                  {streaming ? (
                    <button type="button" onClick={capture} className="btn-gold">
                      <Icon name="Camera" className="h-4 w-4" />
                      Capture
                    </button>
                  ) : (
                    <div className="flex items-center gap-2 text-xs text-neutral-500">
                      <div className="h-4 w-4 animate-spin rounded-full border-2 border-gold-400/30 border-t-gold-400" />
                      Starting camera…
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export function PhotoUpload({
  photo,
  onCapture,
  icon = 'Camera',
  label = 'Click Photo',
}: {
  photo: string | null;
  onCapture: (dataUrl: string) => void;
  icon?: IconName;
  label?: string;
}) {
  const [mode, setMode] = useState<'camera' | 'upload'>('camera');
  const fileRef = useRef<HTMLInputElement>(null);

  return (
    <div className="space-y-2">
      {photo ? (
        <div className="group relative">
          <img
            src={photo}
            alt="member"
            className="h-40 w-full rounded-xl object-cover ring-2 ring-gold-400/40"
          />
          <button
            type="button"
            onClick={() => onCapture('')}
            className="absolute right-2 top-2 rounded-lg bg-ink-950/80 p-1.5 text-rose-300 hover:bg-ink-950"
          >
            <Icon name="Trash2" className="h-4 w-4" />
          </button>
        </div>
      ) : (
        <div className="h-40 w-full">
          {mode === 'camera' ? (
            <PhotoCapture onCapture={onCapture} />
          ) : (
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="flex h-full w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-ink-600 bg-ink-900/40 p-4 text-center transition hover:border-gold-400"
            >
              <div className="rounded-full bg-gold-500/10 p-3 text-gold-300">
                <Icon name={icon} className="h-6 w-6" />
              </div>
              <p className="text-xs font-semibold text-neutral-300">{label}</p>
            </button>
          )}
        </div>
      )}
      {!photo && (
        <div className="flex rounded-lg border border-ink-700 p-0.5">
          <button
            type="button"
            onClick={() => setMode('camera')}
            className={`flex-1 rounded-md px-3 py-1.5 text-xs font-semibold transition ${
              mode === 'camera'
                ? 'bg-gold-500/20 text-gold-200'
                : 'text-neutral-500 hover:text-neutral-300'
            }`}
          >
            <Icon name="Camera" className="mr-1 inline h-3.5 w-3.5" />
            Camera
          </button>
          <button
            type="button"
            onClick={() => setMode('upload')}
            className={`flex-1 rounded-md px-3 py-1.5 text-xs font-semibold transition ${
              mode === 'upload'
                ? 'bg-gold-500/20 text-gold-200'
                : 'text-neutral-500 hover:text-neutral-300'
            }`}
          >
            <Icon name="ImageIcon" className="mr-1 inline h-3.5 w-3.5" />
            Upload
          </button>
        </div>
      )}
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (!file) return;
          if (file.size > 2 * 1024 * 1024) {
            alert('Image too large. Please pick an image under 2MB.');
            return;
          }
          const reader = new FileReader();
          reader.onload = () => onCapture(reader.result as string);
          reader.readAsDataURL(file);
        }}
      />
    </div>
  );
}
