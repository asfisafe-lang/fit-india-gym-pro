import { useEffect, useState } from 'react';
import { NAV, ROLES, GYM, type Role } from '../lib/constants';
import { Icon } from './ui';
import { iconMap, type IconName } from '../lib/icons';

const ROLE_STORE_KEY = 'fig_current_role';

export function useHashRoute() {
  const [hash, setHash] = useState(
    () => window.location.hash.slice(1) || 'dashboard'
  );
  useEffect(() => {
    const onChange = () => setHash(window.location.hash.slice(1) || 'dashboard');
    window.addEventListener('hashchange', onChange);
    return () => window.removeEventListener('hashchange', onChange);
  }, []);
  const path = hash.split('?')[0];
  const query = hash.split('?')[1] ?? '';
  const navigate = (id: string) => {
    window.location.hash = id;
    setHash(id);
    window.scrollTo({ top: 0 });
  };
  return { route: path, fullRoute: hash, query, navigate };
}

export function AppShell({
  children,
  current,
  onNavigate,
  role,
  onRoleChange,
}: {
  children: React.ReactNode;
  current: string;
  onNavigate: (p: string) => void;
  role: Role;
  onRoleChange: (r: Role) => void;
}) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const switchRole = (r: Role) => {
    onRoleChange(r);
    localStorage.setItem(ROLE_STORE_KEY, r);
  };

  return (
    <div className="min-h-screen lg:flex">
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-ink-950/70 backdrop-blur-sm lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-72 flex-col border-r border-ink-700 bg-ink-900/95 backdrop-blur-md transition-transform duration-300 lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center gap-3 border-b border-ink-700 px-5 py-5">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-gold-300 to-gold-500 text-ink-950 shadow-gold-glow">
            <Icon name="Dumbbell" className="h-6 w-6" />
          </div>
          <div className="min-w-0">
            <h1 className="font-display text-base font-bold leading-tight gold-text">
              {GYM.name}
            </h1>
            <p className="truncate text-[11px] font-medium tracking-wide text-neutral-500">
              {GYM.tagline}
            </p>
          </div>
          <button
            className="ml-auto rounded-lg p-1.5 text-neutral-400 hover:bg-ink-700 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          >
            <Icon name="X" className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4">
          {NAV.map((group) => (
            <div key={group.group} className="mb-5">
              <p className="mb-2 px-3 text-[10px] font-bold uppercase tracking-widest text-neutral-600">
                {group.group}
              </p>
              <div className="space-y-1">
                {group.items.map((item) => {
                  const active = current === item.id;
                  const Ic = iconMap[item.icon as IconName];
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onNavigate(item.id);
                        setSidebarOpen(false);
                      }}
                      className={`group flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all ${
                        active
                          ? 'bg-gradient-to-r from-gold-500/20 to-transparent text-gold-200 ring-1 ring-gold-500/30'
                          : 'text-neutral-400 hover:bg-ink-800 hover:text-neutral-200'
                      }`}
                    >
                      {Ic && <Ic className="h-[18px] w-[18px]" />}
                      {item.label}
                      {active && (
                        <Icon
                          name="ChevronRight"
                          className="ml-auto h-4 w-4 text-gold-400"
                        />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        <div className="border-t border-ink-700 p-3">
          <p className="mb-2 px-1 text-[10px] font-bold uppercase tracking-widest text-neutral-600">
            Active Role
          </p>
          <div className="relative">
            <select
              value={role}
              onChange={(e) => switchRole(e.target.value as Role)}
              className="input cursor-pointer appearance-none pr-8 text-sm font-semibold"
            >
              {ROLES.map((r) => (
                <option key={r.name} value={r.name}>
                  {r.name}
                  {r.count ? ` (${r.count})` : ''}
                </option>
              ))}
            </select>
            <Icon
              name="ChevronRight"
              className="pointer-events-none absolute right-2.5 top-1/2 h-4 w-4 -translate-y-1/2 rotate-90 text-neutral-500"
            />
          </div>
          <div className="mt-3 flex items-center gap-2 rounded-lg bg-ink-800/60 px-3 py-2">
            <Icon name={getRoleIcon(role)} className="h-4 w-4 text-gold-300" />
            <div className="min-w-0 text-[11px]">
              <p className="truncate font-semibold text-neutral-300">{role}</p>
              <p className="text-neutral-500">Signed in locally</p>
            </div>
          </div>
        </div>
      </aside>

      <div className="flex min-h-screen flex-1 flex-col lg:pl-72">
        <header className="sticky top-0 z-20 border-b border-ink-700 bg-ink-950/80 backdrop-blur-md">
          <div className="flex items-center gap-3 px-4 py-3 sm:px-6">
            <button
              className="rounded-lg p-2 text-neutral-400 hover:bg-ink-800 hover:text-gold-200 lg:hidden"
              onClick={() => setSidebarOpen(true)}
            >
              <Icon name="Menu" className="h-5 w-5" />
            </button>
            <div className="min-w-0 flex-1">
              <h2 className="font-display text-lg font-semibold capitalize text-neutral-100">
                {pageTitle(current)}
              </h2>
              <p className="hidden text-xs text-neutral-500 sm:block">
                {GYM.name} · {GYM.tagline}
              </p>
            </div>
            <div className="hidden items-center gap-2 rounded-lg border border-ink-700 bg-ink-850 px-3 py-1.5 text-xs text-neutral-400 md:flex">
              <Icon name="Clock" className="h-3.5 w-3.5 text-gold-300" />
              <span className="font-medium text-neutral-300">
                {GYM.gymTiming}
              </span>
            </div>
            <div
              className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-gold-300 to-gold-500 text-sm font-bold text-ink-950"
              title={role}
            >
              {role[0]}
            </div>
          </div>
        </header>

        <main className="flex-1 px-4 py-5 sm:px-6 sm:py-6">{children}</main>

        <footer className="border-t border-ink-700 px-4 py-4 sm:px-6">
          <div className="flex flex-col items-center justify-between gap-2 text-xs text-neutral-500 sm:flex-row">
            <p>
              © {new Date().getFullYear()} {GYM.name} · Owner: {GYM.team} ·
              Managed By: {GYM.managedBy}
            </p>
            <p className="flex items-center gap-1.5">
              <Icon name="MapPin" className="h-3.5 w-3.5 text-gold-400" />
              {GYM.address}
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}

function getRoleIcon(role: Role): IconName {
  switch (role) {
    case 'Super Admin':
      return 'Crown';
    case 'Admin':
      return 'Shield';
    case 'Male Trainer':
    case 'Female Trainer':
      return 'Dumbbell';
    default:
      return 'User';
  }
}

function pageTitle(route: string): string {
  const map: Record<string, string> = {
    dashboard: 'Dashboard',
    reports: 'Reports',
    admission: 'New Admission',
    members: 'All Members',
    'members-active': 'Active Members',
    'members-expired': 'Expired Members',
    'members-expiring': 'Expiring Soon',
    'members-due': 'Due Payment Members',
    'member-profile': 'Member Profile',
    attendance: 'Attendance Tracking',
    payments: 'Payments & Receipts',
    inquiries: 'Inquiry Management',
    trainers: 'Trainer Management',
    settings: 'Settings',
    backup: 'Backup & Export',
  };
  return map[route] ?? 'Fit India Gym';
}
