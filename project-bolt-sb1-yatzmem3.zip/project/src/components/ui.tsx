import { type ReactNode, useEffect } from 'react';
import { iconMap, type IconName } from '../lib/icons';

export function Icon({
  name,
  className = 'w-5 h-5',
}: {
  name: IconName;
  className?: string;
}) {
  const C = iconMap[name];
  if (!C) return null;
  return <C className={className} />;
}

export function Button({
  variant = 'gold',
  children,
  className = '',
  ...rest
}: {
  variant?: 'gold' | 'outline' | 'ghost' | 'danger';
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const variants: Record<string, string> = {
    gold: 'btn-gold',
    outline: 'btn-outline',
    ghost: 'btn-ghost',
    danger: 'btn-danger',
  };
  return (
    <button className={`${variants[variant]} ${className}`} {...rest}>
      {children}
    </button>
  );
}

export function Spinner({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <div
      className={`${className} h-5 w-5 animate-spin rounded-full border-2 border-gold-400/30 border-t-gold-400`}
    />
  );
}

export function Loading({ label = 'Loading…' }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-20 text-neutral-400">
      <Spinner className="h-8 w-8" />
      <p className="text-sm">{label}</p>
    </div>
  );
}

export function EmptyState({
  icon = 'Search',
  title,
  description,
  action,
}: {
  icon?: IconName;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
      <div className="rounded-2xl bg-ink-800/60 p-4 text-gold-300">
        <Icon name={icon} className="h-8 w-8" />
      </div>
      <h3 className="text-base font-semibold text-neutral-200">{title}</h3>
      {description && (
        <p className="max-w-sm text-sm text-neutral-500">{description}</p>
      )}
      {action}
    </div>
  );
}

export function Modal({
  open,
  onClose,
  title,
  children,
  size = 'md',
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [open, onClose]);

  if (!open) return null;
  const sizes = {
    sm: 'max-w-md',
    md: 'max-w-lg',
    lg: 'max-w-2xl',
    xl: 'max-w-4xl',
  };
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto p-4 sm:p-6">
      <div
        className="fixed inset-0 animate-fade-in-up bg-ink-950/80 backdrop-blur-sm"
        onClick={onClose}
      />
      <div
        className={`relative z-10 my-8 w-full animate-fade-in-up card ${sizes[size]}`}
      >
        <div className="flex items-center justify-between border-b border-ink-700 px-5 py-4">
          <h3 className="font-display text-lg font-semibold gold-text">
            {title}
          </h3>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-neutral-400 hover:bg-ink-700 hover:text-gold-200"
          >
            <Icon name="X" className="h-5 w-5" />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

export function Card({
  children,
  className = '',
}: {
  children: ReactNode;
  className?: string;
}) {
  return <div className={`card ${className}`}>{children}</div>;
}

export function StatCard({
  icon,
  label,
  value,
  sub,
  accent = 'gold',
}: {
  icon: IconName;
  label: string;
  value: string | number;
  sub?: string;
  accent?: 'gold' | 'emerald' | 'sky' | 'rose' | 'amber';
}) {
  const accents: Record<string, string> = {
    gold: 'text-gold-300 bg-gold-500/10',
    emerald: 'text-emerald-300 bg-emerald-500/10',
    sky: 'text-sky-300 bg-sky-500/10',
    rose: 'text-rose-300 bg-rose-500/10',
    amber: 'text-amber-300 bg-amber-500/10',
  };
  return (
    <Card className="card-hover animate-fade-in-up p-5">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-neutral-500">
            {label}
          </p>
          <p className="mt-2 font-display text-2xl font-bold text-neutral-100">
            {value}
          </p>
          {sub && <p className="mt-1 text-xs text-neutral-500">{sub}</p>}
        </div>
        <div className={`rounded-xl p-2.5 ${accents[accent]}`}>
          <Icon name={icon} className="h-5 w-5" />
        </div>
      </div>
    </Card>
  );
}

export function Badge({
  children,
  className = '',
}: {
  children: ReactNode;
  className?: string;
}) {
  return <span className={`badge ${className}`}>{children}</span>;
}

export function Avatar({
  photo,
  name,
  size = 'md',
}: {
  photo?: string | null;
  name: string;
  size?: 'sm' | 'md' | 'lg';
}) {
  const sizes = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-16 h-16 text-lg',
  };
  if (photo) {
    return (
      <img
        src={photo}
        alt={name}
        className={`${sizes[size]} rounded-full object-cover ring-2 ring-gold-400/30`}
      />
    );
  }
  return (
    <div
      className={`${sizes[size]} flex items-center justify-center rounded-full bg-gradient-to-br from-ink-700 to-ink-800 font-semibold text-gold-200 ring-2 ring-gold-400/30`}
    >
      {name
        .split(' ')
        .slice(0, 2)
        .map((w) => w[0]?.toUpperCase() ?? '')
        .join('')}
    </div>
  );
}
