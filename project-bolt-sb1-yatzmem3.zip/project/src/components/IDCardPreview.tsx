import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { GYM } from '../lib/constants';
import { formatDate } from '../lib/utils';
import type { Member } from '../lib/types';
import { Avatar } from './ui';

export function IDCardPreview({ member }: { member: Member }) {
  const [qr, setQr] = useState<string>('');

  useEffect(() => {
    const payload = JSON.stringify({
      id: member.id,
      name: member.name,
      member_no: member.member_no,
    });
    QRCode.toDataURL(payload, {
      width: 200,
      margin: 1,
      color: { dark: '#0a0a0b', light: '#ffffff' },
      errorCorrectionLevel: 'M',
    })
      .then(setQr)
      .catch(() => setQr(''));
  }, [member.id, member.name, member.member_no]);

  const isActive = member.status === 'active';
  const planLabel = member.category
    ? `${member.category} · ${member.duration_months ?? 0}M`
    : '—';

  return (
    <div className="flex justify-center">
      <div
        className="relative w-[340px] max-w-full overflow-hidden rounded-2xl border-4 border-gold-500 bg-white shadow-2xl"
        style={{ aspectRatio: '340 / 540' }}
      >
        {/* Header */}
        <div
          className="px-4 pb-3 pt-4 text-center"
          style={{
            background: 'linear-gradient(135deg, #0a0a0b 0%, #1c1c1f 60%, #533a14 100%)',
          }}
        >
          <div className="flex items-center justify-center gap-2">
            <svg
              viewBox="0 0 24 24"
              className="h-7 w-7"
              fill="none"
              stroke="#e7c454"
              strokeWidth="2"
            >
              <path d="M14.4 14.4L9.6 9.6M6.2 6.2c-1.5 1.5-2.2 3.6-2.2 5.8 0 4.4 3.6 8 8 8 2.2 0 4.3-.7 5.8-2.2M17.8 17.8c1.5-1.5 2.2-3.6 2.2-5.8 0-4.4-3.6-8-8-8-2.2 0-4.3.7-5.8 2.2" />
              <path d="M6.2 6.2l1.4 1.4M9.6 9.6l1.4 1.4M13 13l1.4 1.4M16.4 16.4l1.4 1.4" />
            </svg>
            <div className="text-xl font-extrabold tracking-wide text-gold-300">
              {GYM.name}
            </div>
          </div>
          <div className="mt-0.5 text-[9px] font-semibold uppercase tracking-[3px] text-amber-700">
            {GYM.tagline}
          </div>
        </div>

        {/* Gold bar */}
        <div
          className="h-1"
          style={{
            background: 'linear-gradient(90deg, #e7c454, #a9731f)',
          }}
        />

        {/* Photo */}
        <div className="flex justify-center pt-4">
          <div className="h-[120px] w-[100px] overflow-hidden rounded-lg border-[3px] border-gold-500 bg-neutral-100">
            {member.photo ? (
              <img
                src={member.photo}
                alt={member.name}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center">
                <Avatar photo={null} name={member.name} size="md" />
              </div>
            )}
          </div>
        </div>

        {/* Name + status */}
        <div className="px-5 pt-3 text-center">
          <div className="text-lg font-extrabold text-neutral-900">
            {member.name}
          </div>
          <div
            className={`mt-1 inline-block rounded-full px-3 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
              isActive
                ? 'bg-emerald-100 text-emerald-700'
                : 'bg-rose-100 text-rose-700'
            }`}
          >
            {member.status}
          </div>
        </div>

        {/* Info rows */}
        <div className="space-y-0 px-5 pt-3">
          <CardRow label="Member ID" value={member.member_no ?? '—'} />
          <CardRow label="Mobile" value={member.mobile ?? '—'} />
          <CardRow label="Plan" value={planLabel} />
          <CardRow label="Join Date" value={formatDate(member.start_date)} />
          <CardRow label="Expiry" value={formatDate(member.expiry_date)} />
        </div>

        {/* QR + footer */}
        <div className="absolute bottom-0 left-0 right-0">
          <div className="flex items-end justify-between px-5 pb-2">
            <div className="text-[8px] leading-tight text-neutral-500">
              <div className="font-bold text-neutral-700">{GYM.name}</div>
              <div>{GYM.address}</div>
              <div>{GYM.mobiles.join(' · ')}</div>
              <div>{GYM.gymTiming}</div>
            </div>
            {qr && (
              <div className="rounded border border-neutral-200 bg-white p-0.5">
                <img src={qr} alt="QR" className="h-14 w-14" />
              </div>
            )}
          </div>
          <div
            className="h-1"
            style={{
              background: 'linear-gradient(90deg, #a9731f, #e7c454)',
            }}
          />
        </div>
      </div>
    </div>
  );
}

function CardRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between border-b border-dashed border-neutral-200 py-1 text-[11px]">
      <span className="font-semibold text-amber-700">{label}</span>
      <span className="font-bold text-neutral-800">{value}</span>
    </div>
  );
}
