import { GYM } from './constants';
import { formatCurrency, formatDateTime, formatDate } from './utils';
import type { Member, Payment } from './types';

export function openPrintWindow(html: string) {
  const win = window.open('', '_blank', 'width=420,height=720');
  if (!win) {
    alert('Please allow popups to generate PDF / receipt.');
    return;
  }
  win.document.open();
  win.document.write(html);
  win.document.close();
  setTimeout(() => {
    win.focus();
    win.print();
  }, 400);
}

export function downloadHTML(html: string, filename: string) {
  const blob = new Blob([html], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

/* ---------- WhatsApp sharing ---------- */

function normalizePhone(mobile: string | null | undefined): string {
  const phone = (mobile ?? '').replace(/\D/g, '');
  return phone.length === 10 ? `91${phone}` : phone;
}

export function openWhatsApp(mobile: string | null | undefined, message: string) {
  const num = normalizePhone(mobile);
  const url = `https://wa.me/${num}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank');
}

export function receiptWhatsAppMessage(
  payment: Payment,
  member: Member | undefined
): string {
  const planLabel = member?.category
    ? `${member.category} · ${member.duration_months} Month`
    : '—';
  return [
    `Hello ${member?.name ?? 'Member'},`,
    `Your payment has been received successfully.`,
    ``,
    `*Receipt No:* ${payment.receipt_no}`,
    `*Amount:* ${formatCurrency(payment.amount)}`,
    `*Membership Plan:* ${planLabel}`,
    payment.new_expiry_date ? `*Expiry Date:* ${formatDate(payment.new_expiry_date)}` : '',
    payment.due_amount ? `*Due Amount:* ${formatCurrency(payment.due_amount)}` : '',
    ``,
    `Thank you for choosing ${GYM.name}.`,
    ``,
    `${GYM.name}`,
    `${GYM.address}`,
    `${GYM.mobiles.join(', ')}`,
  ]
    .filter(Boolean)
    .join('\n');
}

export function idCardWhatsAppMessage(member: Member): string {
  const planLabel = member.category
    ? `${member.category} · ${member.duration_months ?? 0}M`
    : '—';
  return [
    `Hello ${member.name},`,
    `Your membership ID card has been generated.`,
    ``,
    `*Member ID:* ${member.member_no ?? '—'}`,
    `*Name:* ${member.name}`,
    `*Mobile:* ${member.mobile ?? '—'}`,
    `*Plan:* ${planLabel}`,
    `*Join Date:* ${formatDate(member.start_date)}`,
    `*Expiry Date:* ${formatDate(member.expiry_date)}`,
    `*Status:* ${member.status.toUpperCase()}`,
    ``,
    `Thank you for choosing ${GYM.name}.`,
    ``,
    `${GYM.name}`,
    `${GYM.address}`,
    `${GYM.mobiles.join(', ')}`,
  ].join('\n');
}

export function renewalWhatsAppMessage(
  payment: Payment,
  member: Member | undefined
): string {
  const planLabel = member?.category
    ? `${member.category} · ${member.duration_months} Month`
    : '—';
  return [
    `Hello ${member?.name ?? 'Member'},`,
    `Your membership has been renewed successfully.`,
    ``,
    `*Receipt No:* ${payment.receipt_no}`,
    `*Amount Paid:* ${formatCurrency(payment.amount)}`,
    `*Membership Plan:* ${planLabel}`,
    payment.new_start_date ? `*New Start Date:* ${formatDate(payment.new_start_date)}` : '',
    payment.new_expiry_date ? `*New Expiry Date:* ${formatDate(payment.new_expiry_date)}` : '',
    payment.due_amount ? `*Due Amount:* ${formatCurrency(payment.due_amount)}` : '',
    ``,
    `Thank you for choosing ${GYM.name}.`,
    ``,
    `${GYM.name}`,
    `${GYM.address}`,
    `${GYM.mobiles.join(', ')}`,
  ]
    .filter(Boolean)
    .join('\n');
}

export function expiryReminderMessage(member: Member): string {
  return [
    `Hello ${member.name},`,
    `Your membership at ${GYM.name} is expiring soon.`,
    ``,
    `*Member ID:* ${member.member_no ?? '—'}`,
    `*Expiry Date:* ${formatDate(member.expiry_date)}`,
    ``,
    `Please renew your membership to continue enjoying our services without interruption.`,
    ``,
    `Thank you for choosing ${GYM.name}.`,
    ``,
    `${GYM.name}`,
    `${GYM.address}`,
    `${GYM.mobiles.join(', ')}`,
  ].join('\n');
}

export function duePaymentReminderMessage(member: Member): string {
  return [
    `Hello ${member.name},`,
    `This is a friendly reminder regarding your pending due payment at ${GYM.name}.`,
    ``,
    `*Member ID:* ${member.member_no ?? '—'}`,
    `*Due Amount:* ${formatCurrency(member.due_amount ?? 0)}`,
    `*Expiry Date:* ${formatDate(member.expiry_date)}`,
    ``,
    `Kindly clear your due payment at the earliest to avoid any inconvenience.`,
    ``,
    `Thank you for choosing ${GYM.name}.`,
    ``,
    `${GYM.name}`,
    `${GYM.address}`,
    `${GYM.mobiles.join(', ')}`,
  ].join('\n');
}

export function generateReceiptHTML(
  payment: Payment,
  member: Member | undefined,
  _settings: Record<string, string>
): string {
  const planLabel = member?.category
    ? `${member.category} · ${member.duration_months} Month`
    : '—';
  const dueAmount = payment.due_amount ?? 0;
  const receivedBy = payment.received_by ?? 'Admin';
  return `<!doctype html><html><head><meta charset="utf-8"/><title>Receipt ${payment.receipt_no}</title>
<style>
  *{font-family:'Segoe UI',Arial,sans-serif;box-sizing:border-box;margin:0;padding:0;}
  body{background:#0a0a0b;padding:18px;color:#1a1a1a;}
  .rcpt{width:380px;margin:0 auto;background:#fff;border:8px solid #c8902a;border-radius:14px;overflow:hidden;}
  .head{background:#0a0a0b;color:#e7c454;padding:18px 16px;text-align:center;}
  .head .logo-row{display:flex;align-items:center;justify-content:center;gap:8px;}
  .head .logo-row svg{width:28px;height:28px;}
  .head .logo{font-size:22px;font-weight:800;letter-spacing:1px;}
  .head .tag{font-size:10px;color:#a9731f;margin-top:3px;letter-spacing:2px;}
  .gold-bar{height:4px;background:linear-gradient(90deg,#e7c454,#a9731f);}
  .body{padding:16px;}
  .row{display:flex;justify-content:space-between;padding:5px 0;font-size:13px;border-bottom:1px dashed #ddd;}
  .row span:first-child{color:#666;}
  .row span:last-child{font-weight:600;color:#111;}
  .title{text-align:center;font-size:14px;font-weight:700;color:#c8902a;margin:8px 0 12px;letter-spacing:1px;}
  .amt-box{display:flex;gap:10px;margin:14px 0;}
  .amt{flex:1;text-align:center;padding:12px 8px;background:#fbf6e7;border:1px dashed #c8902a;border-radius:8px;}
  .amt.due{background:#fff0f0;border-color:#e8a0a0;}
  .amt .lbl{font-size:9px;color:#7e551b;letter-spacing:2px;}
  .amt.due .lbl{color:#b04040;}
  .amt .val{font-size:22px;font-weight:800;color:#7e551b;}
  .amt.due .val{color:#b04040;}
  .ftr{text-align:center;padding:14px 16px;background:#0a0a0b;color:#999;font-size:10px;line-height:1.6;}
  .ftr b{color:#e7c454;}
  .sign{margin-top:14px;display:flex;justify-content:space-between;font-size:11px;color:#888;}
  .sign div{text-align:center;}
  .sign .line{border-top:1px solid #999;width:110px;margin-bottom:4px;}
  .recv{text-align:center;margin-top:10px;font-size:11px;color:#666;}
  .recv b{color:#c8902a;}
</style></head><body>
  <div class="rcpt">
    <div class="head">
      <div class="logo-row">
        <svg viewBox="0 0 24 24" fill="none" stroke="#e7c454" stroke-width="2"><path d="M14.4 14.4L9.6 9.6M6.2 6.2c-1.5 1.5-2.2 3.6-2.2 5.8 0 4.4 3.6 8 8 8 2.2 0 4.3-.7 5.8-2.2M17.8 17.8c1.5-1.5 2.2-3.6 2.2-5.8 0-4.4-3.6-8-8-8-2.2 0-4.3.7-5.8 2.2"/><path d="M6.2 6.2l1.4 1.4M9.6 9.6l1.4 1.4M13 13l1.4 1.4M16.4 16.4l1.4 1.4"/></svg>
        <div class="logo">${GYM.name}</div>
      </div>
      <div class="tag">${GYM.tagline.toUpperCase()}</div>
    </div>
    <div class="gold-bar"></div>
    <div class="body">
      <div class="title">PAYMENT RECEIPT</div>
      <div class="row"><span>Receipt No</span><span>${payment.receipt_no}</span></div>
      <div class="row"><span>Payment Date</span><span>${formatDateTime(payment.paid_date)}</span></div>
      <div class="row"><span>Member ID</span><span>${member?.member_no ?? '—'}</span></div>
      <div class="row"><span>Member Name</span><span>${member?.name ?? '—'}</span></div>
      <div class="row"><span>Mobile Number</span><span>${member?.mobile ?? '—'}</span></div>
      <div class="row"><span>Membership Plan</span><span>${planLabel}</span></div>
      <div class="row"><span>Payment Mode</span><span>${payment.method ?? 'Cash'}</span></div>
      <div class="row"><span>Payment Type</span><span>${payment.type === 'registration' ? 'Registration + Membership' : 'Membership Renewal'}</span></div>
      ${payment.new_expiry_date ? `<div class="row"><span>Valid Till</span><span>${formatDate(payment.new_expiry_date)}</span></div>` : ''}
      <div class="amt-box">
        <div class="amt"><div class="lbl">AMOUNT PAID</div><div class="val">${formatCurrency(payment.amount)}</div></div>
        <div class="amt due"><div class="lbl">DUE AMOUNT</div><div class="val">${formatCurrency(dueAmount)}</div></div>
      </div>
      <div class="recv">Received By: <b>${receivedBy}</b></div>
      <div class="sign"><div><div class="line"></div>Member Sign</div><div><div class="line"></div>Authorized Sign</div></div>
    </div>
    <div class="gold-bar"></div>
    <div class="ftr"><b>${GYM.name}</b><br/>${GYM.address}<br/>${GYM.mobiles.join(' · ')}<br/>Timings: ${GYM.gymTiming} | Ladies: ${GYM.ladiesTiming}</div>
  </div>
</body></html>`;
}

export function generateAdmissionFormHTML(
  member: Member,
  _settings: Record<string, string>
): string {
  return `<!doctype html><html><head><meta charset="utf-8"/><title>Admission Form ${member.member_no ?? ''}</title>
<style>
  *{font-family:'Segoe UI',Arial,sans-serif;box-sizing:border-box;margin:0;padding:0;}
  body{background:#0a0a0b;padding:18px;color:#1a1a1a;}
  .form{width:600px;margin:0 auto;background:#fff;border-radius:14px;overflow:hidden;border:3px solid #c8902a;}
  .head{background:#0a0a0b;color:#e7c454;padding:18px;text-align:center;}
  .head .logo{font-size:24px;font-weight:800;}
  .head .tag{font-size:10px;color:#a9731f;letter-spacing:2px;}
  .bar{height:4px;background:linear-gradient(90deg,#e7c454,#a9731f);}
  .body{padding:20px;}
  .title{text-align:center;font-size:16px;font-weight:700;color:#c8902a;margin-bottom:14px;letter-spacing:1px;}
  .grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
  .photo-col{display:flex;gap:16px;margin-bottom:16px;}
  .photo{width:110px;height:130px;border:2px solid #c8902a;border-radius:8px;overflow:hidden;}
  .photo img{width:100%;height:100%;object-fit:cover;}
  .info{flex:1;display:flex;flex-direction:column;justify-content:center;gap:6px;}
  .field{display:flex;gap:6px;font-size:12px;}
  .field .k{color:#7e551b;font-weight:600;min-width:90px;}
  .field .v{color:#111;font-weight:600;}
  .full{grid-column:1/3;}
  .box{border:1px solid #ddd;border-radius:8px;padding:8px 10px;}
  .box .lbl{font-size:10px;color:#7e551b;font-weight:700;letter-spacing:1px;margin-bottom:3px;}
  .box .val{font-size:13px;color:#111;font-weight:600;}
  .decl{border:1px dashed #c8902a;border-radius:8px;padding:12px;margin-top:14px;font-size:11px;color:#444;line-height:1.6;}
  .check{margin-top:14px;display:flex;gap:8px;align-items:center;font-size:12px;}
  .sign{margin-top:20px;display:flex;justify-content:space-between;font-size:11px;color:#888;}
  .sign div{text-align:center;}
  .sign .line{border-top:1px solid #999;width:140px;margin-bottom:4px;}
  .ftr{text-align:center;padding:10px;background:#0a0a0b;color:#999;font-size:9px;}
</style></head><body>
  <div class="form">
    <div class="head"><div class="logo">${GYM.name}</div><div class="tag">${GYM.tagline.toUpperCase()}</div></div>
    <div class="bar"></div>
    <div class="body">
      <div class="title">MEMBERSHIP ADMISSION FORM</div>
      <div class="photo-col">
        <div class="photo">${member.photo ? `<img src="${member.photo}"/>` : ''}</div>
        <div class="info">
          <div class="field"><span class="k">Member No:</span><span class="v">${member.member_no ?? '—'}</span></div>
          <div class="field"><span class="k">Date:</span><span class="v">${formatDate(member.created_at)}</span></div>
          <div class="field"><span class="k">Status:</span><span class="v">${member.status}</span></div>
        </div>
      </div>
      <div class="grid">
        <div class="box"><div class="lbl">NAME</div><div class="val">${member.name}</div></div>
        <div class="box"><div class="lbl">FATHER NAME</div><div class="val">${member.father_name ?? '—'}</div></div>
        <div class="box"><div class="lbl">GENDER</div><div class="val">${member.gender ?? '—'}</div></div>
        <div class="box"><div class="lbl">DATE OF BIRTH</div><div class="val">${formatDate(member.date_of_birth)}</div></div>
        <div class="box"><div class="lbl">MOBILE</div><div class="val">${member.mobile ?? '—'}</div></div>
        <div class="box"><div class="lbl">EMERGENCY CONTACT</div><div class="val">${member.emergency_contact ?? '—'}</div></div>
        <div class="box full"><div class="lbl">ADDRESS</div><div class="val">${member.address ?? '—'}</div></div>
        <div class="box"><div class="lbl">PLAN SELECTED</div><div class="val">${member.category ?? '—'} · ${member.duration_months ?? '—'} Months · ${formatCurrency(member.plan_price)}</div></div>
        <div class="box"><div class="lbl">REGISTRATION FEE</div><div class="val">${formatCurrency(member.registration_fee)}</div></div>
        <div class="box"><div class="lbl">START DATE</div><div class="val">${formatDate(member.start_date)}</div></div>
        <div class="box"><div class="lbl">EXPIRY DATE</div><div class="val">${formatDate(member.expiry_date)}</div></div>
        <div class="box full"><div class="lbl">MEDICAL CONDITION</div><div class="val">${member.medical_condition || 'None'}</div></div>
        <div class="box full"><div class="lbl">CARDIO NOTES</div><div class="val">${member.cardio_notes || 'None'}</div></div>
      </div>
      <div class="decl"><strong>DECLARATION:</strong> I confirm that I am joining the gym voluntarily and understand that exercise involves physical risk. The gym management shall not be responsible for any injury, illness, loss or damage arising during training.</div>
      <div class="check"><div class="chk">${member.declaration_accepted ? '✓' : '✗'}</div><span>I have read and accept the declaration above.</span></div>
      <div class="sign"><div><div class="line"></div>Member Signature</div><div><div class="line"></div>Authorized Signature</div></div>
    </div>
    <div class="bar"></div>
    <div class="ftr">${GYM.name} · ${GYM.address} · ${GYM.mobiles.join(' · ')}</div>
  </div>
</body></html>`;
}

export function generateIDCardHTML(
  member: Member,
  qrDataUrl?: string
): string {
  const isActive = member.status === 'active';
  const planLabel = member.category
    ? `${member.category} · ${member.duration_months ?? 0}M`
    : '—';
  return `<!doctype html><html><head><meta charset="utf-8"/><title>ID Card ${member.member_no ?? ''}</title>
<style>
  *{font-family:'Segoe UI',Arial,sans-serif;box-sizing:border-box;margin:0;padding:0;}
  body{background:#0a0a0b;padding:24px;display:flex;justify-content:center;}
  .card{width:340px;height:540px;border-radius:18px;overflow:hidden;background:#fff;border:4px solid #c8902a;position:relative;}
  .head{background:linear-gradient(135deg,#0a0a0b,#1c1c1f 60%,#533a14);color:#e7c454;padding:18px 16px 14px;text-align:center;}
  .head .logo{font-size:22px;font-weight:800;}
  .head .tag{font-size:9px;color:#a9731f;letter-spacing:3px;margin-top:2px;}
  .bar{height:3px;background:linear-gradient(90deg,#e7c454,#a9731f);}
  .photo-wrap{padding:16px;text-align:center;}
  .photo{width:100px;height:120px;border-radius:10px;border:3px solid #c8902a;overflow:hidden;margin:0 auto;background:#f5f5f5;}
  .photo img{width:100%;height:100%;object-fit:cover;}
  .info{padding:4px 20px 0;}
  .name{font-size:18px;font-weight:800;color:#0a0a0b;text-align:center;}
  .status{display:inline-block;margin:4px auto 0;padding:2px 10px;border-radius:99px;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:1px;}
  .status.active{background:#d1fae5;color:#047857;}
  .status.expired{background:#ffe4e6;color:#be123c;}
  .status-wrap{text-align:center;}
  .row{display:flex;justify-content:space-between;padding:4px 0;font-size:11px;border-bottom:1px dashed #ddd;}
  .row .k{color:#7e551b;font-weight:600;}
  .row .v{font-weight:700;color:#111;}
  .bottom{position:absolute;bottom:0;left:0;right:0;}
  .bottom-inner{display:flex;align-items:flex-end;justify-content:space-between;padding:0 18px 4px;}
  .addr{font-size:7px;color:#888;line-height:1.4;}
  .addr b{color:#555;}
  .qr{border:1px solid #e5e5e5;border-radius:4px;padding:2px;background:#fff;}
  .qr img{width:56px;height:56px;}
  .bar2{height:3px;background:linear-gradient(90deg,#a9731f,#e7c454);}
</style></head><body>
  <div class="card">
    <div class="head"><div class="logo">${GYM.name}</div><div class="tag">${GYM.tagline.toUpperCase()}</div></div>
    <div class="bar"></div>
    <div class="photo-wrap"><div class="photo">${member.photo ? `<img src="${member.photo}"/>` : ''}</div></div>
    <div class="info">
      <div class="name">${member.name}</div>
      <div class="status-wrap"><span class="status ${isActive ? 'active' : 'expired'}">${member.status}</span></div>
      <div style="margin-top:8px;">
        <div class="row"><span class="k">Member ID</span><span class="v">${member.member_no ?? '—'}</span></div>
        <div class="row"><span class="k">Mobile</span><span class="v">${member.mobile ?? '—'}</span></div>
        <div class="row"><span class="k">Plan</span><span class="v">${planLabel}</span></div>
        <div class="row"><span class="k">Join Date</span><span class="v">${formatDate(member.start_date)}</span></div>
        <div class="row"><span class="k">Expiry</span><span class="v">${formatDate(member.expiry_date)}</span></div>
      </div>
    </div>
    <div class="bottom">
      <div class="bottom-inner">
        <div class="addr"><b>${GYM.name}</b><br/>${GYM.address}<br/>${GYM.mobiles.join(' · ')}<br/>${GYM.gymTiming}</div>
        ${qrDataUrl ? `<div class="qr"><img src="${qrDataUrl}"/></div>` : ''}
      </div>
      <div class="bar2"></div>
    </div>
  </div>
</body></html>`;
}
