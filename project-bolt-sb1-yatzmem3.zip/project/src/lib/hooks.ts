import { useCallback, useEffect, useState } from 'react';
import { supabase } from './supabase';
import type {
  Member,
  Payment,
  Plan,
  Trainer,
  Inquiry,
  Attendance,
  Settings,
} from './types';

export function usePlans() {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('plans')
      .select('*')
      .order('sort_order', { ascending: true });
    setPlans((data ?? []) as Plan[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { plans, loading, reload: load };
}

export function useMembers() {
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('members')
      .select('*')
      .order('created_at', { ascending: false });
    setMembers((data ?? []) as Member[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const syncStatuses = useCallback(async () => {
    const today = new Date().toISOString().slice(0, 10);
    await supabase
      .from('members')
      .update({ status: 'expired' })
      .lt('expiry_date', today)
      .neq('status', 'inactive');
    load();
  }, [load]);

  return { members, loading, reload: load, syncStatuses };
}

export function useTrainers() {
  const [trainers, setTrainers] = useState<Trainer[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('trainers')
      .select('*')
      .order('created_at', { ascending: false });
    setTrainers((data ?? []) as Trainer[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { trainers, loading, reload: load };
}

export function useInquiries() {
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('inquiries')
      .select('*')
      .order('created_at', { ascending: false });
    setInquiries((data ?? []) as Inquiry[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { inquiries, loading, reload: load };
}

export function usePayments() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('payments')
      .select('*')
      .order('paid_date', { ascending: false })
      .limit(500);
    setPayments((data ?? []) as Payment[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { payments, loading, reload: load };
}

export function useAttendanceToday() {
  const [records, setRecords] = useState<Attendance[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    const { data } = await supabase
      .from('attendance')
      .select('*')
      .gte('check_in', start.toISOString())
      .order('check_in', { ascending: false });
    setRecords((data ?? []) as Attendance[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { records, loading, reload: load };
}

export function useAttendance() {
  const [records, setRecords] = useState<Attendance[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('attendance')
      .select('*')
      .order('check_in', { ascending: false })
      .limit(2000);
    setRecords((data ?? []) as Attendance[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { records, loading, reload: load };
}

export function useSettings() {
  const [settings, setSettings] = useState<Settings>({});
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('settings').select('key, value');
    const out: Settings = {};
    for (const row of data ?? []) out[row.key] = row.value;
    setSettings(out);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { settings, loading, reload: load };
}
