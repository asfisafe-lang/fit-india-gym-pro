export const GYM = {
  name: 'Fit India Gym',
  tagline: 'Fit India Strong India',
  owner: 'Fit India Team',
  team: 'Fit India Team',
  managedBy: 'Fit India Administration',
  address:
    'Pather Ki Masjid, Dargah Road, Near Shahi Darbar Banquet Hall, Patna-6',
  mobiles: ['6207412972', '7766880099', '7766990044'],
  gymTiming: '6:00 AM to 12:00 Midnight',
  ladiesTiming: '11:00 AM to 4:30 PM',
};

export const REGISTRATION_FEE_DEFAULT = 500;

export type Role =
  | 'Super Admin'
  | 'Admin'
  | 'Male Trainer'
  | 'Female Trainer'
  | 'Member';

export const ROLES: { name: Role; count: string }[] = [
  { name: 'Super Admin', count: '6' },
  { name: 'Admin', count: '10–12' },
  { name: 'Male Trainer', count: '' },
  { name: 'Female Trainer', count: '' },
  { name: 'Member', count: '' },
];

export const NAV: {
  group: string;
  items: { id: string; label: string; icon: string }[];
}[] = [
  {
    group: 'Overview',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: 'LayoutDashboard' },
      { id: 'reports', label: 'Reports', icon: 'BarChart3' },
    ],
  },
  {
    group: 'Members',
    items: [
      { id: 'admission', label: 'New Admission', icon: 'UserPlus' },
      { id: 'members', label: 'All Members', icon: 'Users' },
      { id: 'members-active', label: 'Active Members', icon: 'CheckCircle2' },
      { id: 'members-expired', label: 'Expired Members', icon: 'AlertCircle' },
      { id: 'members-due', label: 'Due Payments', icon: 'Wallet' },
      { id: 'attendance', label: 'Attendance', icon: 'ClipboardCheck' },
    ],
  },
  {
    group: 'Finance',
    items: [
      { id: 'payments', label: 'Payments', icon: 'IndianRupee' },
      { id: 'inquiries', label: 'Inquiries', icon: 'PhoneCall' },
    ],
  },
  {
    group: 'Team',
    items: [
      { id: 'trainers', label: 'Trainers', icon: 'Dumbbell' },
      { id: 'backup', label: 'Backup & Export', icon: 'Download' },
      { id: 'settings', label: 'Settings', icon: 'Settings' },
    ],
  },
];
