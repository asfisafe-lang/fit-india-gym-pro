export type Plan = {
  id: string;
  category: 'Boys/Unisex' | 'Only Ladies';
  label: string;
  duration_months: number;
  price: number;
  is_active: boolean;
  sort_order: number;
};

export type Member = {
  id: string;
  member_no: string | null;
  photo: string | null;
  name: string;
  father_name: string | null;
  gender: 'Male' | 'Female' | 'Other' | null;
  date_of_birth: string | null;
  mobile: string | null;
  address: string | null;
  emergency_contact: string | null;
  plan_id: string | null;
  category: string | null;
  duration_months: number | null;
  plan_price: number | null;
  registration_fee: number | null;
  medical_condition: string | null;
  cardio_notes: string | null;
  declaration_accepted: boolean;
  status: 'active' | 'expired' | 'inactive';
  due_amount: number | null;
  start_date: string;
  expiry_date: string | null;
  assigned_trainer_id: string | null;
  created_at: string;
  updated_at: string | null;
};

export type Payment = {
  id: string;
  member_id: string;
  receipt_no: string;
  type: 'registration' | 'renewal';
  amount: number;
  due_amount: number | null;
  method: string | null;
  note: string | null;
  paid_date: string;
  received_by: string | null;
  new_start_date: string | null;
  new_expiry_date: string | null;
  created_at: string;
};

export type Trainer = {
  id: string;
  name: string;
  gender: 'Male' | 'Female' | null;
  specialization: string | null;
  mobile: string | null;
  timing: string | null;
  is_active: boolean;
  created_at: string;
};

export type Inquiry = {
  id: string;
  name: string;
  mobile: string | null;
  notes: string | null;
  status: 'new' | 'contacted' | 'joined' | 'lost';
  follow_up_date: string | null;
  created_at: string;
};

export type Attendance = {
  id: string;
  member_id: string;
  check_in: string;
  created_at: string;
};

export type Settings = Record<string, string>;
