import { supabase } from './supabase';
import type { Settings } from './types';

export function formatCurrency(n: number | null | undefined): string {
  const v = Number(n ?? 0);
  return '₹' + v.toLocaleString('en-IN', { maximumFractionDigits: 0 });
}

export function formatDate(d: string | null | undefined): string {
  if (!d) return '—';
  const date = new Date(d);
  if (isNaN(date.getTime())) return '—';
  return date.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function formatDateTime(d: string | null | undefined): string {
  if (!d) return '—';
  const date = new Date(d);
  if (isNaN(date.getTime())) return '—';
  return date.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

export function addMonths(dateISO: string, months: number): string {
  const d = new Date(dateISO);
  d.setMonth(d.getMonth() + months);
  return d.toISOString().slice(0, 10);
}

export function daysUntil(dateISO: string | null): number | null {
  if (!dateISO) return null;
  const target = new Date(dateISO);
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  target.setHours(0, 0, 0, 0);
  const diff = target.getTime() - now.getTime();
  return Math.round(diff / (1000 * 60 * 60 * 24));
}

export function statusBadge(status: string): string {
  switch (status) {
    case 'active':
      return 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30';
    case 'expired':
      return 'bg-red-500/15 text-red-300 border border-red-500/30';
    case 'inactive':
      return 'bg-neutral-500/15 text-neutral-300 border border-neutral-500/30';
    case 'new':
      return 'bg-sky-500/15 text-sky-300 border border-sky-500/30';
    case 'contacted':
      return 'bg-amber-500/15 text-amber-300 border border-amber-500/30';
    case 'joined':
      return 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30';
    case 'lost':
      return 'bg-red-500/15 text-red-300 border border-red-500/30';
    default:
      return 'bg-neutral-500/15 text-neutral-300 border border-neutral-500/30';
  }
}

const MEMBER_NO_PREFIX = 'FIGP-';

export async function generateMemberNo(): Promise<string> {
  const { data, error } = await supabase
    .from('members')
    .select('member_no')
    .like('member_no', `${MEMBER_NO_PREFIX}%`);
  if (error) throw error;
  let maxSeq = 0;
  for (const row of data ?? []) {
    const num = parseInt(
      String(row.member_no ?? '').replace(MEMBER_NO_PREFIX, ''),
      10
    );
    if (!Number.isNaN(num) && num > maxSeq) maxSeq = num;
  }
  return `${MEMBER_NO_PREFIX}${String(maxSeq + 1).padStart(4, '0')}`;
}

export async function generateReceiptNo(): Promise<string> {
  const { data } = await supabase
    .from('payments')
    .select('receipt_no')
    .like('receipt_no', 'FIGP-RCPT-%');
  let maxSeq = 0;
  for (const row of data ?? []) {
    const m = /FIGP-RCPT-(\d+)$/.exec(row.receipt_no ?? '');
    if (m) maxSeq = Math.max(maxSeq, parseInt(m[1], 10));
  }
  return `FIGP-RCPT-${String(maxSeq + 1).padStart(4, '0')}`;
}

export async function fetchSettings(): Promise<Settings> {
  const { data, error } = await supabase.from('settings').select('key, value');
  if (error) throw error;
  const out: Settings = {};
  for (const row of data ?? []) out[row.key] = row.value;
  return out;
}

export async function upsertSetting(key: string, value: string): Promise<void> {
  const { error } = await supabase
    .from('settings')
    .upsert({ key, value, updated_at: new Date().toISOString() });
  if (error) throw error;
}
