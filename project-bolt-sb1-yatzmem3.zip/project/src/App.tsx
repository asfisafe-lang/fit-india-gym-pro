import { useState } from 'react';
import { AppShell, useHashRoute } from './components/AppShell';
import { DashboardPage } from './pages/Dashboard';
import { AdmissionPage } from './pages/Admission';
import { MembersPage } from './pages/Members';
import { MemberProfilePage } from './pages/MemberProfile';
import { PaymentsPage } from './pages/Payments';
import { InquiriesPage } from './pages/Inquiries';
import { TrainersPage } from './pages/Trainers';
import { AttendancePage } from './pages/Attendance';
import { SettingsPage } from './pages/Settings';
import { BackupPage } from './pages/Backup';
import { ReportsPage } from './pages/Reports';
import type { Role } from './lib/constants';

const ROLE_STORE_KEY = 'fig_current_role';

function App() {
  const { route, navigate, query } = useHashRoute();
  const [role, setRole] = useState<Role>(
    () => (localStorage.getItem(ROLE_STORE_KEY) as Role) || 'Super Admin'
  );

  const memberRoutes = new Set([
    'members',
    'members-active',
    'members-expired',
    'members-expiring',
    'members-due',
  ]);
  const activeMemberRoute = memberRoutes.has(route) ? route : 'members';

  return (
    <AppShell
      current={route}
      onNavigate={navigate}
      role={role}
      onRoleChange={setRole}
    >
      {route === 'dashboard' && <DashboardPage onNavigate={navigate} />}
      {route === 'admission' && (
        <AdmissionPage onDone={() => navigate('members')} />
      )}
      {memberRoutes.has(route) && (
        <MembersPage
          route={activeMemberRoute}
          role={role}
          onNavigate={navigate}
        />
      )}
      {route === 'member-profile' && (
        <MemberProfilePage role={role} onNavigate={navigate} query={query} />
      )}
      {route === 'payments' && <PaymentsPage />}
      {route === 'inquiries' && <InquiriesPage />}
      {route === 'trainers' && <TrainersPage />}
      {route === 'attendance' && <AttendancePage />}
      {route === 'settings' && <SettingsPage />}
      {route === 'backup' && <BackupPage />}
      {route === 'reports' && <ReportsPage />}
      {![
        'dashboard',
        'admission',
        ...[...memberRoutes],
        'member-profile',
        'payments',
        'inquiries',
        'trainers',
        'attendance',
        'settings',
        'backup',
        'reports',
      ].includes(route) && <DashboardPage onNavigate={navigate} />}
    </AppShell>
  );
}

export default App;
