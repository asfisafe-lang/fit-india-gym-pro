import { useState, useRef, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { Card, Icon, Button, Loading } from '../components/ui';
import { formatCurrency, formatDate, formatDateTime } from '../lib/utils';
import { GYM } from '../lib/constants';
import { openPrintWindow } from '../lib/print';
import type {
  Member,
  Payment,
  Attendance,
} from '../lib/types';

type Toast = { type: 'success' | 'error'; msg: string } | null;

export function BackupPage() {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  const [toast, setToast] = useState<Toast>(null);
  const [restoreStatus, setRestoreStatus] = useState<string>('');
  const fileRef = useRef<HTMLInputElement>(null);

  const showToast = useCallback((type: 'success' | 'error', msg: string) => {
    setToast({ type, msg });
    setTimeout(() => setToast(null), 4000);
  }, []);

  const fetchAll = useCallback(async () => {
    const [members, payments, attendance, trainers, inquiries, plans, settings] =
      await Promise.all([
        supabase.from('members').select('*').order('created_at', { ascending: false }),
        supabase.from('payments').select('*').order('paid_date', { ascending: false }),
        supabase.from('attendance').select('*').order('check_in', { ascending: false }),
        supabase.from('trainers').select('*').order('created_at', { ascending: false }),
        supabase.from('inquiries').select('*').order('created_at', { ascending: false }),
        supabase.from('plans').select('*').order('sort_order', { ascending: true }),
        supabase.from('settings').select('*'),
      ]);
    return {
      members: members.data ?? [],
      payments: payments.data ?? [],
      attendance: attendance.data ?? [],
      trainers: trainers.data ?? [],
      inquiries: inquiries.data ?? [],
      plans: plans.data ?? [],
      settings: settings.data ?? [],
    };
  }, []);

  const filterByDate = useCallback(
    <T extends Record<string, any>>(
      rows: T[],
      field: string
    ): T[] => {
      if (!from && !to) return rows;
      return rows.filter((r) => {
        const val = r[field];
        if (!val) return false;
        const d = new Date(val).toISOString().slice(0, 10);
        if (from && d < from) return false;
        if (to && d > to) return false;
        return true;
      });
    },
    [from, to]
  );

  /* ---------- CSV export ---------- */

  const downloadCSV = useCallback(
    (filename: string, headers: string[], rows: (string | number)[][]) => {
      const csv = [
        headers.map((h) => `"${h}"`).join(','),
        ...rows.map((r) =>
          r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')
        ),
      ].join('\n');
      const blob = new Blob(['\ufeff' + csv], {
        type: 'text/csv;charset=utf-8;',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}-${new Date().toISOString().slice(0, 10)}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    },
    []
  );

  /* ---------- XLSX (HTML table) export ---------- */

  const downloadXLSX = useCallback(
    (filename: string, headers: string[], rows: (string | number)[][]) => {
      const table = `<table><thead><tr>${headers
        .map((h) => `<th style="background:#c8902a;color:#000;font-weight:bold;padding:6px;border:1px solid #ccc">${h}</th>`)
        .join('')}</tr></thead><tbody>${rows
        .map(
          (r) =>
            `<tr>${r
              .map((c) => `<td style="padding:6px;border:1px solid #ddd">${c}</td>`)
              .join('')}</tr>`
        )
        .join('')}</tbody></table>`;
      const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="utf-8"></head><body>${table}</body></html>`;
      const blob = new Blob([html], { type: 'application/vnd.ms-excel' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}-${new Date().toISOString().slice(0, 10)}.xls`;
      a.click();
      URL.revokeObjectURL(url);
    },
    []
  );

  /* ---------- PDF (print) export ---------- */

  const downloadPDF = useCallback(
    (title: string, headers: string[], rows: (string | number)[][]) => {
      const html = `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title>
<style>
  *{font-family:'Segoe UI',Arial,sans-serif;box-sizing:border-box;margin:0;padding:0;}
  body{padding:24px;color:#1a1a1a;}
  h1{color:#c8902a;font-size:18px;margin-bottom:2px;}
  .sub{color:#888;font-size:11px;margin-bottom:16px;}
  table{width:100%;border-collapse:collapse;font-size:11px;}
  th{background:#c8902a;color:#000;padding:6px 8px;text-align:left;border:1px solid #ddd;font-weight:bold;}
  td{padding:5px 8px;border:1px solid #eee;}
  tr:nth-child(even){background:#f9f7f0;}
  .foot{margin-top:20px;text-align:center;font-size:10px;color:#999;}
</style></head><body>
  <h1>${GYM.name} — ${title}</h1>
  <div class="sub">Generated on ${new Date().toLocaleString()}${
        from || to
          ? ` · Filter: ${from || '…'} to ${to || '…'}`
          : ''
      } · ${rows.length} records</div>
  <table><thead><tr>${headers
        .map((h) => `<th>${h}</th>`)
        .join('')}</tr></thead><tbody>${rows
        .map(
          (r) => `<tr>${r.map((c) => `<td>${c}</td>`).join('')}</tr>`
        )
        .join('')}</tbody></table>
  <div class="foot">${GYM.name} · ${GYM.address} · ${GYM.mobiles.join(', ')}</div>
</body></html>`;
      openPrintWindow(html);
    },
    [from, to]
  );

  /* ---------- Export handlers ---------- */

  const exportMembers = useCallback(
    async (format: 'csv' | 'xlsx' | 'pdf') => {
      setBusy(`members-${format}`);
      try {
        const data = await fetchAll();
        const rows = data.members.map((m: Member) => [
          m.name,
          m.member_no ?? '',
          m.mobile ?? '',
          m.gender ?? '',
          m.category ?? '',
          `${m.duration_months ?? 0}M`,
          formatCurrency(m.plan_price ?? 0),
          m.status,
          formatDate(m.start_date),
          formatDate(m.expiry_date),
          formatCurrency(m.due_amount ?? 0),
          formatDate(m.created_at),
        ]);
        const headers = [
          'Name',
          'Member No',
          'Mobile',
          'Gender',
          'Category',
          'Duration',
          'Plan Price',
          'Status',
          'Start Date',
          'Expiry Date',
          'Due Amount',
          'Created',
        ];
        const fn = `Members-${format}`;
        if (format === 'csv') downloadCSV(fn, headers, rows);
        else if (format === 'xlsx') downloadXLSX(fn, headers, rows);
        else downloadPDF('Members Export', headers, rows);
        showToast('success', `Exported ${rows.length} members as ${format.toUpperCase()}`);
      } catch (e: any) {
        showToast('error', `Export failed: ${e.message}`);
      }
      setBusy(null);
    },
    [fetchAll, downloadCSV, downloadXLSX, downloadPDF, showToast]
  );

  const exportAttendance = useCallback(
    async (format: 'csv' | 'xlsx' | 'pdf') => {
      setBusy(`attendance-${format}`);
      try {
        const data = await fetchAll();
        const memberMap = new Map(
          data.members.map((m: Member) => [m.id, m])
        );
        let records = data.attendance as Attendance[];
        records = filterByDate(records as any[], 'check_in') as Attendance[];
        const rows = records.map((r) => {
          const m = memberMap.get(r.member_id);
          return [
            m?.name ?? '—',
            m?.member_no ?? '—',
            m?.mobile ?? '',
            formatDateTime(r.check_in),
          ];
        });
        const headers = ['Member Name', 'Member No', 'Mobile', 'Check-In Time'];
        const fn = `Attendance-${format}`;
        if (format === 'csv') downloadCSV(fn, headers, rows);
        else if (format === 'xlsx') downloadXLSX(fn, headers, rows);
        else downloadPDF('Attendance Export', headers, rows);
        showToast('success', `Exported ${rows.length} attendance records as ${format.toUpperCase()}`);
      } catch (e: any) {
        showToast('error', `Export failed: ${e.message}`);
      }
      setBusy(null);
    },
    [fetchAll, filterByDate, downloadCSV, downloadXLSX, downloadPDF, showToast]
  );

  const exportPayments = useCallback(
    async (format: 'csv' | 'xlsx' | 'pdf') => {
      setBusy(`payments-${format}`);
      try {
        const data = await fetchAll();
        const memberMap = new Map(
          data.members.map((m: Member) => [m.id, m])
        );
        let records = data.payments as Payment[];
        records = filterByDate(records as any[], 'paid_date') as Payment[];
        const rows = records.map((p) => {
          const m = memberMap.get(p.member_id);
          return [
            p.receipt_no,
            m?.name ?? '—',
            m?.member_no ?? '—',
            p.type === 'registration' ? 'Registration' : 'Renewal',
            formatCurrency(p.amount),
            p.method ?? 'Cash',
            formatCurrency(p.due_amount ?? 0),
            formatDateTime(p.paid_date),
            p.received_by ?? '',
          ];
        });
        const headers = [
          'Receipt No',
          'Member Name',
          'Member No',
          'Type',
          'Amount',
          'Method',
          'Due Amount',
          'Paid Date',
          'Received By',
        ];
        const fn = `Payments-${format}`;
        if (format === 'csv') downloadCSV(fn, headers, rows);
        else if (format === 'xlsx') downloadXLSX(fn, headers, rows);
        else downloadPDF('Payments & Due Export', headers, rows);
        showToast('success', `Exported ${rows.length} payment records as ${format.toUpperCase()}`);
      } catch (e: any) {
        showToast('error', `Export failed: ${e.message}`);
      }
      setBusy(null);
    },
    [fetchAll, filterByDate, downloadCSV, downloadXLSX, downloadPDF, showToast]
  );

  const exportExpiry = useCallback(
    async (format: 'csv' | 'xlsx' | 'pdf') => {
      setBusy(`expiry-${format}`);
      try {
        const data = await fetchAll();
        const today = new Date().toISOString().slice(0, 10);
        const rows = (data.members as Member[])
          .filter((m) => m.expiry_date && m.expiry_date < today)
          .map((m) => [
            m.name,
            m.member_no ?? '',
            m.mobile ?? '',
            m.category ?? '',
            m.status,
            formatDate(m.start_date),
            formatDate(m.expiry_date),
            formatCurrency(m.due_amount ?? 0),
          ]);
        const headers = [
          'Name',
          'Member No',
          'Mobile',
          'Category',
          'Status',
          'Start Date',
          'Expiry Date',
          'Due Amount',
        ];
        const fn = `Expired-Members-${format}`;
        if (format === 'csv') downloadCSV(fn, headers, rows);
        else if (format === 'xlsx') downloadXLSX(fn, headers, rows);
        else downloadPDF('Expired Members Export', headers, rows);
        showToast('success', `Exported ${rows.length} expired members as ${format.toUpperCase()}`);
      } catch (e: any) {
        showToast('error', `Export failed: ${e.message}`);
      }
      setBusy(null);
    },
    [fetchAll, downloadCSV, downloadXLSX, downloadPDF, showToast]
  );

  const exportReports = useCallback(
    async (format: 'csv' | 'xlsx' | 'pdf') => {
      setBusy(`reports-${format}`);
      try {
        const data = await fetchAll();
        const members = data.members as Member[];
        const payments = data.payments as Payment[];
        const attendance = data.attendance as Attendance[];
        const today = new Date().toISOString().slice(0, 10);
        const month = today.slice(0, 7);
        const year = today.slice(0, 4);

        const summary = [
          ['Total Members', String(members.length)],
          ['Active Members', String(members.filter((m) => m.status === 'active').length)],
          ['Expired Members', String(members.filter((m) => m.status === 'expired').length)],
          ['Due Members', String(members.filter((m) => Number(m.due_amount ?? 0) > 0).length)],
          ['Total Due Amount', formatCurrency(members.reduce((s, m) => s + Number(m.due_amount ?? 0), 0))],
          ["Today's Collection", formatCurrency(payments.filter((p) => p.paid_date.slice(0, 10) === today).reduce((s, p) => s + Number(p.amount), 0))],
          ['Monthly Collection', formatCurrency(payments.filter((p) => p.paid_date.slice(0, 7) === month).reduce((s, p) => s + Number(p.amount), 0))],
          ['Yearly Revenue', formatCurrency(payments.filter((p) => p.paid_date.slice(0, 4) === year).reduce((s, p) => s + Number(p.amount), 0))],
          ['Total Revenue', formatCurrency(payments.reduce((s, p) => s + Number(p.amount), 0))],
          ["Today's Attendance", String(attendance.filter((r) => r.check_in.slice(0, 10) === today).length)],
          ['Total Attendance', String(attendance.length)],
        ];
        const headers = ['Metric', 'Value'];
        const fn = `Dashboard-Report-${format}`;
        if (format === 'csv') downloadCSV(fn, headers, summary);
        else if (format === 'xlsx') downloadXLSX(fn, headers, summary);
        else downloadPDF('Dashboard Reports', headers, summary);
        showToast('success', `Exported dashboard report as ${format.toUpperCase()}`);
      } catch (e: any) {
        showToast('error', `Export failed: ${e.message}`);
      }
      setBusy(null);
    },
    [fetchAll, downloadCSV, downloadXLSX, downloadPDF, showToast]
  );

  /* ---------- Full backup ---------- */

  const fullBackup = useCallback(async () => {
    setBusy('backup');
    try {
      const data = await fetchAll();
      const backup = {
        _meta: {
          app: 'Fit India Gym Pro',
          version: 1,
          exported_at: new Date().toISOString(),
          gym: GYM.name,
          counts: {
            members: data.members.length,
            payments: data.payments.length,
            attendance: data.attendance.length,
            trainers: data.trainers.length,
            inquiries: data.inquiries.length,
            plans: data.plans.length,
            settings: data.settings.length,
          },
        },
        ...data,
      };
      const json = JSON.stringify(backup, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `FitIndia-Backup-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      showToast(
        'success',
        `Full backup created: ${backup._meta.counts.members} members, ${backup._meta.counts.payments} payments, ${backup._meta.counts.attendance} attendance records`
      );
    } catch (e: any) {
      showToast('error', `Backup failed: ${e.message}`);
    }
    setBusy(null);
  }, [fetchAll, showToast]);

  /* ---------- Restore ---------- */

  const restoreBackup = useCallback(
    async (file: File) => {
      setBusy('restore');
      setRestoreStatus('Reading backup file…');
      try {
        const text = await file.text();
        const backup = JSON.parse(text);

        if (!backup._meta || backup._meta.app !== 'Fit India Gym Pro') {
          throw new Error('Invalid backup file format.');
        }

        setRestoreStatus('Restoring members…');
        if (backup.members?.length) {
          const clean = backup.members.map((m: Member) => {
            const { id, ...rest } = m;
            return rest;
          });
          for (const m of clean) {
            await supabase.from('members').upsert(m, { onConflict: 'member_no' });
          }
        }

        setRestoreStatus('Restoring payments…');
        if (backup.payments?.length) {
          for (const p of backup.payments) {
            const { id, ...rest } = p;
            await supabase.from('payments').upsert(rest);
          }
        }

        setRestoreStatus('Restoring attendance…');
        if (backup.attendance?.length) {
          for (const a of backup.attendance) {
            const { id, ...rest } = a;
            await supabase.from('attendance').upsert(rest);
          }
        }

        setRestoreStatus('Restoring trainers…');
        if (backup.trainers?.length) {
          for (const t of backup.trainers) {
            const { id, ...rest } = t;
            await supabase.from('trainers').upsert(rest);
          }
        }

        setRestoreStatus('Restoring inquiries…');
        if (backup.inquiries?.length) {
          for (const i of backup.inquiries) {
            const { id, ...rest } = i;
            await supabase.from('inquiries').upsert(rest);
          }
        }

        setRestoreStatus('Restoring plans…');
        if (backup.plans?.length) {
          for (const p of backup.plans) {
            await supabase.from('plans').upsert(p, { onConflict: 'label' });
          }
        }

        setRestoreStatus('Restoring settings…');
        if (backup.settings?.length) {
          for (const s of backup.settings) {
            await supabase.from('settings').upsert(s, { onConflict: 'key' });
          }
        }

        setRestoreStatus('');
        showToast(
          'success',
          `Restore complete: ${backup._meta.counts.members} members, ${backup._meta.counts.payments} payments, ${backup._meta.counts.attendance} attendance records`
        );
      } catch (e: any) {
        setRestoreStatus('');
        showToast('error', `Restore failed: ${e.message}`);
      }
      setBusy(null);
    },
    [showToast]
  );

  const clearDates = () => {
    setFrom('');
    setTo('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="font-display text-2xl font-bold text-neutral-100">
          Backup & Data Export
        </h1>
        <p className="text-sm text-neutral-500">
          Export gym data, create full backups, and restore from previous backups.
        </p>
      </div>

      {/* Toast */}
      {toast && (
        <div
          className={`flex items-center gap-3 rounded-xl border px-4 py-3 text-sm font-medium animate-fade-in-up ${
            toast.type === 'success'
              ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300'
              : 'border-rose-500/30 bg-rose-500/10 text-rose-300'
          }`}
        >
          <Icon
            name={toast.type === 'success' ? 'CheckCircle2' : 'AlertCircle'}
            className="h-5 w-5 flex-shrink-0"
          />
          {toast.msg}
          <button
            onClick={() => setToast(null)}
            className="ml-auto rounded-lg p-1 hover:bg-ink-700"
          >
            <Icon name="X" className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Date filter */}
      <Card className="p-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h3 className="mb-3 font-display text-sm font-semibold gold-text">
              Date Range Filter
            </h3>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
              <div>
                <label className="label">From Date</label>
                <input
                  type="date"
                  className="input"
                  value={from}
                  onChange={(e) => setFrom(e.target.value)}
                />
              </div>
              <div>
                <label className="label">To Date</label>
                <input
                  type="date"
                  className="input"
                  value={to}
                  onChange={(e) => setTo(e.target.value)}
                />
              </div>
              {(from || to) && (
                <Button variant="ghost" onClick={clearDates}>
                  <Icon name="X" className="h-4 w-4" />
                  Clear
                </Button>
              )}
            </div>
            <p className="mt-2 text-xs text-neutral-500">
              {from || to
                ? `Filtering: ${from || 'Start'} to ${to || 'Today'}`
                : 'No date filter — exporting all records.'}
            </p>
          </div>
        </div>
      </Card>

      {/* Export cards */}
      <div>
        <h2 className="mb-3 text-xs font-bold uppercase tracking-widest text-neutral-500">
          Data Exports
        </h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <ExportCard
            title="Members Data"
            description="All member records with plan, status, and due amounts."
            icon="Users"
            accent="sky"
            busy={busy}
            busyKey="members"
            onExport={exportMembers}
          />
          <ExportCard
            title="Attendance Records"
            description="Check-in records with member names and timestamps."
            icon="ClipboardCheck"
            accent="emerald"
            busy={busy}
            busyKey="attendance"
            onExport={exportAttendance}
          />
          <ExportCard
            title="Payments & Dues"
            description="Payment receipts, amounts, methods, and due balances."
            icon="IndianRupee"
            accent="gold"
            busy={busy}
            busyKey="payments"
            onExport={exportPayments}
          />
          <ExportCard
            title="Expired Memberships"
            description="Members whose memberships have expired."
            icon="AlertCircle"
            accent="rose"
            busy={busy}
            busyKey="expiry"
            onExport={exportExpiry}
          />
          <ExportCard
            title="Dashboard Reports"
            description="Summary metrics: revenue, attendance, member counts."
            icon="BarChart3"
            accent="amber"
            busy={busy}
            busyKey="reports"
            onExport={exportReports}
          />
        </div>
      </div>

      {/* Full backup & restore */}
      <div>
        <h2 className="mb-3 text-xs font-bold uppercase tracking-widest text-neutral-500">
          Full Database Backup & Restore
        </h2>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {/* Backup */}
          <Card className="p-5">
            <div className="flex items-start gap-3">
              <div className="rounded-xl bg-gold-500/10 p-3 text-gold-300">
                <Icon name="Download" className="h-6 w-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-display text-base font-semibold text-neutral-100">
                  One-Click Full Backup
                </h3>
                <p className="mt-1 text-sm text-neutral-500">
                  Download a complete JSON backup of all gym data — members,
                  payments, attendance, trainers, inquiries, plans, and
                  settings. Save it to your device for safekeeping.
                </p>
                <Button
                  variant="gold"
                  className="mt-4 w-full"
                  onClick={fullBackup}
                  disabled={busy === 'backup'}
                >
                  {busy === 'backup' ? (
                    <>
                      <Loading />
                      Creating backup…
                    </>
                  ) : (
                    <>
                      <Icon name="Download" className="h-4 w-4" />
                      Download Full Backup
                    </>
                  )}
                </Button>
              </div>
            </div>
          </Card>

          {/* Restore */}
          <Card className="p-5">
            <div className="flex items-start gap-3">
              <div className="rounded-xl bg-emerald-500/10 p-3 text-emerald-300">
                <Icon name="RefreshCw" className="h-6 w-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-display text-base font-semibold text-neutral-100">
                  Restore from Backup
                </h3>
                <p className="mt-1 text-sm text-neutral-500">
                  Upload a previously downloaded backup file (.json) to restore
                  all gym data. Existing records with matching IDs will be
                  updated.
                </p>
                <input
                  ref={fileRef}
                  type="file"
                  accept=".json,application/json"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) restoreBackup(file);
                    e.target.value = '';
                  }}
                />
                <Button
                  variant="outline"
                  className="mt-4 w-full"
                  onClick={() => fileRef.current?.click()}
                  disabled={busy === 'restore'}
                >
                  {busy === 'restore' ? (
                    <>
                      <Loading />
                      {restoreStatus || 'Restoring…'}
                    </>
                  ) : (
                    <>
                      <Icon name="Upload" className="h-4 w-4" />
                      Upload & Restore
                    </>
                  )}
                </Button>
                {busy === 'restore' && restoreStatus && (
                  <p className="mt-2 text-center text-xs text-emerald-300">
                    {restoreStatus}
                  </p>
                )}
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Info note */}
      <Card className="border-gold-500/20 p-4">
        <div className="flex items-start gap-3">
          <Icon name="Shield" className="mt-0.5 h-5 w-5 flex-shrink-0 text-gold-300" />
          <div className="text-xs text-neutral-500">
            <p className="font-semibold text-neutral-300">Backup Tips</p>
            <ul className="mt-1 space-y-1">
              <li>• Create a full backup at least once a week and before any major changes.</li>
              <li>• Date filters apply to attendance and payment exports only.</li>
              <li>• Restore updates existing records — it does not delete data.</li>
              <li>• Keep backup files in a secure location (Google Drive, email, etc.).</li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
}

/* ---------- Export card component ---------- */

function ExportCard({
  title,
  description,
  icon,
  accent,
  busy,
  busyKey,
  onExport,
}: {
  title: string;
  description: string;
  icon: string;
  accent: 'gold' | 'emerald' | 'sky' | 'rose' | 'amber';
  busy: string | null;
  busyKey: string;
  onExport: (format: 'csv' | 'xlsx' | 'pdf') => void;
}) {
  const accents: Record<string, string> = {
    gold: 'text-gold-300 bg-gold-500/10',
    emerald: 'text-emerald-300 bg-emerald-500/10',
    sky: 'text-sky-300 bg-sky-500/10',
    rose: 'text-rose-300 bg-rose-500/10',
    amber: 'text-amber-300 bg-amber-500/10',
  };
  const isBusy = busy === `${busyKey}-csv` || busy === `${busyKey}-xlsx` || busy === `${busyKey}-pdf`;
  return (
    <Card className="card-hover flex flex-col p-5">
      <div className="flex items-start gap-3">
        <div className={`rounded-xl p-2.5 ${accents[accent]}`}>
          <Icon name={icon as any} className="h-5 w-5" />
        </div>
        <div className="flex-1">
          <h3 className="font-display text-sm font-semibold text-neutral-100">
            {title}
          </h3>
          <p className="mt-1 text-xs text-neutral-500">{description}</p>
        </div>
      </div>
      <div className="mt-4 grid grid-cols-3 gap-2">
        {(['csv', 'xlsx', 'pdf'] as const).map((fmt) => (
          <button
            key={fmt}
            disabled={isBusy}
            onClick={() => onExport(fmt)}
            className={`flex items-center justify-center gap-1 rounded-lg px-2 py-2 text-xs font-semibold transition ${
              fmt === 'pdf'
                ? 'bg-rose-500/10 text-rose-300 hover:bg-rose-500/20'
                : fmt === 'xlsx'
                ? 'bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20'
                : 'bg-sky-500/10 text-sky-300 hover:bg-sky-500/20'
            } disabled:opacity-50`}
          >
            {busy === `${busyKey}-${fmt}` ? (
              <div className="h-3 w-3 animate-spin rounded-full border border-current border-t-transparent" />
            ) : (
              <Icon
                name={fmt === 'pdf' ? 'Printer' : 'Download'}
                className="h-3.5 w-3.5"
              />
            )}
            {fmt.toUpperCase()}
          </button>
        ))}
      </div>
    </Card>
  );
}
