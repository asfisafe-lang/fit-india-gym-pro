import { useMemo } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  useMembers,
  usePayments,
  useAttendance,
} from '../lib/hooks';
import { Card, Loading, StatCard, Icon, Avatar, Badge } from '../components/ui';
import {
  formatCurrency,
  formatDate,
  daysUntil,
  statusBadge,
} from '../lib/utils';
import { GYM } from '../lib/constants';
import { openPrintWindow } from '../lib/print';

const CHART_GOLD = '#e7c454';
const CHART_EMERALD = '#34d399';
const CHART_ROSE = '#fb7185';
const CHART_SKY = '#38bdf8';
const CHART_AMBER = '#fbbf24';
const PIE_COLORS = [CHART_EMERALD, CHART_ROSE, CHART_AMBER, CHART_SKY];

export function ReportsPage() {
  const { members } = useMembers();
  const { payments } = usePayments();
  const { records: attendance } = useAttendance();

  const a = useMemo(() => computeAnalytics(members, payments, attendance), [
    members,
    payments,
    attendance,
  ]);

  if (!members.length && !payments.length)
    return <Loading label="Loading reports…" />;

  return (
    <div className="space-y-6">
      {/* Header + export */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-neutral-100">
            Reports & Analytics
          </h1>
          <p className="text-sm text-neutral-500">
            Comprehensive insights for {GYM.name}.
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => openPrintWindow(generateReportHTML(a, members))}
            className="btn-outline"
          >
            <Icon name="Printer" className="h-4 w-4" />
            PDF Report
          </button>
          <button
            onClick={() => exportExcel(a, members)}
            className="btn-gold"
          >
            <Icon name="Download" className="h-4 w-4" />
            Excel Report
          </button>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        <StatCard
          icon="Users"
          label="Total Members"
          value={a.totalMembers}
          sub={`${a.active} active`}
          accent="sky"
        />
        <StatCard
          icon="CheckCircle2"
          label="Active Members"
          value={a.active}
          sub="currently enrolled"
          accent="emerald"
        />
        <StatCard
          icon="AlertCircle"
          label="Expired Members"
          value={a.expired}
          sub="needs renewal"
          accent="rose"
        />
        <StatCard
          icon="Wallet"
          label="Due Members"
          value={a.dueMembers}
          sub={formatCurrency(a.totalDue)}
          accent="amber"
        />
        <StatCard
          icon="IndianRupee"
          label="Today's Collection"
          value={formatCurrency(a.todayRevenue)}
          sub="collected today"
          accent="gold"
        />
        <StatCard
          icon="CalendarDays"
          label="Monthly Collection"
          value={formatCurrency(a.monthRevenue)}
          sub="this month"
          accent="emerald"
        />
        <StatCard
          icon="TrendingUp"
          label="Total Revenue"
          value={formatCurrency(a.totalRevenue)}
          sub="all-time"
          accent="amber"
        />
        <StatCard
          icon="ClipboardCheck"
          label="Today's Attendance"
          value={a.attendanceToday}
          sub="check-ins today"
          accent="sky"
        />
      </div>

      {/* Membership analytics */}
      <div>
        <h2 className="mb-3 text-xs font-bold uppercase tracking-widest text-neutral-500">
          Membership Analytics
        </h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <MiniStat
            icon="UserPlus"
            label="New Members This Month"
            value={a.newThisMonth}
            accent="emerald"
          />
          <MiniStat
            icon="RefreshCw"
            label="Renewed This Month"
            value={a.renewedThisMonth}
            accent="gold"
          />
          <MiniStat
            icon="AlertCircle"
            label="Expired Memberships"
            value={a.expired}
            accent="rose"
          />
        </div>
      </div>

      {/* Attendance analytics */}
      <div>
        <h2 className="mb-3 text-xs font-bold uppercase tracking-widest text-neutral-500">
          Attendance Analytics
        </h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <MiniStat
            icon="ClipboardCheck"
            label="Today's Attendance"
            value={a.attendanceToday}
            accent="sky"
          />
          <MiniStat
            icon="Calendar"
            label="Weekly Attendance"
            value={a.attendanceWeek}
            accent="emerald"
          />
          <MiniStat
            icon="CalendarDays"
            label="Monthly Attendance"
            value={a.attendanceMonth}
            accent="gold"
          />
        </div>
      </div>

      {/* Revenue analytics */}
      <div>
        <h2 className="mb-3 text-xs font-bold uppercase tracking-widest text-neutral-500">
          Revenue Analytics
        </h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <MiniStat
            icon="IndianRupee"
            label="Daily Revenue"
            value={formatCurrency(a.todayRevenue)}
            accent="gold"
          />
          <MiniStat
            icon="CalendarDays"
            label="Monthly Revenue"
            value={formatCurrency(a.monthRevenue)}
            accent="emerald"
          />
          <MiniStat
            icon="TrendingUp"
            label="Yearly Revenue"
            value={formatCurrency(a.yearRevenue)}
            accent="amber"
          />
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        <Card className="p-5">
          <h3 className="mb-4 font-display text-sm font-semibold gold-text">
            Membership Growth (Last 6 Months)
          </h3>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={a.membershipGrowth}>
              <defs>
                <linearGradient id="gMem" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={CHART_EMERALD} stopOpacity={0.4} />
                  <stop offset="95%" stopColor={CHART_EMERALD} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#2a2a2e" />
              <XAxis dataKey="month" stroke="#888" fontSize={11} />
              <YAxis stroke="#888" fontSize={11} />
              <Tooltip
                contentStyle={{
                  background: '#0a0a0b',
                  border: '1px solid #c8902a',
                  borderRadius: 8,
                }}
              />
              <Area
                type="monotone"
                dataKey="members"
                stroke={CHART_EMERALD}
                fill="url(#gMem)"
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-5">
          <h3 className="mb-4 font-display text-sm font-semibold gold-text">
            Revenue Trend (Last 6 Months)
          </h3>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={a.revenueTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2a2a2e" />
              <XAxis dataKey="month" stroke="#888" fontSize={11} />
              <YAxis stroke="#888" fontSize={11} />
              <Tooltip
                contentStyle={{
                  background: '#0a0a0b',
                  border: '1px solid #c8902a',
                  borderRadius: 8,
                }}
              />
              <Bar
                dataKey="revenue"
                fill={CHART_GOLD}
                radius={[6, 6, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-5">
          <h3 className="mb-4 font-display text-sm font-semibold gold-text">
            Attendance Trend (Last 7 Days)
          </h3>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={a.attendanceTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2a2a2e" />
              <XAxis dataKey="day" stroke="#888" fontSize={11} />
              <YAxis stroke="#888" fontSize={11} />
              <Tooltip
                contentStyle={{
                  background: '#0a0a0b',
                  border: '1px solid #c8902a',
                  borderRadius: 8,
                }}
              />
              <Line
                type="monotone"
                dataKey="checkins"
                stroke={CHART_SKY}
                strokeWidth={2}
                dot={{ fill: CHART_SKY, r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-5">
          <h3 className="mb-4 font-display text-sm font-semibold gold-text">
            Membership Status Distribution
          </h3>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie
                data={a.statusPie}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={80}
                label={({ name, value }) => `${name}: ${value}`}
                labelLine={false}
              >
                {a.statusPie.map((_, i) => (
                  <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  background: '#0a0a0b',
                  border: '1px solid #c8902a',
                  borderRadius: 8,
                }}
              />
              <Legend wrapperStyle={{ fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Quick alerts */}
      <div>
        <h2 className="mb-3 text-xs font-bold uppercase tracking-widest text-neutral-500">
          Quick Alerts
        </h2>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <AlertList
            title="Expiring in 7 Days"
            icon="CalendarDays"
            accent="amber"
            members={a.expiringSoon}
            showExpiry
          />
          <AlertList
            title="Due Payments Pending"
            icon="Wallet"
            accent="rose"
            members={a.dueList}
            showDue
          />
          <AlertList
            title="Not Visiting Recently"
            icon="UserX"
            accent="gold"
            members={a.notVisiting}
            showLastVisit
          />
        </div>
      </div>
    </div>
  );
}

/* ---------- analytics computation ---------- */

type Analytics = ReturnType<typeof computeAnalytics>;

function computeAnalytics(
  members: ReturnType<typeof useMembers>['members'],
  payments: ReturnType<typeof usePayments>['payments'],
  attendance: { member_id: string; check_in: string }[]
) {
  const now = new Date();
  const today = now.toISOString().slice(0, 10);
  const month = today.slice(0, 7);
  const year = today.slice(0, 4);

  const active = members.filter((m) => m.status === 'active').length;
  const expired = members.filter((m) => m.status === 'expired').length;
  const dueList = members.filter((m) => Number(m.due_amount ?? 0) > 0);
  const totalDue = members.reduce((s, m) => s + Number(m.due_amount ?? 0), 0);

  const todayRevenue = payments
    .filter((p) => p.paid_date.slice(0, 10) === today)
    .reduce((s, p) => s + Number(p.amount), 0);
  const monthRevenue = payments
    .filter((p) => p.paid_date.slice(0, 7) === month)
    .reduce((s, p) => s + Number(p.amount), 0);
  const yearRevenue = payments
    .filter((p) => p.paid_date.slice(0, 4) === year)
    .reduce((s, p) => s + Number(p.amount), 0);
  const totalRevenue = payments.reduce((s, p) => s + Number(p.amount), 0);

  const newThisMonth = members.filter(
    (m) => m.created_at.slice(0, 7) === month
  ).length;
  const renewedThisMonth = payments.filter(
    (p) => p.type === 'renewal' && p.paid_date.slice(0, 7) === month
  ).length;

  const weekAgo = new Date(now.getTime() - 7 * 86400000);
  const monthAgo = new Date(now.getTime() - 30 * 86400000);
  const attendanceToday = attendance.filter(
    (r) => r.check_in.slice(0, 10) === today
  ).length;
  const attendanceWeek = attendance.filter(
    (r) => new Date(r.check_in) >= weekAgo
  ).length;
  const attendanceMonth = attendance.filter(
    (r) => new Date(r.check_in) >= monthAgo
  ).length;

  const expiringSoon = members.filter((m) => {
    const d = daysUntil(m.expiry_date);
    return d !== null && d >= 0 && d <= 7 && m.status === 'active';
  });

  // Members not visiting recently (active, no check-in in 14 days)
  const lastVisitByMember = new Map<string, string>();
  for (const r of attendance) {
    const cur = lastVisitByMember.get(r.member_id);
    if (!cur || r.check_in > cur) lastVisitByMember.set(r.member_id, r.check_in);
  }
  const notVisiting = members
    .filter((m) => m.status === 'active')
    .filter((m) => {
      const last = lastVisitByMember.get(m.id);
      if (!last) return true;
      return now.getTime() - new Date(last).getTime() > 14 * 86400000;
    })
    .slice(0, 12);

  // Membership growth — last 6 months
  const membershipGrowth: { month: string; members: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const ym = d.toISOString().slice(0, 7);
    const count = members.filter(
      (m) => m.created_at.slice(0, 7) <= ym
    ).length;
    membershipGrowth.push({
      month: d.toLocaleDateString('en', { month: 'short' }),
      members: count,
    });
  }

  // Revenue trend — last 6 months
  const revenueTrend: { month: string; revenue: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const ym = d.toISOString().slice(0, 7);
    const rev = payments
      .filter((p) => p.paid_date.slice(0, 7) === ym)
      .reduce((s, p) => s + Number(p.amount), 0);
    revenueTrend.push({
      month: d.toLocaleDateString('en', { month: 'short' }),
      revenue: rev,
    });
  }

  // Attendance trend — last 7 days
  const attendanceTrend: { day: string; checkins: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 86400000);
    const ds = d.toISOString().slice(0, 10);
    const count = attendance.filter(
      (r) => r.check_in.slice(0, 10) === ds
    ).length;
    attendanceTrend.push({
      day: d.toLocaleDateString('en', { weekday: 'short' }),
      checkins: count,
    });
  }

  const statusPie = [
    { name: 'Active', value: active },
    { name: 'Expired', value: expired },
    { name: 'Due', value: dueList.length },
    {
      name: 'Other',
      value: Math.max(0, members.length - active - expired - dueList.length),
    },
  ];

  return {
    totalMembers: members.length,
    active,
    expired,
    dueMembers: dueList.length,
    totalDue,
    todayRevenue,
    monthRevenue,
    yearRevenue,
    totalRevenue,
    newThisMonth,
    renewedThisMonth,
    attendanceToday,
    attendanceWeek,
    attendanceMonth,
    expiringSoon,
    dueList,
    notVisiting,
    membershipGrowth,
    revenueTrend,
    attendanceTrend,
    statusPie,
  };
}

/* ---------- export helpers ---------- */

function exportExcel(a: Analytics, members: any[]) {
  const rows: string[][] = [
    ['Metric', 'Value'],
    ['Total Members', String(a.totalMembers)],
    ['Active Members', String(a.active)],
    ['Expired Members', String(a.expired)],
    ['Due Members', String(a.dueMembers)],
    ['Total Due Amount', String(a.totalDue)],
    ["Today's Collection", String(a.todayRevenue)],
    ['Monthly Collection', String(a.monthRevenue)],
    ['Yearly Revenue', String(a.yearRevenue)],
    ['Total Revenue', String(a.totalRevenue)],
    ['New Members This Month', String(a.newThisMonth)],
    ['Renewed This Month', String(a.renewedThisMonth)],
    ["Today's Attendance", String(a.attendanceToday)],
    ['Weekly Attendance', String(a.attendanceWeek)],
    ['Monthly Attendance', String(a.attendanceMonth)],
    ['Expiring in 7 Days', String(a.expiringSoon.length)],
    ['', ''],
    ['Member Name', 'Member No', 'Mobile', 'Status', 'Expiry', 'Due Amount'],
    ...members.map((m) => [
      m.name,
      m.member_no,
      m.mobile,
      m.status,
      m.expiry_date,
      String(m.due_amount ?? 0),
    ]),
  ];
  const csv = rows
    .map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(','))
    .join('\n');
  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `FitIndia-Report-${new Date().toISOString().slice(0, 10)}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

function generateReportHTML(a: Analytics, _members: any[]): string {
  const row = (k: string, v: string) =>
    `<tr><td style="padding:6px 12px;border-bottom:1px solid #eee;color:#666">${k}</td><td style="padding:6px 12px;border-bottom:1px solid #eee;font-weight:700;text-align:right">${v}</td></tr>`;
  return `<!doctype html><html><head><meta charset="utf-8"/><title>Fit India Gym Pro — Report</title>
<style>
  *{font-family:'Segoe UI',Arial,sans-serif;box-sizing:border-box;margin:0;padding:0;}
  body{padding:30px;color:#1a1a1a;}
  h1{color:#c8902a;margin-bottom:4px;}
  .sub{color:#888;font-size:12px;margin-bottom:20px;}
  table{width:100%;border-collapse:collapse;margin-bottom:24px;}
  .sec{font-size:14px;font-weight:700;color:#c8902a;margin:20px 0 8px;border-bottom:2px solid #c8902a;padding-bottom:4px;}
  .grid{display:grid;grid-template-columns:1fr 1fr;gap:0 40px;}
</style></head><body>
  <h1>${GYM.name} — Analytics Report</h1>
  <div class="sub">Generated on ${new Date().toLocaleString()}</div>
  <div class="sec">Summary</div>
  <table>${row('Total Members', String(a.totalMembers))}${row('Active Members', String(a.active))}${row('Expired Members', String(a.expired))}${row('Due Members', String(a.dueMembers))}${row('Total Due Amount', formatCurrency(a.totalDue))}</table>
  <div class="sec">Revenue</div>
  <table>${row("Today's Collection", formatCurrency(a.todayRevenue))}${row('Monthly Collection', formatCurrency(a.monthRevenue))}${row('Yearly Revenue', formatCurrency(a.yearRevenue))}${row('Total Revenue', formatCurrency(a.totalRevenue))}</table>
  <div class="sec">Membership</div>
  <table>${row('New This Month', String(a.newThisMonth))}${row('Renewed This Month', String(a.renewedThisMonth))}${row('Expired', String(a.expired))}</table>
  <div class="sec">Attendance</div>
  <table>${row("Today", String(a.attendanceToday))}${row('This Week', String(a.attendanceWeek))}${row('This Month', String(a.attendanceMonth))}</table>
  <div class="sec">Alerts</div>
  <table>${row('Expiring in 7 Days', String(a.expiringSoon.length))}${row('Due Payments Pending', String(a.dueList.length))}${row('Not Visiting Recently', String(a.notVisiting.length))}</table>
  <div class="sub" style="margin-top:30px;text-align:center">${GYM.name} · ${GYM.address} · ${GYM.mobiles.join(' · ')}</div>
</body></html>`;
}

/* ---------- small components ---------- */

function MiniStat({
  icon,
  label,
  value,
  accent,
}: {
  icon: string;
  label: string;
  value: string | number;
  accent: 'gold' | 'emerald' | 'rose' | 'sky' | 'amber';
}) {
  const accents: Record<string, string> = {
    gold: 'text-gold-300 bg-gold-500/10',
    emerald: 'text-emerald-300 bg-emerald-500/10',
    rose: 'text-rose-300 bg-rose-500/10',
    sky: 'text-sky-300 bg-sky-500/10',
    amber: 'text-amber-300 bg-amber-500/10',
  };
  return (
    <Card className="flex items-center gap-3 p-4">
      <div className={`rounded-xl p-2.5 ${accents[accent]}`}>
        <Icon name={icon as any} className="h-5 w-5" />
      </div>
      <div>
        <p className="text-xs font-medium uppercase tracking-wider text-neutral-500">
          {label}
        </p>
        <p className="mt-0.5 font-display text-xl font-bold text-neutral-100">
          {value}
        </p>
      </div>
    </Card>
  );
}

function AlertList({
  title,
  icon,
  accent,
  members,
  showExpiry = false,
  showDue = false,
  showLastVisit = false,
}: {
  title: string;
  icon: string;
  accent: 'amber' | 'rose' | 'gold';
  members: any[];
  showExpiry?: boolean;
  showDue?: boolean;
  showLastVisit?: boolean;
}) {
  const accents: Record<string, string> = {
    amber: 'text-amber-300 bg-amber-500/10',
    rose: 'text-rose-300 bg-rose-500/10',
    gold: 'text-gold-300 bg-gold-500/10',
  };
  return (
    <Card className="card-hover overflow-hidden">
      <div className="flex items-center gap-2 border-b border-ink-700 px-4 py-3">
        <div className={`rounded-lg p-1.5 ${accents[accent]}`}>
          <Icon name={icon as any} className="h-4 w-4" />
        </div>
        <h3 className="text-sm font-semibold text-neutral-200">{title}</h3>
        <span className="ml-auto rounded-full bg-ink-700 px-2 py-0.5 text-[11px] font-bold text-neutral-300">
          {members.length}
        </span>
      </div>
      {members.length === 0 ? (
        <div className="px-4 py-6 text-center text-xs text-neutral-500">
          All clear — no alerts.
        </div>
      ) : (
        <div className="max-h-64 divide-y divide-ink-700/50 overflow-y-auto">
          {members.slice(0, 8).map((m) => (
            <div
              key={m.id}
              className="flex w-full items-center gap-2 px-4 py-2.5"
            >
              <Avatar photo={m.photo} name={m.name} size="sm" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-neutral-200">
                  {m.name}
                </p>
                <p className="text-[11px] text-neutral-500">
                  {m.member_no} · {m.mobile}
                </p>
              </div>
              {showDue && (
                <span className="text-sm font-bold text-rose-300">
                  {formatCurrency(m.due_amount)}
                </span>
              )}
              {showExpiry && (
                <span className="text-[11px] text-amber-300">
                  exp {formatDate(m.expiry_date)}
                </span>
              )}
              {showLastVisit && (
                <Badge className={statusBadge('inactive')}>inactive</Badge>
              )}
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}
