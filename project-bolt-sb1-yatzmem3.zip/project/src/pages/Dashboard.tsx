import { useMemo } from 'react';
import { GYM } from '../lib/constants';
import {
  useMembers,
  usePayments,
  useInquiries,
  useAttendanceToday,
  useAttendance,
} from '../lib/hooks';
import {
  Card,
  Loading,
  StatCard,
  EmptyState,
  Avatar,
  Badge,
  Icon,
} from '../components/ui';
import {
  formatCurrency,
  formatDate,
  daysUntil,
  statusBadge,
} from '../lib/utils';
import {
  expiryReminderMessage,
  duePaymentReminderMessage,
  openWhatsApp,
} from '../lib/print';
import type { Member } from '../lib/types';

export function DashboardPage({ onNavigate }: { onNavigate: (p: string) => void }) {
  const { members, loading, syncStatuses } = useMembers();
  const { payments } = usePayments();
  const { inquiries } = useInquiries();
  const { records: todaysAttendance } = useAttendanceToday();
  const { records: allAttendance } = useAttendance();
  const allAttendanceCount = allAttendance.length;

  const stats = useMemo(() => {
    const active = members.filter((m) => m.status === 'active').length;
    const expired = members.filter((m) => m.status === 'expired').length;
    const today = new Date().toISOString().slice(0, 10);
    const todayRevenue = payments
      .filter((p) => p.paid_date.slice(0, 10) === today)
      .reduce((s, p) => s + Number(p.amount), 0);
    const monthRevenue = payments
      .filter((p) => p.paid_date.slice(0, 7) === today.slice(0, 7))
      .reduce((s, p) => s + Number(p.amount), 0);
    const totalRevenue = payments.reduce((s, p) => s + Number(p.amount), 0);
    const newInquiries = inquiries.filter((i) => i.status === 'new').length;
    const totalDue = members.reduce((s, m) => s + Number(m.due_amount ?? 0), 0);
    const expiringSoon = members.filter((m) => {
      const d = daysUntil(m.expiry_date);
      return d !== null && d >= 0 && d <= 7 && m.status === 'active';
    });
    const expiredList = members.filter((m) => m.status === 'expired');
    const dueList = members.filter((m) => Number(m.due_amount ?? 0) > 0);

    // Members not visiting recently (active, no check-in in 14 days)
    const lastVisit = new Map<string, string>();
    for (const r of allAttendance) {
      const cur = lastVisit.get(r.member_id);
      if (!cur || r.check_in > cur) lastVisit.set(r.member_id, r.check_in);
    }
    const notVisiting = members
      .filter((m) => m.status === 'active')
      .filter((m) => {
        const lv = lastVisit.get(m.id);
        if (!lv) return true;
        return new Date().getTime() - new Date(lv).getTime() > 14 * 86400000;
      })
      .slice(0, 12);

    return {
      totalMembers: members.length,
      active,
      expired,
      dueMembers: dueList.length,
      todayRevenue,
      monthRevenue,
      totalRevenue,
      newInquiries,
      totalDue,
      expiringSoon,
      expiredList,
      dueList,
      notVisiting,
    };
  }, [members, payments, inquiries, allAttendance]);

  if (loading) return <Loading label="Loading dashboard…" />;

  const recent = [...members]
    .sort(
      (a, b) =>
        new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    )
    .slice(0, 5);

  return (
    <div className="space-y-6">
      <Card className="relative overflow-hidden border-gold-500/30 bg-gradient-to-br from-ink-850 via-ink-900 to-ink-850 p-6 sm:p-8">
        <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-gold-500/10 blur-3xl" />
        <div className="absolute -bottom-12 -left-8 h-40 w-40 rounded-full bg-gold-500/5 blur-3xl" />
        <div className="relative flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="mb-1 text-xs font-semibold uppercase tracking-widest text-gold-300">
              Welcome to
            </p>
            <h1 className="font-display text-3xl font-bold sm:text-4xl">
              <span className="gold-text">{GYM.name}</span>
            </h1>
            <p className="mt-2 flex items-center gap-2 text-sm text-neutral-400">
              <Icon name="Activity" className="h-4 w-4 text-gold-400" />
              {GYM.tagline}
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <button onClick={() => onNavigate('admission')} className="btn-gold">
              <Icon name="UserPlus" className="h-4 w-4" />
              New Admission
            </button>
            <button
              onClick={syncStatuses}
              className="btn-outline"
              title="Mark expired memberships"
            >
              <Icon name="RefreshCw" className="h-4 w-4" />
              Sync Status
            </button>
          </div>
        </div>
        <div className="relative mt-6 grid grid-cols-2 gap-3 text-xs sm:grid-cols-4">
          <InfoChip icon="Clock" label="Gym Timing" value={GYM.gymTiming} />
          <InfoChip icon="Users" label="Ladies Timing" value={GYM.ladiesTiming} />
          <InfoChip icon="Phone" label="Contact" value={GYM.mobiles[0]} />
          <InfoChip icon="MapPin" label="Location" value="Patna-6" />
        </div>
      </Card>

      {/* Member statistics — primary dashboard metrics */}
      <div>
        <h2 className="mb-3 text-xs font-bold uppercase tracking-widest text-neutral-500">
          Member Statistics
        </h2>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <button
            onClick={() => onNavigate('members')}
            className="card card-hover animate-fade-in-up p-5 text-left"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium uppercase tracking-wider text-neutral-500">
                  Total Members
                </p>
                <p className="mt-2 font-display text-2xl font-bold text-neutral-100">
                  {stats.totalMembers}
                </p>
              </div>
              <div className="rounded-xl bg-gold-500/10 p-2.5 text-gold-300">
                <Icon name="Users" className="h-5 w-5" />
              </div>
            </div>
            <p className="mt-1 text-xs text-gold-300">View all members →</p>
          </button>
          <button
            onClick={() => onNavigate('members-active')}
            className="card card-hover animate-fade-in-up p-5 text-left"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium uppercase tracking-wider text-neutral-500">
                  Active Members
                </p>
                <p className="mt-2 font-display text-2xl font-bold text-emerald-300">
                  {stats.active}
                </p>
              </div>
              <div className="rounded-xl bg-emerald-500/10 p-2.5 text-emerald-300">
                <Icon name="CheckCircle2" className="h-5 w-5" />
              </div>
            </div>
            <p className="mt-1 text-xs text-emerald-400/70">
              Currently enrolled
            </p>
          </button>
          <button
            onClick={() => onNavigate('members-expired')}
            className="card card-hover animate-fade-in-up p-5 text-left"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium uppercase tracking-wider text-neutral-500">
                  Expired Members
                </p>
                <p className="mt-2 font-display text-2xl font-bold text-rose-300">
                  {stats.expired}
                </p>
              </div>
              <div className="rounded-xl bg-rose-500/10 p-2.5 text-rose-300">
                <Icon name="AlertCircle" className="h-5 w-5" />
              </div>
            </div>
            <p className="mt-1 text-xs text-rose-400/70">Needs renewal</p>
          </button>
          <button
            onClick={() => onNavigate('members-expiring')}
            className="card card-hover animate-fade-in-up p-5 text-left"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium uppercase tracking-wider text-neutral-500">
                  Expiring Soon
                </p>
                <p className="mt-2 font-display text-2xl font-bold text-orange-300">
                  {stats.expiringSoon.length}
                </p>
              </div>
              <div className="rounded-xl bg-orange-500/10 p-2.5 text-orange-300">
                <Icon name="Clock" className="h-5 w-5" />
              </div>
            </div>
            <p className="mt-1 text-xs text-orange-400/70">Within 7 days</p>
          </button>
          <button
            onClick={() => onNavigate('members-due')}
            className="card card-hover animate-fade-in-up p-5 text-left"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium uppercase tracking-wider text-neutral-500">
                  Due Members
                </p>
                <p className="mt-2 font-display text-2xl font-bold text-amber-300">
                  {stats.dueMembers}
                </p>
              </div>
              <div className="rounded-xl bg-amber-500/10 p-2.5 text-amber-300">
                <Icon name="Wallet" className="h-5 w-5" />
              </div>
            </div>
            <p className="mt-1 text-xs text-amber-400/70">
              {formatCurrency(stats.totalDue)} outstanding
            </p>
          </button>
        </div>
      </div>

      {/* Financial & attendance stats */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          icon="IndianRupee"
          label="Today's Collection"
          value={formatCurrency(stats.todayRevenue)}
          sub="collected today"
          accent="gold"
        />
        <StatCard
          icon="CalendarDays"
          label="Monthly Collection"
          value={formatCurrency(stats.monthRevenue)}
          sub="this month"
          accent="emerald"
        />
        <StatCard
          icon="Wallet"
          label="Total Revenue"
          value={formatCurrency(stats.totalRevenue)}
          sub="all-time"
          accent="amber"
        />
        <StatCard
          icon="ClipboardCheck"
          label="Today's Attendance"
          value={todaysAttendance.length}
          sub="check-ins today"
          accent="sky"
        />
        <StatCard
          icon="History"
          label="Total Attendance"
          value={allAttendanceCount}
          sub="all-time check-ins"
          accent="emerald"
        />
        <StatCard
          icon="Wallet"
          label="Total Due Amount"
          value={formatCurrency(stats.totalDue)}
          sub={`${stats.dueList.length} members with dues`}
          accent="rose"
        />
        <StatCard
          icon="PhoneCall"
          label="New Inquiries"
          value={stats.newInquiries}
          sub="awaiting follow-up"
          accent="amber"
        />
      </div>

      {(stats.expiringSoon.length > 0 ||
        stats.expiredList.length > 0 ||
        stats.dueList.length > 0) && (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <AlertCard
            title="Expiring This Week"
            icon="CalendarDays"
            accent="amber"
            members={stats.expiringSoon}
            emptyText="No memberships expiring soon."
            onNavigate={onNavigate}
            navigateTo="members-expiring"
            reminderType="expiry"
          />
          <AlertCard
            title="Expired Memberships"
            icon="AlertCircle"
            accent="rose"
            members={stats.expiredList}
            emptyText="No expired memberships."
            onNavigate={onNavigate}
            navigateTo="members-expired"
          />
          <AlertCard
            title="Due Payments"
            icon="Wallet"
            accent="gold"
            members={stats.dueList}
            showDue
            emptyText="No due payments."
            onNavigate={onNavigate}
            navigateTo="members-due"
            reminderType="due"
          />
          <AlertCard
            title="Not Visiting Recently"
            icon="UserX"
            accent="rose"
            members={stats.notVisiting}
            emptyText="All members are active."
            onNavigate={onNavigate}
            navigateTo="members-active"
          />
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between border-b border-ink-700 px-5 py-4">
            <h3 className="font-display text-base font-semibold text-neutral-100">
              Recent Admissions
            </h3>
            <button
              onClick={() => onNavigate('members')}
              className="text-xs font-semibold text-gold-300 hover:text-gold-200"
            >
              View all →
            </button>
          </div>
          {recent.length === 0 ? (
            <EmptyState
              icon="UserPlus"
              title="No members yet"
              description="Add your first member to get started."
              action={
                <button onClick={() => onNavigate('admission')} className="btn-gold">
                  <Icon name="UserPlus" className="h-4 w-4" />
                  New Admission
                </button>
              }
            />
          ) : (
            <div className="divide-y divide-ink-700/60">
              {recent.map((m) => (
                <div
                  key={m.id}
                  className="flex items-center gap-3 px-5 py-3 table-row-hover"
                >
                  <Avatar photo={m.photo} name={m.name} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-neutral-200">
                      {m.name}
                    </p>
                    <p className="text-xs text-neutral-500">
                      {m.member_no} · {m.category} · {m.duration_months}M
                    </p>
                  </div>
                  <div className="text-right">
                    <Badge className={statusBadge(m.status)}>{m.status}</Badge>
                    <p className="mt-1 text-[11px] text-neutral-500">
                      {formatDate(m.start_date)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card>
          <div className="flex items-center justify-between border-b border-ink-700 px-5 py-4">
            <h3 className="font-display text-base font-semibold text-neutral-100">
              New Inquiries
            </h3>
            <button
              onClick={() => onNavigate('inquiries')}
              className="text-xs font-semibold text-gold-300 hover:text-gold-200"
            >
              View →
            </button>
          </div>
          {inquiries.filter((i) => i.status === 'new').length === 0 ? (
            <EmptyState
              icon="PhoneCall"
              title="No new inquiries"
              description="Walk-in inquiries will appear here."
            />
          ) : (
            <div className="divide-y divide-ink-700/60">
              {inquiries
                .filter((i) => i.status === 'new')
                .slice(0, 5)
                .map((i) => (
                  <div
                    key={i.id}
                    className="flex items-center gap-3 px-5 py-3 table-row-hover"
                  >
                    <div className="rounded-lg bg-ink-800 p-2 text-sky-300">
                      <Icon name="PhoneCall" className="h-4 w-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-neutral-200">
                        {i.name}
                      </p>
                      <p className="text-xs text-neutral-500">{i.mobile}</p>
                    </div>
                    <Badge className={statusBadge('new')}>new</Badge>
                  </div>
                ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

function InfoChip({
  icon,
  label,
  value,
}: {
  icon: string;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-xl border border-ink-700 bg-ink-900/50 px-3 py-2">
      <p className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-neutral-500">
        <Icon name={icon as any} className="h-3 w-3" />
        {label}
      </p>
      <p className="mt-0.5 truncate text-xs font-semibold text-neutral-200">
        {value}
      </p>
    </div>
  );
}

function AlertCard({
  title,
  icon,
  accent,
  members,
  emptyText,
  showDue = false,
  onNavigate,
  navigateTo = 'members',
  reminderType,
}: {
  title: string;
  icon: string;
  accent: 'amber' | 'rose' | 'gold';
  members: Member[];
  emptyText: string;
  showDue?: boolean;
  onNavigate: (p: string) => void;
  navigateTo?: string;
  reminderType?: 'expiry' | 'due';
}) {
  const accents: Record<string, string> = {
    amber: 'text-amber-300 bg-amber-500/10',
    rose: 'text-rose-300 bg-rose-500/10',
    gold: 'text-gold-300 bg-gold-500/10',
  };
  const sendReminder = (m: Member) => {
    const msg = reminderType === 'due'
      ? duePaymentReminderMessage(m)
      : expiryReminderMessage(m);
    openWhatsApp(m.mobile, msg);
  };
  return (
    <Card className="card-hover overflow-hidden">
      <div className="flex items-center gap-2 border-b border-ink-700 px-4 py-3">
        <div className={`rounded-lg p-1.5 ${accents[accent]}`}>
          <Icon name={icon as any} className="h-4 w-4" />
        </div>
        <h3 className="text-sm font-semibold text-neutral-200">{title}</h3>
        <span className="ml-auto rounded-full bg-ink-700 px-2 py-0.5 text-[11px] font-bold text-neutral-300">
          {members.length}
        </span>
      </div>
      {members.length === 0 ? (
        <div className="px-4 py-6 text-center text-xs text-neutral-500">
          {emptyText}
        </div>
      ) : (
        <div className="max-h-64 divide-y divide-ink-700/50 overflow-y-auto">
          {members.slice(0, 8).map((m) => (
            <div
              key={m.id}
              className="flex w-full items-center gap-2 px-4 py-2.5 table-row-hover"
            >
              <button
                onClick={() => onNavigate(navigateTo)}
                className="flex min-w-0 flex-1 items-center gap-2 text-left"
              >
                <Avatar photo={m.photo} name={m.name} size="sm" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-neutral-200">
                    {m.name}
                  </p>
                  <p className="text-[11px] text-neutral-500">
                    {m.member_no} · {m.mobile}
                  </p>
                </div>
                {showDue ? (
                  <span className="text-sm font-bold text-rose-300">
                    {formatCurrency(m.due_amount)}
                  </span>
                ) : (
                  <span className="text-[11px] text-neutral-500">
                    exp {formatDate(m.expiry_date)}
                  </span>
                )}
              </button>
              {reminderType && (
                <button
                  onClick={() => sendReminder(m)}
                  title="Send WhatsApp reminder"
                  className="flex-shrink-0 rounded-lg bg-emerald-500/10 p-1.5 text-emerald-300 transition hover:bg-emerald-500/20"
                >
                  <Icon name="MessageCircle" className="h-4 w-4" />
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}
