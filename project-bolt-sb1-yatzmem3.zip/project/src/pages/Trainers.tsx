import { useMemo, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useTrainers } from '../lib/hooks';
import {
  Card,
  Icon,
  Button,
  Loading,
  EmptyState,
  Avatar,
  Badge,
  Modal,
} from '../components/ui';
import { GYM } from '../lib/constants';
import type { Trainer } from '../lib/types';

const emptyForm = () => ({
  name: '',
  gender: 'Male' as 'Male' | 'Female',
  specialization: '',
  mobile: '',
  timing: '',
});

export function TrainersPage() {
  const { trainers, loading, reload } = useTrainers();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Trainer | null>(null);
  const [form, setForm] = useState(emptyForm());
  const [saving, setSaving] = useState(false);

  const stats = useMemo(() => {
    return {
      total: trainers.length,
      male: trainers.filter((t) => t.gender === 'Male' && t.is_active).length,
      female: trainers.filter((t) => t.gender === 'Female' && t.is_active)
        .length,
    };
  }, [trainers]);

  const submit = async () => {
    if (!form.name.trim()) {
      alert('Name is required.');
      return;
    }
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        gender: form.gender,
        specialization: form.specialization.trim() || null,
        mobile: form.mobile.trim() || null,
        timing: form.timing.trim() || null,
        is_active: true,
      };
      if (editing) {
        const { error } = await supabase
          .from('trainers')
          .update(payload)
          .eq('id', editing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('trainers').insert(payload);
        if (error) throw error;
      }
      reload();
      setOpen(false);
      setEditing(null);
      setForm(emptyForm());
    } catch (e: any) {
      alert(e.message);
    } finally {
      setSaving(false);
    }
  };

  const toggleActive = async (t: Trainer) => {
    const { error } = await supabase
      .from('trainers')
      .update({ is_active: !t.is_active })
      .eq('id', t.id);
    if (error) alert(error.message);
    else reload();
  };

  const remove = async (t: Trainer) => {
    if (!confirm(`Delete trainer ${t.name}?`)) return;
    const { error } = await supabase.from('trainers').delete().eq('id', t.id);
    if (error) alert(error.message);
    else reload();
  };

  const openEdit = (t: Trainer) => {
    setEditing(t);
    setForm({
      name: t.name,
      gender: (t.gender ?? 'Male') as 'Male' | 'Female',
      specialization: t.specialization ?? '',
      mobile: t.mobile ?? '',
      timing: t.timing ?? '',
    });
    setOpen(true);
  };

  if (loading) return <Loading label="Loading trainers…" />;

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-neutral-100">
            Trainer Management
          </h1>
          <p className="text-sm text-neutral-500">
            {stats.total} trainers · {stats.male} male · {stats.female} female
          </p>
        </div>
        <Button
          variant="gold"
          onClick={() => {
            setEditing(null);
            setForm(emptyForm());
            setOpen(true);
          }}
        >
          <Icon name="Plus" className="h-4 w-4" />
          Add Trainer
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {trainers.length === 0 ? (
          <Card className="lg:col-span-2">
            <EmptyState
              icon="Dumbbell"
              title="No trainers yet"
              description="Add male and female trainers to manage your team."
            />
          </Card>
        ) : (
          trainers.map((t) => (
            <Card key={t.id} className="card-hover p-5">
              <div className="flex items-start gap-4">
                <Avatar name={t.name} size="lg" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h3 className="truncate font-display text-lg font-semibold text-neutral-100">
                        {t.name}
                      </h3>
                      <p className="text-sm text-neutral-500">
                        {t.specialization ?? 'General Fitness'}
                      </p>
                    </div>
                    <Badge
                      className={
                        t.is_active
                          ? 'border border-emerald-500/30 bg-emerald-500/15 text-emerald-300'
                          : 'border border-neutral-500/30 bg-neutral-500/15 text-neutral-400'
                      }
                    >
                      {t.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                  <div className="mt-3 space-y-1.5 text-sm">
                    <p className="flex items-center gap-2 text-neutral-400">
                      <Icon
                        name="User"
                        className={`h-4 w-4 ${
                          t.gender === 'Female' ? 'text-rose-400' : 'text-sky-400'
                        }`}
                      />
                      {t.gender}
                    </p>
                    {t.mobile && (
                      <a
                        href={`tel:${t.mobile}`}
                        className="flex items-center gap-2 text-neutral-400 hover:text-gold-200"
                      >
                        <Icon name="Phone" className="h-4 w-4 text-gold-400" />
                        {t.mobile}
                      </a>
                    )}
                    {t.timing && (
                      <p className="flex items-center gap-2 text-neutral-400">
                        <Icon name="Clock" className="h-4 w-4 text-gold-400" />
                        {t.timing}
                      </p>
                    )}
                  </div>
                  <div className="mt-4 flex gap-2">
                    <Button
                      variant="ghost"
                      className="px-3 py-1.5 text-xs"
                      onClick={() => openEdit(t)}
                    >
                      <Icon name="Pencil" className="h-3.5 w-3.5" />
                      Edit
                    </Button>
                    <Button
                      variant="ghost"
                      className="px-3 py-1.5 text-xs"
                      onClick={() => toggleActive(t)}
                    >
                      <Icon
                        name={t.is_active ? 'XCircle' : 'CheckCircle2'}
                        className="h-3.5 w-3.5"
                      />
                      {t.is_active ? 'Deactivate' : 'Activate'}
                    </Button>
                    <Button
                      variant="ghost"
                      className="px-3 py-1.5 text-xs text-rose-300 hover:text-rose-200"
                      onClick={() => remove(t)}
                    >
                      <Icon name="Trash2" className="h-3.5 w-3.5" />
                      Delete
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ))
        )}
      </div>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? 'Edit Trainer' : 'Add Trainer'}
        size="md"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Name *</label>
              <input
                className="input"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Trainer name"
              />
            </div>
            <div>
              <label className="label">Gender</label>
              <select
                className="input"
                value={form.gender}
                onChange={(e) =>
                  setForm({ ...form, gender: e.target.value as 'Male' | 'Female' })
                }
              >
                <option value="Male">Male Trainer</option>
                <option value="Female">Female Trainer</option>
              </select>
            </div>
            <div className="col-span-2">
              <label className="label">Specialization</label>
              <input
                className="input"
                value={form.specialization}
                onChange={(e) =>
                  setForm({ ...form, specialization: e.target.value })
                }
                placeholder="e.g. Strength, CrossFit, Weight Loss"
              />
            </div>
            <div>
              <label className="label">Mobile</label>
              <input
                className="input"
                value={form.mobile}
                onChange={(e) => setForm({ ...form, mobile: e.target.value })}
                placeholder="10-digit"
                inputMode="numeric"
              />
            </div>
            <div>
              <label className="label">Timing</label>
              <input
                className="input"
                value={form.timing}
                onChange={(e) => setForm({ ...form, timing: e.target.value })}
                placeholder="e.g. 6 AM - 12 PM, Ladies 11-4:30"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 border-t border-ink-700 pt-4">
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button variant="gold" onClick={submit} disabled={saving}>
              {saving ? <Loading /> : <Icon name="Save" className="h-4 w-4" />}
              {editing ? 'Save Changes' : 'Add Trainer'}
            </Button>
          </div>
          <p className="text-center text-xs text-neutral-600">
            {GYM.name} · {GYM.tagline}
          </p>
        </div>
      </Modal>
    </div>
  );
}
