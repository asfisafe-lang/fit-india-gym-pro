import { useMemo, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useMembers, usePayments, usePlans, useAttendance } from '../lib/hooks';
import { PhotoUpload } from '../components/PhotoCapture';
import { IDCardPreview } from '../components/IDCardPreview';
import QRCode from 'qrcode';
import {
  Card,
  Icon,
  Button,
  Loading,
  EmptyState,
  Avatar,
  Badge,
  Modal,
  StatCard,
} from '../components/ui';
import {
  formatCurrency,
  formatDate,
  formatDateTime,
  daysUntil,
  statusBadge,
  generateReceiptNo,
} from '../lib/utils';
import {
  openPrintWindow,
  generateReceiptHTML,
  generateAdmissionFormHTML,
  generateIDCardHTML,
  receiptWhatsAppMessage,
  renewalWhatsAppMessage,
  idCardWhatsAppMessage,
  openWhatsApp,
} from '../lib/print';
import type { Member, Payment, Plan } from '../lib/types';
import type { Role } from '../lib/constants';

export function MemberProfilePage({
  role,
  onNavigate,
  query,
}: {
  role: Role;
  onNavigate: (p: string) => void;
  query: string;
}) {
  const { members, loading, reload } = useMembers();
  const { payments } = usePayments();
  const { plans } = usePlans();
  const memberId = useMemo(() => {
    const params = new URLSearchParams(query);
    return params.get('id');
  }, [query]);

  const member = useMemo(
    () => members.find((m) => m.id === memberId) ?? null,
    [members, memberId]
  );

  const memberPayments = useMemo(
    () => payments.filter((p) => p.member_id === memberId),
    [payments, memberId]
  );

  const { records: allAttendance } = useAttendance();
  const memberAttendance = useMemo(
    () => allAttendance.filter((a) => a.member_id === memberId),
    [allAttendance, memberId]
  );
  const totalDaysAttended = memberAttendance.length;
  const lastAttendanceDate = memberAttendance[0]?.check_in ?? null;

  const [editing, setEditing] = useState(false);
  const [renewing, setRenewing] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [showCard, setShowCard] = useState(false);
  const [cardQr, setCardQr] = useState('');
  const [cardSaved, setCardSaved] = useState(false);

  if (loading) return <Loading label="Loading member profile…" />;

  if (!member) {
    return (
      <div className="mx-auto max-w-md">
        <Card>
          <EmptyState
            icon="Users"
            title="Member not found"
            description="This member may have been deleted."
            action={
              <Button variant="outline" onClick={() => onNavigate('members')}>
                <Icon name="ArrowLeft" className="h-4 w-4" />
                Back to Members
              </Button>
            }
          />
        </Card>
      </div>
    );
  }

  const expiryDays = daysUntil(member.expiry_date);
  const isSuperAdmin = role === 'Super Admin';

  const doDelete = async () => {
    setDeleting(true);
    const { error } = await supabase.from('members').delete().eq('id', member.id);
    setDeleting(false);
    if (error) {
      alert(error.message);
      return;
    }
    onNavigate('members');
  };

  return (
    <div className="space-y-5">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-neutral-500">
        <button
          onClick={() => onNavigate('members')}
          className="flex items-center gap-1 hover:text-gold-200"
        >
          <Icon name="ArrowLeft" className="h-4 w-4" />
          Members
        </button>
        <Icon name="ChevronRight" className="h-3 w-3" />
        <span className="text-neutral-300">{member.name}</span>
      </div>

      {/* Profile header */}
      <Card className="relative overflow-hidden border-gold-500/30 bg-gradient-to-br from-ink-850 via-ink-900 to-ink-850 p-6">
        <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-gold-500/10 blur-3xl" />
        <div className="relative flex flex-col gap-5 sm:flex-row sm:items-start">
          <Avatar
            photo={member.photo}
            name={member.name}
            size="lg"
          />
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="font-display text-2xl font-bold text-neutral-100">
                {member.name}
              </h1>
              <Badge className={statusBadge(member.status)}>
                {member.status}
              </Badge>
              {Number(member.due_amount ?? 0) > 0 && (
                <Badge className="border border-rose-500/30 bg-rose-500/15 text-rose-300">
                  Due {formatCurrency(member.due_amount)}
                </Badge>
              )}
            </div>
            <p className="mt-1 flex items-center gap-2 text-sm text-neutral-500">
              <Icon name="BadgeCheck" className="h-4 w-4 text-gold-400" />
              Member ID: <span className="font-mono text-gold-300">
                {member.member_no}
              </span>
            </p>
            <div className="mt-3 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
              <HeaderStat
                label="Plan"
                value={`${member.category} ${member.duration_months}M`}
                icon="IndianRupee"
              />
              <HeaderStat
                label="Start Date"
                value={formatDate(member.start_date)}
                icon="CalendarDays"
              />
              <HeaderStat
                label="Expiry"
                value={formatDate(member.expiry_date)}
                icon="Clock"
              />
              <HeaderStat
                label={expiryDays !== null && expiryDays >= 0 ? 'Days Left' : 'Status'}
                value={
                  expiryDays !== null
                    ? expiryDays >= 0
                      ? `${expiryDays} days`
                      : `${Math.abs(expiryDays)} days ago`
                    : '—'
                }
                icon="Activity"
              />
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="gold" onClick={() => setRenewing(true)}>
              <Icon name="RefreshCw" className="h-4 w-4" />
              Renew
            </Button>
            <Button variant="outline" onClick={() => setEditing(true)}>
              <Icon name="Pencil" className="h-4 w-4" />
              Edit
            </Button>
            {isSuperAdmin && (
              <Button variant="danger" onClick={() => setConfirmDelete(true)}>
                <Icon name="Trash2" className="h-4 w-4" />
                Delete
              </Button>
            )}
          </div>
        </div>
      </Card>

      {/* Quick actions */}
      <div className="flex flex-wrap gap-2">
        <Button
          variant="outline"
          onClick={async () => {
            const payload = JSON.stringify({
              id: member.id,
              name: member.name,
              member_no: member.member_no,
            });
            try {
              const qr = await QRCode.toDataURL(payload, {
                width: 200,
                margin: 1,
                color: { dark: '#0a0a0b', light: '#ffffff' },
              });
              setCardQr(qr);
            } catch {
              setCardQr('');
            }
            setCardSaved(false);
            setShowCard(true);
          }}
        >
          <Icon name="BadgeCheck" className="h-4 w-4" />
          Membership ID Card
        </Button>
        <Button
          variant="outline"
          onClick={() =>
            openPrintWindow(generateAdmissionFormHTML(member, {}))
          }
        >
          <Icon name="FileText" className="h-4 w-4" />
          Admission Form PDF
        </Button>
        {memberPayments.length > 0 && (
          <Button
            variant="outline"
            onClick={() =>
              openPrintWindow(
                generateReceiptHTML(memberPayments[0], member, {})
              )
            }
          >
            <Icon name="Download" className="h-4 w-4" />
            Latest Receipt
          </Button>
        )}
      </div>

      {/* Details grid */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        <Card className="p-5">
          <h3 className="mb-4 font-display text-sm font-semibold gold-text">
            Personal Details
          </h3>
          <div className="space-y-3">
            <DetailRow label="Full Name" value={member.name} />
            <DetailRow label="Father Name" value={member.father_name} />
            <DetailRow label="Gender" value={member.gender} />
            <DetailRow label="Date of Birth" value={formatDate(member.date_of_birth)} />
            <DetailRow label="Mobile" value={member.mobile} />
            <DetailRow label="Emergency Contact" value={member.emergency_contact} />
            <DetailRow label="Address" value={member.address} />
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="mb-4 font-display text-sm font-semibold gold-text">
            Membership Details
          </h3>
          <div className="space-y-3">
            <DetailRow
              label="Plan"
              value={`${member.category} · ${member.duration_months} Months`}
            />
            <DetailRow label="Plan Price" value={formatCurrency(member.plan_price)} />
            <DetailRow
              label="Registration Fee"
              value={formatCurrency(member.registration_fee)}
            />
            <DetailRow label="Start Date" value={formatDate(member.start_date)} />
            <DetailRow label="Expiry Date" value={formatDate(member.expiry_date)} />
            <DetailRow
              label="Due Amount"
              value={formatCurrency(member.due_amount)}
              highlight={Number(member.due_amount ?? 0) > 0}
            />
            <DetailRow label="Status" value={member.status} />
          </div>
        </Card>
      </div>

      {/* Health info */}
      <Card className="p-5">
        <h3 className="mb-4 font-display text-sm font-semibold gold-text">
          Health Information
        </h3>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="rounded-xl border border-ink-700 bg-ink-900/40 p-4">
            <p className="text-[11px] uppercase tracking-wider text-neutral-500">
              Medical Condition
            </p>
            <p className="mt-1 text-sm text-neutral-200">
              {member.medical_condition || 'None reported'}
            </p>
          </div>
          <div className="rounded-xl border border-ink-700 bg-ink-900/40 p-4">
            <p className="text-[11px] uppercase tracking-wider text-neutral-500">
              Cardio Notes
            </p>
            <p className="mt-1 text-sm text-neutral-200">
              {member.cardio_notes || 'None reported'}
            </p>
          </div>
          <div className="rounded-xl border border-gold-500/30 bg-gold-500/5 p-4 sm:col-span-2">
            <p className="text-[11px] uppercase tracking-wider text-gold-300">
              Declaration
            </p>
            <p className="mt-1 text-sm text-neutral-400">
              {member.declaration_accepted
                ? '✓ Accepted — I confirm that I am joining the gym voluntarily and understand that exercise involves physical risk. The gym management shall not be responsible for any injury, illness, loss or damage arising during training.'
                : 'Not accepted'}
            </p>
          </div>
        </div>
      </Card>

      {/* Attendance summary */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-2">
        <StatCard
          icon="ClipboardCheck"
          label="Total Days Attended"
          value={totalDaysAttended}
          accent="emerald"
        />
        <StatCard
          icon="CalendarDays"
          label="Last Attendance"
          value={lastAttendanceDate ? formatDate(lastAttendanceDate) : '—'}
          accent="sky"
        />
      </div>

      {/* Payment history */}
      <Card className="overflow-hidden">
        <div className="flex items-center justify-between border-b border-ink-700 px-5 py-4">
          <h3 className="font-display text-base font-semibold text-neutral-100">
            Payment History
          </h3>
          <Badge className="border border-gold-500/30 bg-gold-500/15 text-gold-300">
            {memberPayments.length} payments
          </Badge>
        </div>
        {memberPayments.length === 0 ? (
          <EmptyState
            icon="IndianRupee"
            title="No payments"
            description="No payment records for this member yet."
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-ink-700 bg-ink-900/50 text-left text-xs uppercase tracking-wider text-neutral-500">
                <tr>
                  <th className="px-4 py-3 font-semibold">Receipt</th>
                  <th className="hidden px-4 py-3 font-semibold sm:table-cell">
                    Date
                  </th>
                  <th className="hidden px-4 py-3 font-semibold sm:table-cell">
                    Method
                  </th>
                  <th className="px-4 py-3 font-semibold">Type</th>
                  <th className="px-4 py-3 font-semibold">Amount</th>
                  <th className="px-4 py-3 text-right font-semibold">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-700/50">
                {memberPayments.map((p) => (
                  <tr key={p.id} className="table-row-hover">
                    <td className="px-4 py-3 font-mono text-xs text-gold-300">
                      {p.receipt_no}
                    </td>
                    <td className="hidden px-4 py-3 text-neutral-400 sm:table-cell">
                      {formatDateTime(p.paid_date)}
                    </td>
                    <td className="hidden px-4 py-3 sm:table-cell">
                      <span className="text-xs text-neutral-400">
                        {p.method ?? 'Cash'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <Badge
                        className={
                          p.type === 'registration'
                            ? 'border border-gold-500/30 bg-gold-500/15 text-gold-300'
                            : 'border border-emerald-500/30 bg-emerald-500/15 text-emerald-300'
                        }
                      >
                        {p.type}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 font-bold text-neutral-100">
                      {formatCurrency(p.amount)}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() =>
                          openPrintWindow(
                            generateReceiptHTML(p, member, {})
                          )
                        }
                        className="rounded-lg p-2 text-neutral-400 hover:bg-ink-700 hover:text-gold-200"
                        title="View Receipt"
                      >
                        <Icon name="Download" className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() =>
                          openWhatsApp(
                            member.mobile,
                            p.type === 'renewal'
                              ? renewalWhatsAppMessage(p, member)
                              : receiptWhatsAppMessage(p, member)
                          )
                        }
                        className="rounded-lg p-2 text-neutral-400 hover:bg-emerald-500/10 hover:text-emerald-300"
                        title="Share on WhatsApp"
                      >
                        <Icon name="MessageCircle" className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Edit modal */}
      {editing && (
        <Modal
          open
          onClose={() => setEditing(false)}
          title="Edit Member"
          size="lg"
        >
          <EditMemberForm
            member={member}
            onCancel={() => setEditing(false)}
            onSaved={() => {
              setEditing(false);
              reload();
            }}
          />
        </Modal>
      )}

      {/* Renewal modal */}
      {renewing && (
        <Modal
          open
          onClose={() => setRenewing(false)}
          title={`Renew ${member.name}`}
          size="md"
        >
          <RenewalForm
            member={member}
            plans={plans}
            onClose={() => setRenewing(false)}
            onDone={() => {
              setRenewing(false);
              reload();
            }}
          />
        </Modal>
      )}

      {/* Delete confirmation */}
      {confirmDelete && (
        <Modal
          open
          onClose={() => setConfirmDelete(false)}
          title="Delete Member"
          size="sm"
        >
          <div className="space-y-4">
            <div className="flex flex-col items-center gap-3 py-2 text-center">
              <div className="rounded-full bg-rose-500/15 p-3 text-rose-300">
                <Icon name="Trash2" className="h-8 w-8" />
              </div>
              <p className="text-sm text-neutral-300">
                Permanently delete{' '}
                <span className="font-bold text-neutral-100">{member.name}</span>{' '}
                ({member.member_no})?
              </p>
              <p className="text-xs text-neutral-500">
                All payment records for this member will also be removed. This
                cannot be undone.
              </p>
            </div>
            <div className="rounded-lg border border-gold-500/20 bg-gold-500/5 px-3 py-2 text-center text-[11px] text-gold-200">
              <Icon name="Crown" className="mr-1 inline h-3.5 w-3.5" />
              Super Admin authorization required for deletion.
            </div>
            <div className="flex justify-end gap-2 border-t border-ink-700 pt-4">
              <Button variant="ghost" onClick={() => setConfirmDelete(false)}>
                Cancel
              </Button>
              <Button variant="danger" onClick={doDelete} disabled={deleting}>
                {deleting ? <Loading /> : <Icon name="Trash2" className="h-4 w-4" />}
                Delete Permanently
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {showCard && (
        <Modal
          open
          onClose={() => setShowCard(false)}
          title="Membership ID Card"
          size="md"
        >
          <div className="space-y-4">
            <IDCardPreview member={member} />

            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              <Button
                variant="gold"
                onClick={() => openPrintWindow(generateIDCardHTML(member, cardQr))}
              >
                <Icon name="Printer" className="h-4 w-4" />
                Print
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  const html = generateIDCardHTML(member, cardQr);
                  const blob = new Blob([html], { type: 'text/html' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `ID-Card-${member.member_no ?? member.name}.html`;
                  a.click();
                  URL.revokeObjectURL(url);
                }}
              >
                <Icon name="Download" className="h-4 w-4" />
                PDF
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  const html = generateIDCardHTML(member, cardQr);
                  const blob = new Blob([html], { type: 'text/html' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `ID-Card-${member.member_no ?? member.name}.html`;
                  a.click();
                  URL.revokeObjectURL(url);
                  setCardSaved(true);
                  setTimeout(() => setCardSaved(false), 2500);
                }}
              >
                <Icon name="Save" className="h-4 w-4" />
                {cardSaved ? 'Saved!' : 'Save'}
              </Button>
              <Button
                variant="outline"
                onClick={() =>
                  openWhatsApp(member.mobile, idCardWhatsAppMessage(member))
                }
              >
                <Icon name="MessageCircle" className="h-4 w-4" />
                WhatsApp
              </Button>
            </div>
            <p className="text-center text-xs text-neutral-500">
              Card auto-updates when membership is renewed — plan, expiry, and
              status reflect the latest record.
            </p>
          </div>
        </Modal>
      )}
    </div>
  );
}

function HeaderStat({
  label,
  value,
  icon,
}: {
  label: string;
  value: string;
  icon: string;
}) {
  return (
    <div className="rounded-lg border border-ink-700 bg-ink-900/50 px-3 py-2">
      <p className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-neutral-500">
        <Icon name={icon as any} className="h-3 w-3" />
        {label}
      </p>
      <p className="mt-0.5 truncate text-sm font-semibold text-neutral-200">
        {value}
      </p>
    </div>
  );
}

function DetailRow({
  label,
  value,
  highlight,
}: {
  label: string;
  value: string | null | undefined;
  highlight?: boolean;
}) {
  return (
    <div className="flex justify-between gap-4 border-b border-ink-700/50 pb-2">
      <span className="text-xs uppercase tracking-wider text-neutral-500">
        {label}
      </span>
      <span
        className={`text-sm font-medium ${
          highlight ? 'text-rose-300' : 'text-neutral-200'
        }`}
      >
        {value || '—'}
      </span>
    </div>
  );
}

function EditMemberForm({
  member,
  onCancel,
  onSaved,
}: {
  member: Member;
  onCancel: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState({
    name: member.name ?? '',
    father_name: member.father_name ?? '',
    gender: member.gender ?? 'Male',
    date_of_birth: member.date_of_birth ?? '',
    mobile: member.mobile ?? '',
    address: member.address ?? '',
    emergency_contact: member.emergency_contact ?? '',
    medical_condition: member.medical_condition ?? '',
    cardio_notes: member.cardio_notes ?? '',
    status: member.status ?? 'active',
  });
  const [photo, setPhoto] = useState(member.photo ?? '');
  const [saving, setSaving] = useState(false);
  const set = (k: string, v: any) => setForm((f) => ({ ...f, [k]: v }));

  const save = async () => {
    setSaving(true);
    const { error } = await supabase
      .from('members')
      .update({
        ...form,
        photo: photo || null,
        updated_at: new Date().toISOString(),
      })
      .eq('id', member.id);
    setSaving(false);
    if (error) {
      alert(error.message);
      return;
    }
    onSaved();
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label className="label">Photo</label>
          <div className="h-32">
            <PhotoUpload photo={photo} onCapture={setPhoto} />
          </div>
        </div>
        <div>
          <label className="label">Name</label>
          <input
            className="input"
            value={form.name}
            onChange={(e) => set('name', e.target.value)}
          />
        </div>
        <div>
          <label className="label">Father Name</label>
          <input
            className="input"
            value={form.father_name}
            onChange={(e) => set('father_name', e.target.value)}
          />
        </div>
        <div>
          <label className="label">Gender</label>
          <select
            className="input"
            value={form.gender}
            onChange={(e) => set('gender', e.target.value)}
          >
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
        </div>
        <div>
          <label className="label">Date of Birth</label>
          <input
            type="date"
            className="input"
            value={form.date_of_birth}
            onChange={(e) => set('date_of_birth', e.target.value)}
          />
        </div>
        <div>
          <label className="label">Mobile</label>
          <input
            className="input"
            value={form.mobile}
            onChange={(e) => set('mobile', e.target.value)}
          />
        </div>
        <div>
          <label className="label">Emergency Contact</label>
          <input
            className="input"
            value={form.emergency_contact}
            onChange={(e) => set('emergency_contact', e.target.value)}
          />
        </div>
        <div className="sm:col-span-2">
          <label className="label">Address</label>
          <textarea
            className="input min-h-[50px]"
            value={form.address}
            onChange={(e) => set('address', e.target.value)}
          />
        </div>
        <div className="sm:col-span-2">
          <label className="label">Medical Condition</label>
          <textarea
            className="input min-h-[50px]"
            value={form.medical_condition}
            onChange={(e) => set('medical_condition', e.target.value)}
          />
        </div>
        <div className="sm:col-span-2">
          <label className="label">Cardio Notes</label>
          <textarea
            className="input min-h-[50px]"
            value={form.cardio_notes}
            onChange={(e) => set('cardio_notes', e.target.value)}
          />
        </div>
        <div>
          <label className="label">Status</label>
          <select
            className="input"
            value={form.status}
            onChange={(e) => set('status', e.target.value)}
          >
            <option value="active">Active</option>
            <option value="expired">Expired</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div className="flex justify-end gap-2 border-t border-ink-700 pt-4">
        <Button variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
        <Button
          variant="gold"
          onClick={save}
          disabled={saving || !form.name.trim()}
        >
          {saving ? <Loading /> : <Icon name="Save" className="h-4 w-4" />}
          Save Changes
        </Button>
      </div>
    </div>
  );
}

function RenewalForm({
  member,
  plans,
  onClose,
  onDone,
}: {
  member: Member;
  plans: Plan[];
  onClose: () => void;
  onDone: () => void;
}) {
  const [planId, setPlanId] = useState(member.plan_id ?? '');
  const [method, setMethod] = useState('Cash');
  const [startDate, setStartDate] = useState(
    member.expiry_date && daysUntil(member.expiry_date)! >= 0
      ? member.expiry_date
      : new Date().toISOString().slice(0, 10)
  );
  const [amountPaid, setAmountPaid] = useState<string>(
    String(plans.find((p) => p.id === member.plan_id)?.price ?? '')
  );
  const [saving, setSaving] = useState(false);

  const plan = plans.find((p) => p.id === planId) as Plan | undefined;
  const expiry = plan
    ? new Date(new Date(startDate).setMonth(plan.duration_months))
        .toISOString()
        .slice(0, 10)
    : '';
  const paid = Number(amountPaid || 0);
  const due = Math.max(0, (plan?.price ?? 0) - paid);

  const save = async () => {
    if (!plan || paid <= 0) return;
    setSaving(true);
    try {
      const receiptNo = await generateReceiptNo();
      const { error: payErr } = await supabase.from('payments').insert({
        member_id: member.id,
        receipt_no: receiptNo,
        type: 'renewal',
        amount: paid,
        due_amount: Math.max(0, Number(plan.price) - paid),
        method,
        received_by: 'Admin',
        note: `${plan.category} ${plan.duration_months}M renewal`,
        paid_date: new Date().toISOString(),
        new_start_date: startDate,
        new_expiry_date: expiry,
      });
      if (payErr) throw payErr;

      const { error: memErr } = await supabase
        .from('members')
        .update({
          plan_id: plan.id,
          category: plan.category,
          duration_months: plan.duration_months,
          plan_price: plan.price,
          start_date: startDate,
          expiry_date: expiry,
          status: 'active',
          due_amount: due,
          updated_at: new Date().toISOString(),
        })
        .eq('id', member.id);
      if (memErr) throw memErr;

      const lastPay: Payment = {
        id: '',
        member_id: member.id,
        receipt_no: receiptNo,
        type: 'renewal',
        amount: paid,
        due_amount: Math.max(0, Number(plan.price) - paid),
        method,
        received_by: 'Admin',
        note: `${plan.category} ${plan.duration_months}M renewal`,
        paid_date: new Date().toISOString(),
        new_start_date: startDate,
        new_expiry_date: expiry,
        created_at: new Date().toISOString(),
      };
      const updated: Member = {
        ...member,
        plan_id: plan.id,
        category: plan.category,
        duration_months: plan.duration_months,
        plan_price: plan.price,
        start_date: startDate,
        expiry_date: expiry,
        status: 'active',
        due_amount: due,
      };
      openPrintWindow(generateReceiptHTML(lastPay, updated, {}));
      openWhatsApp(updated.mobile, renewalWhatsAppMessage(lastPay, updated));
      onDone();
    } catch (e: any) {
      alert(e.message || 'Renewal failed.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="label">Select Plan</label>
        <select
          className="input"
          value={planId}
          onChange={(e) => setPlanId(e.target.value)}
        >
          <option value="">— Choose Plan —</option>
          {plans
            .filter((p) => p.is_active)
            .map((p) => (
              <option key={p.id} value={p.id}>
                {p.category} · {p.label} — {formatCurrency(p.price)}
              </option>
            ))}
        </select>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label">Start Date</label>
          <input
            type="date"
            className="input"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
          />
        </div>
        <div>
          <label className="label">New Expiry</label>
          <input className="input bg-ink-800" value={expiry} readOnly />
        </div>
        <div>
          <label className="label">Amount Paid</label>
          <input
            type="number"
            className="input"
            value={amountPaid}
            onChange={(e) => setAmountPaid(e.target.value)}
          />
        </div>
        <div>
          <label className="label">Payment Method</label>
          <select
            className="input"
            value={method}
            onChange={(e) => setMethod(e.target.value)}
          >
            <option value="Cash">Cash</option>
            <option value="UPI">UPI</option>
            <option value="Card">Card</option>
            <option value="Bank Transfer">Bank Transfer</option>
          </select>
        </div>
      </div>
      <div className="flex items-center justify-between rounded-xl border border-gold-500/30 bg-gold-500/5 px-4 py-3 text-sm">
        <div>
          <p className="text-xs text-neutral-500">Plan Price</p>
          <p className="font-bold gold-text">
            {formatCurrency(plan?.price ?? 0)}
          </p>
        </div>
        <div className="text-right">
          <p className="text-xs text-neutral-500">Due</p>
          <p
            className={`font-bold ${
              due > 0 ? 'text-rose-300' : 'text-emerald-300'
            }`}
          >
            {formatCurrency(due)}
          </p>
        </div>
      </div>
      <div className="flex justify-end gap-2 border-t border-ink-700 pt-4">
        <Button variant="ghost" onClick={onClose}>
          Cancel
        </Button>
        <Button
          variant="gold"
          onClick={save}
          disabled={saving || !planId || paid <= 0}
        >
          {saving ? <Loading /> : <Icon name="RefreshCw" className="h-4 w-4" />}
          Renew & Generate Receipt
        </Button>
      </div>
    </div>
  );
}
