import { useEffect, useMemo, useState } from 'react';
import { supabase } from '../lib/supabase';
import { usePlans, useSettings, useMembers } from '../lib/hooks';
import { PhotoUpload } from '../components/PhotoCapture';
import { Card, Icon, Button, Loading } from '../components/ui';
import {
  formatCurrency,
  todayISO,
  addMonths,
  generateMemberNo,
} from '../lib/utils';
import type { Plan } from '../lib/types';

const DECLARATION =
  'I confirm that I am joining the gym voluntarily and understand that exercise involves physical risk. The gym management shall not be responsible for any injury, illness, loss or damage arising during training.';

const empty = () => ({
  photo: '' as string,
  name: '',
  father_name: '',
  gender: 'Male' as 'Male' | 'Female' | 'Other',
  date_of_birth: '',
  mobile: '',
  address: '',
  emergency_contact: '',
  plan_id: '',
  medical_condition: '',
  cardio_notes: '',
  declaration_accepted: false,
  start_date: todayISO(),
});

export function AdmissionPage({ onDone }: { onDone: () => void }) {
  const { plans } = usePlans();
  const { settings } = useSettings();
  const { reload } = useMembers();
  const [form, setForm] = useState(empty());
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [previewMemberNo, setPreviewMemberNo] = useState<string>('');

  useEffect(() => {
    generateMemberNo()
      .then(setPreviewMemberNo)
      .catch(() => setPreviewMemberNo(''));
  }, []);

  const regFee = Number(settings?.registration_fee ?? 500);

  const selectedPlan = useMemo(
    () => plans.find((p) => p.id === form.plan_id) as Plan | undefined,
    [plans, form.plan_id]
  );

  const category = selectedPlan?.category;
  const planPrice = selectedPlan?.price ?? 0;
  const total = regFee + planPrice;

  const set = (k: string, v: any) => setForm((f) => ({ ...f, [k]: v }));

  const valid =
    form.name.trim() &&
    form.mobile.trim() &&
    form.plan_id &&
    form.declaration_accepted;

  const submit = async () => {
    if (!selectedPlan) return;
    setError(null);
    setSaving(true);
    try {
      const memberNo = await generateMemberNo();
      const expiry = addMonths(form.start_date, selectedPlan.duration_months);
      const insert = {
        member_no: memberNo,
        photo: form.photo || null,
        name: form.name.trim(),
        father_name: form.father_name.trim(),
        gender: form.gender,
        date_of_birth: form.date_of_birth || null,
        mobile: form.mobile.trim(),
        address: form.address.trim() || null,
        emergency_contact: form.emergency_contact.trim() || null,
        plan_id: selectedPlan.id,
        category: selectedPlan.category,
        duration_months: selectedPlan.duration_months,
        plan_price: selectedPlan.price,
        registration_fee: regFee,
        medical_condition: form.medical_condition.trim() || null,
        cardio_notes: form.cardio_notes.trim() || null,
        declaration_accepted: form.declaration_accepted,
        status: 'active',
        due_amount: 0,
        start_date: form.start_date,
        expiry_date: expiry,
      };
      const { data, error: insErr } = await supabase
        .from('members')
        .insert(insert)
        .select()
        .single();
      if (insErr) throw insErr;
      const member = data;

      const receiptNo = `FIG-${new Date()
        .toISOString()
        .slice(0, 10)
        .replace(/-/g, '')}-${Math.floor(Math.random() * 9000 + 1000)}`;
      await supabase.from('payments').insert({
        member_id: member.id,
        receipt_no: receiptNo,
        type: 'registration',
        amount: total,
        method: 'Cash',
        note: `Registration ₹${regFee} + ${selectedPlan.category} ${selectedPlan.duration_months}M plan ₹${planPrice}`,
        paid_date: new Date().toISOString(),
        new_start_date: form.start_date,
        new_expiry_date: expiry,
      });

      setSuccess(memberNo);
      reload();
      setForm(empty());
    } catch (e: any) {
      setError(e.message || 'Failed to save member. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  if (success) {
    return (
      <div className="mx-auto max-w-md">
        <Card className="p-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-300">
            <Icon name="CheckCircle2" className="h-9 w-9" />
          </div>
          <h2 className="font-display text-xl font-bold gold-text">
            Admission Successful!
          </h2>
          <p className="mt-2 text-sm text-neutral-400">
            Member has been registered successfully.
          </p>
          <div className="mt-4 rounded-xl border border-gold-500/30 bg-ink-900/60 px-4 py-3">
            <p className="text-xs uppercase tracking-wider text-neutral-500">
              Member Number
            </p>
            <p className="font-display text-2xl font-bold gold-text">{success}</p>
          </div>
          <div className="mt-6 flex flex-col gap-2">
            <Button variant="outline" onClick={() => setSuccess(null)}>
              <Icon name="Plus" className="h-4 w-4" />
              Add Another Member
            </Button>
            <Button variant="ghost" onClick={onDone}>
              Go to Dashboard
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl space-y-5">
      <div>
        <h1 className="font-display text-2xl font-bold text-neutral-100">
          New Member Admission
        </h1>
        <p className="text-sm text-neutral-500">
          Fill the form below to register a new gym member.
        </p>
      </div>

      {previewMemberNo && (
        <div className="flex items-center gap-3 rounded-xl border border-gold-500/30 bg-gradient-to-r from-gold-500/10 to-transparent px-4 py-3">
          <div className="rounded-lg bg-gold-500/20 p-2 text-gold-300">
            <Icon name="BadgeCheck" className="h-5 w-5" />
          </div>
          <div>
            <p className="text-xs uppercase tracking-wider text-neutral-500">
              Auto-Generated Member ID
            </p>
            <p className="font-display text-lg font-bold gold-text">
              {previewMemberNo}
            </p>
          </div>
          <span className="ml-auto rounded-full bg-gold-500/10 px-2.5 py-1 text-[10px] font-semibold text-gold-300">
            assigned on save
          </span>
        </div>
      )}

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div className="space-y-5">
          <Card className="p-5">
            <label className="label">Photo</label>
            <PhotoUpload
              photo={form.photo}
              onCapture={(d) => set('photo', d)}
            />
          </Card>

          <Card className="p-5">
            <h3 className="mb-3 font-display text-sm font-semibold gold-text">
              Membership Plan
            </h3>
            <div className="label">Select Plan</div>
            <select
              value={form.plan_id}
              onChange={(e) => set('plan_id', e.target.value)}
              className="input"
            >
              <option value="">— Choose Plan —</option>
              {(['Boys/Unisex', 'Only Ladies'] as const).map((cat) => (
                <optgroup key={cat} label={cat}>
                  {plans
                    .filter((p) => p.is_active && p.category === cat)
                    .map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.label} — {formatCurrency(p.price)}
                      </option>
                    ))}
                </optgroup>
              ))}
            </select>

            {selectedPlan && (
              <div className="mt-3 space-y-1.5 rounded-xl border border-ink-700 bg-ink-900/50 p-3 text-sm">
                <Row k="Category" v={category ?? '—'} />
                <Row k="Duration" v={`${selectedPlan.duration_months} months`} />
                <Row k="Plan Price" v={formatCurrency(planPrice)} />
                <Row k="Registration Fee" v={formatCurrency(regFee)} />
                <div className="my-1 border-t border-ink-700" />
                <Row k="Total Payable" v={formatCurrency(total)} bold />
              </div>
            )}
          </Card>
        </div>

        <div className="space-y-5 lg:col-span-2">
          <Card className="p-5">
            <h3 className="mb-4 font-display text-sm font-semibold gold-text">
              Personal Details
            </h3>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Field label="Full Name *">
                <input
                  className="input"
                  value={form.name}
                  onChange={(e) => set('name', e.target.value)}
                  placeholder="e.g. Rahul Kumar"
                />
              </Field>
              <Field label="Father Name">
                <input
                  className="input"
                  value={form.father_name}
                  onChange={(e) => set('father_name', e.target.value)}
                  placeholder="Father's full name"
                />
              </Field>
              <Field label="Gender">
                <select
                  className="input"
                  value={form.gender}
                  onChange={(e) => set('gender', e.target.value)}
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </Field>
              <Field label="Date of Birth">
                <input
                  type="date"
                  className="input"
                  value={form.date_of_birth}
                  onChange={(e) => set('date_of_birth', e.target.value)}
                />
              </Field>
              <Field label="Mobile *">
                <input
                  className="input"
                  value={form.mobile}
                  onChange={(e) => set('mobile', e.target.value)}
                  placeholder="10-digit mobile"
                  inputMode="numeric"
                  maxLength={10}
                />
              </Field>
              <Field label="Emergency Contact">
                <input
                  className="input"
                  value={form.emergency_contact}
                  onChange={(e) => set('emergency_contact', e.target.value)}
                  placeholder="Emergency mobile"
                />
              </Field>
              <Field label="Address" full>
                <textarea
                  className="input min-h-[60px] resize-y"
                  value={form.address}
                  onChange={(e) => set('address', e.target.value)}
                  placeholder="Full residential address"
                />
              </Field>
            </div>
          </Card>

          <Card className="p-5">
            <h3 className="mb-4 font-display text-sm font-semibold gold-text">
              Health & Membership
            </h3>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Field label="Membership Start Date">
                <input
                  type="date"
                  className="input"
                  value={form.start_date}
                  onChange={(e) => set('start_date', e.target.value)}
                />
              </Field>
              <Field label="Medical Condition" full>
                <textarea
                  className="input min-h-[60px] resize-y"
                  value={form.medical_condition}
                  onChange={(e) => set('medical_condition', e.target.value)}
                  placeholder="Any injuries, BP, diabetes, past surgery, etc. Write 'None' if not applicable."
                />
              </Field>
              <Field label="Cardio Notes" full>
                <textarea
                  className="input min-h-[60px] resize-y"
                  value={form.cardio_notes}
                  onChange={(e) => set('cardio_notes', e.target.value)}
                  placeholder="Cardio-related observations / restrictions"
                />
              </Field>
            </div>
          </Card>

          <Card className="border-gold-500/30 p-5">
            <div className="flex items-start gap-3">
              <button
                type="button"
                onClick={() =>
                  set('declaration_accepted', !form.declaration_accepted)
                }
                className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition ${
                  form.declaration_accepted
                    ? 'border-gold-400 bg-gold-400 text-ink-950'
                    : 'border-ink-500 bg-ink-800'
                }`}
              >
                {form.declaration_accepted && (
                  <Icon name="Check" className="h-3.5 w-3.5" />
                )}
              </button>
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-gold-300">
                  Declaration
                </p>
                <p className="mt-1 text-sm leading-relaxed text-neutral-400">
                  {DECLARATION}
                </p>
              </div>
            </div>
          </Card>

          {error && (
            <div className="flex items-center gap-2 rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-300">
              <Icon name="AlertCircle" className="h-4 w-4" />
              {error}
            </div>
          )}

          <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
            <Button variant="ghost" onClick={() => setForm(empty())}>
              Reset Form
            </Button>
            <Button
              variant="gold"
              disabled={!valid || saving}
              onClick={submit}
            >
              {saving ? <Loading /> : <Icon name="Save" className="h-4 w-4" />}
              {saving ? 'Saving…' : 'Complete Admission'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  children,
  full,
}: {
  label: string;
  children: React.ReactNode;
  full?: boolean;
}) {
  return (
    <div className={full ? 'sm:col-span-2' : ''}>
      <label className="label">{label}</label>
      {children}
    </div>
  );
}

function Row({ k, v, bold }: { k: string; v: string; bold?: boolean }) {
  return (
    <div className="flex justify-between">
      <span className="text-neutral-500">{k}</span>
      <span
        className={
          bold ? 'font-bold gold-text' : 'font-semibold text-neutral-200'
        }
      >
        {v}
      </span>
    </div>
  );
}
