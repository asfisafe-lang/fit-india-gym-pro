import { useMemo, useState } from 'react';
import { useMembers, usePayments } from '../lib/hooks';
import {
  Card,
  Icon,
  Loading,
  EmptyState,
  Avatar,
  Badge,
  StatCard,
  Modal,
  Button,
} from '../components/ui';
import { formatCurrency, formatDateTime } from '../lib/utils';
import {
  openPrintWindow,
  generateReceiptHTML,
  downloadHTML,
  receiptWhatsAppMessage,
  openWhatsApp,
} from '../lib/print';
import type { Member, Payment } from '../lib/types';

export function PaymentsPage() {
  const { members } = useMembers();
  const { payments, loading } = usePayments();
  const [q, setQ] = useState('');
  const [viewPayment, setViewPayment] = useState<Payment | null>(null);
  const [viewMember, setViewMember] = useState<Member | undefined>(undefined);

  const memberMap = useMemo(() => {
    const m = new Map<string, Member>();
    for (const mem of members) m.set(mem.id, mem);
    return m;
  }, [members]);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return payments;
    return payments.filter((p) => {
      const m = memberMap.get(p.member_id);
      return (
        p.receipt_no.toLowerCase().includes(term) ||
        m?.name.toLowerCase().includes(term) ||
        m?.member_no?.toLowerCase().includes(term) ||
        m?.mobile?.toLowerCase().includes(term)
      );
    });
  }, [payments, q, memberMap]);

  const stats = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    const month = today.slice(0, 7);
    const total = payments.reduce((s, p) => s + Number(p.amount), 0);
    const todayRev = payments
      .filter((p) => p.paid_date.slice(0, 10) === today)
      .reduce((s, p) => s + Number(p.amount), 0);
    const monthRev = payments
      .filter((p) => p.paid_date.slice(0, 7) === month)
      .reduce((s, p) => s + Number(p.amount), 0);
    return { total, todayRev, monthRev, count: payments.length };
  }, [payments]);

  if (loading) return <Loading label="Loading payments…" />;

  const shareWhatsApp = (p: Payment) => {
    const m = memberMap.get(p.member_id);
    const msg = receiptWhatsAppMessage(p, m);
    openWhatsApp(m?.mobile, msg);
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-2xl font-bold text-neutral-100">
          Payments & Receipts
        </h1>
        <p className="text-sm text-neutral-500">
          Track all payments and generate / share receipts.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          icon="IndianRupee"
          label="Total Revenue"
          value={formatCurrency(stats.total)}
          accent="gold"
        />
        <StatCard
          icon="TrendingUp"
          label="This Month"
          value={formatCurrency(stats.monthRev)}
          accent="emerald"
        />
        <StatCard
          icon="CalendarDays"
          label="Today"
          value={formatCurrency(stats.todayRev)}
          accent="sky"
        />
        <StatCard
          icon="FileText"
          label="Total Receipts"
          value={stats.count}
          accent="amber"
        />
      </div>

      <Card className="p-4">
        <div className="relative">
          <Icon
            name="Search"
            className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-500"
          />
          <input
            className="input pl-10"
            placeholder="Search by receipt no, name, mobile, member no…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
      </Card>

      <Card className="overflow-hidden">
        {filtered.length === 0 ? (
          <EmptyState
            icon="IndianRupee"
            title="No payments found"
            description="Payments will appear here once admissions or renewals are made."
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-ink-700 bg-ink-900/50 text-left text-xs uppercase tracking-wider text-neutral-500">
                <tr>
                  <th className="px-4 py-3 font-semibold">Receipt</th>
                  <th className="hidden px-4 py-3 font-semibold sm:table-cell">
                    Member
                  </th>
                  <th className="hidden px-4 py-3 font-semibold md:table-cell">
                    Date
                  </th>
                  <th className="px-4 py-3 font-semibold">Type</th>
                  <th className="px-4 py-3 font-semibold">Amount</th>
                  <th className="px-4 py-3 text-right font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-700/50">
                {filtered.slice(0, 100).map((p) => {
                  const m = memberMap.get(p.member_id);
                  return (
                    <tr key={p.id} className="table-row-hover">
                      <td className="px-4 py-3">
                        <p className="font-mono text-xs text-gold-300">
                          {p.receipt_no}
                        </p>
                        <p className="text-xs text-neutral-500 sm:hidden">
                          {m?.name}
                        </p>
                      </td>
                      <td className="hidden px-4 py-3 sm:table-cell">
                        {m ? (
                          <div className="flex items-center gap-2">
                            <Avatar photo={m.photo} name={m.name} size="sm" />
                            <div className="min-w-0">
                              <p className="truncate font-medium text-neutral-200">
                                {m.name}
                              </p>
                              <p className="text-xs text-neutral-500">
                                {m.member_no}
                              </p>
                            </div>
                          </div>
                        ) : (
                          <span className="text-neutral-600">—</span>
                        )}
                      </td>
                      <td className="hidden px-4 py-3 text-neutral-400 md:table-cell">
                        {formatDateTime(p.paid_date)}
                      </td>
                      <td className="px-4 py-3">
                        <Badge
                          className={
                            p.type === 'registration'
                              ? 'border border-gold-500/30 bg-gold-500/15 text-gold-300'
                              : 'border border-emerald-500/30 bg-emerald-500/15 text-emerald-300'
                          }
                        >
                          {p.type}
                        </Badge>
                      </td>
                      <td className="px-4 py-3">
                        <span className="font-bold text-neutral-100">
                          {formatCurrency(p.amount)}
                        </span>
                        <p className="text-xs text-neutral-500">{p.method}</p>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex justify-end gap-1">
                          <button
                            onClick={() => {
                              setViewPayment(p);
                              setViewMember(m);
                            }}
                            className="rounded-lg p-2 text-neutral-400 hover:bg-ink-700 hover:text-sky-300"
                            title="View Receipt"
                          >
                            <Icon name="Eye" className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() =>
                              openPrintWindow(generateReceiptHTML(p, m, {}))
                            }
                            className="rounded-lg p-2 text-neutral-400 hover:bg-ink-700 hover:text-emerald-300"
                            title="Print Receipt"
                          >
                            <Icon name="Printer" className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() =>
                              downloadHTML(
                                generateReceiptHTML(p, m, {}),
                                `Receipt-${p.receipt_no}.html`
                              )
                            }
                            className="rounded-lg p-2 text-neutral-400 hover:bg-ink-700 hover:text-gold-200"
                            title="Download PDF"
                          >
                            <Icon name="Download" className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => shareWhatsApp(p)}
                            className="rounded-lg p-2 text-neutral-400 hover:bg-ink-700 hover:text-emerald-300"
                            title="Share on WhatsApp"
                          >
                            <Icon name="Share2" className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {viewPayment && (
        <Modal
          open
          onClose={() => setViewPayment(null)}
          title={`Receipt ${viewPayment.receipt_no}`}
          size="md"
        >
          <div className="space-y-4">
            <div className="rounded-xl border border-ink-700 bg-ink-900/40 p-4">
              <ReceiptRows payment={viewPayment} member={viewMember} />
            </div>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              <Button
                variant="gold"
                onClick={() =>
                  openPrintWindow(
                    generateReceiptHTML(viewPayment, viewMember, {})
                  )
                }
              >
                <Icon name="Printer" className="h-4 w-4" />
                Print Receipt
              </Button>
              <Button
                variant="outline"
                onClick={() =>
                  downloadHTML(
                    generateReceiptHTML(viewPayment, viewMember, {}),
                    `Receipt-${viewPayment.receipt_no}.html`
                  )
                }
              >
                <Icon name="Download" className="h-4 w-4" />
                Download PDF
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

function ReceiptRows({
  payment,
  member,
}: {
  payment: Payment;
  member?: Member;
}) {
  const planLabel = member?.category
    ? `${member.category} · ${member.duration_months}M`
    : '—';
  const rows: [string, string][] = [
    ['Receipt No', payment.receipt_no],
    ['Date', formatDateTime(payment.paid_date)],
    ['Member ID', member?.member_no ?? '—'],
    ['Member Name', member?.name ?? '—'],
    ['Mobile', member?.mobile ?? '—'],
    ['Membership Plan', planLabel],
    ['Payment Mode', payment.method ?? 'Cash'],
    ['Amount Paid', formatCurrency(payment.amount)],
    ['Due Amount', formatCurrency(payment.due_amount ?? 0)],
    ['Received By', payment.received_by ?? 'Admin'],
  ];
  return (
    <div className="space-y-1">
      {rows.map(([k, v]) => (
        <div
          key={k}
          className="flex items-center justify-between border-b border-dashed border-ink-700 py-1.5 text-sm"
        >
          <span className="text-neutral-500">{k}</span>
          <span className="font-semibold text-neutral-100">{v}</span>
        </div>
      ))}
    </div>
  );
}
