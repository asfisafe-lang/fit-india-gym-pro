import { useMemo, useState } from 'react';
import { supabase } from '../lib/supabase';
import {
  useMembers,
  useAttendanceToday,
  useAttendance,
} from '../lib/hooks';
import {
  Card,
  Icon,
  Button,
  Loading,
  EmptyState,
  Avatar,
  StatCard,
  Badge,
} from '../components/ui';
import { formatDateTime, formatDate } from '../lib/utils';
import type { Member } from '../lib/types';

type RangeKey = 'today' | 'week' | 'month';

const RANGES: { key: RangeKey; label: string }[] = [
  { key: 'today', label: 'Today' },
  { key: 'week', label: 'This Week' },
  { key: 'month', label: 'This Month' },
];

function rangeStart(key: RangeKey): string {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  if (key === 'week') {
    const day = d.getDay();
    d.setDate(d.getDate() - day);
  } else if (key === 'month') {
    d.setDate(1);
  }
  return d.toISOString();
}

export function AttendancePage() {
  const { members, loading } = useMembers();
  const { records, loading: attLoading, reload } = useAttendanceToday();
  const { records: allRecords, loading: allLoading } = useAttendance();
  const [q, setQ] = useState('');
  const [category, setCategory] = useState('all');
  const [range, setRange] = useState<RangeKey>('today');
  const [view, setView] = useState<'checkin' | 'history'>('checkin');

  const memberMap = useMemo(() => {
    const m = new Map<string, Member>();
    for (const mem of members) m.set(mem.id, mem);
    return m;
  }, [members]);

  const checkedInIds = useMemo(
    () => new Set(records.map((r) => r.member_id)),
    [records]
  );

  const eligible = useMemo(() => {
    const term = q.trim().toLowerCase();
    return members.filter((m) => {
      if (m.status === 'inactive') return false;
      if (category === 'active' && m.status !== 'active') return false;
      if (category === 'ladies' && m.gender !== 'Female') return false;
      if (category === 'boys' && m.gender === 'Female') return false;
      if (!term) return true;
      return (
        m.name?.toLowerCase().includes(term) ||
        m.mobile?.toLowerCase().includes(term) ||
        m.member_no?.toLowerCase().includes(term)
      );
    });
  }, [members, q, category]);

  const rangeRecords = useMemo(() => {
    const start = rangeStart(range);
    return allRecords.filter((r) => r.check_in >= start);
  }, [allRecords, range]);

  const rangeStats = useMemo(() => {
    const count = rangeRecords.length;
    const uniqueMembers = new Set(rangeRecords.map((r) => r.member_id)).size;
    return { count, uniqueMembers };
  }, [rangeRecords]);

  const historyFiltered = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return rangeRecords;
    return rangeRecords.filter((r) => {
      const m = memberMap.get(r.member_id);
      return (
        m?.name?.toLowerCase().includes(term) ||
        m?.mobile?.toLowerCase().includes(term) ||
        m?.member_no?.toLowerCase().includes(term)
      );
    });
  }, [rangeRecords, q, memberMap]);

  const checkIn = async (memberId: string) => {
    const { error } = await supabase.from('attendance').insert({
      member_id: memberId,
      check_in: new Date().toISOString(),
    });
    if (error) alert(error.message);
    else {
      reload();
      window.location.reload();
    }
  };

  const checkOut = async (memberId: string) => {
    const memberRecords = records.filter((r) => r.member_id === memberId);
    if (memberRecords.length === 0) return;
    const latest = memberRecords[0];
    const { error } = await supabase
      .from('attendance')
      .delete()
      .eq('id', latest.id);
    if (error) alert(error.message);
    else reload();
  };

  if (loading || attLoading || allLoading)
    return <Loading label="Loading attendance…" />;

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-neutral-100">
            Attendance Tracking
          </h1>
          <p className="text-sm text-neutral-500">
            Check members in and view attendance history.
          </p>
        </div>
        <div className="flex gap-1.5 rounded-lg bg-ink-900/60 p-1">
          <button
            onClick={() => setView('checkin')}
            className={`rounded-md px-3 py-1.5 text-xs font-semibold transition ${
              view === 'checkin'
                ? 'bg-gold-500/20 text-gold-200 ring-1 ring-gold-500/30'
                : 'text-neutral-500 hover:text-neutral-300'
            }`}
          >
            <Icon name="ClipboardCheck" className="mr-1.5 inline h-4 w-4" />
            Check In
          </button>
          <button
            onClick={() => setView('history')}
            className={`rounded-md px-3 py-1.5 text-xs font-semibold transition ${
              view === 'history'
                ? 'bg-gold-500/20 text-gold-200 ring-1 ring-gold-500/30'
                : 'text-neutral-500 hover:text-neutral-300'
            }`}
          >
            <Icon name="History" className="mr-1.5 inline h-4 w-4" />
            History
          </button>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <StatCard
          icon="ClipboardCheck"
          label="Checked In Today"
          value={records.length}
          accent="emerald"
        />
        <StatCard
          icon="Users"
          label="Eligible Members"
          value={eligible.length}
          accent="gold"
        />
        <StatCard
          icon="CalendarDays"
          label={RANGES.find((r) => r.key === range)?.label + ' Total'}
          value={rangeStats.count}
          accent="sky"
        />
        <StatCard
          icon="CheckCircle2"
          label={RANGES.find((r) => r.key === range)?.label + ' Unique'}
          value={rangeStats.uniqueMembers}
          accent="amber"
        />
      </div>

      {/* Filters card */}
      <Card className="space-y-3 p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Icon
              name="Search"
              className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-500"
            />
            <input
              className="input pl-10"
              placeholder="Search member by name, mobile, or no…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>
          {view === 'checkin' && (
            <select
              className="input sm:w-44"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option value="all">All Members</option>
              <option value="active">Active Only</option>
              <option value="ladies">Ladies</option>
              <option value="boys">Boys/Men</option>
            </select>
          )}
        </div>
        {view === 'history' && (
          <div className="flex flex-wrap gap-1.5">
            {RANGES.map((r) => (
              <button
                key={r.key}
                onClick={() => setRange(r.key)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                  range === r.key
                    ? 'bg-gold-500/20 text-gold-200 ring-1 ring-gold-500/30'
                    : 'text-neutral-500 hover:bg-ink-800 hover:text-neutral-300'
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>
        )}
        {view === 'checkin' && (
          <div className="flex flex-wrap gap-1.5">
            {['all', 'active', 'ladies', 'boys'].map((c) => (
              <button
                key={c}
                onClick={() => setCategory(c)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold capitalize transition ${
                  category === c
                    ? 'bg-gold-500/20 text-gold-200 ring-1 ring-gold-500/30'
                    : 'text-neutral-500 hover:bg-ink-800 hover:text-neutral-300'
                }`}
              >
                {c === 'all' ? 'All Members' : c}
              </button>
            ))}
          </div>
        )}
      </Card>

      {/* Check-in view */}
      {view === 'checkin' &&
        (eligible.length === 0 ? (
          <Card>
            <EmptyState
              icon="ClipboardCheck"
              title="No members to show"
              description="Try different search or filter."
            />
          </Card>
        ) : (
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {eligible.slice(0, 60).map((m) => {
              const isIn = checkedInIds.has(m.id);
              const record = records.find((r) => r.member_id === m.id);
              return (
                <Card
                  key={m.id}
                  className="card-hover flex items-center gap-3 p-3"
                >
                  <Avatar photo={m.photo} name={m.name} size="md" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-neutral-100">
                      {m.name}
                    </p>
                    <p className="text-xs text-neutral-500">
                      {m.member_no} · {m.gender}
                    </p>
                    {isIn && record && (
                      <p className="mt-0.5 text-[11px] text-emerald-400">
                        In: {formatDateTime(record.check_in)}
                      </p>
                    )}
                  </div>
                  {isIn ? (
                    <Button
                      variant="ghost"
                      className="px-2 py-1.5 text-xs text-rose-300 hover:text-rose-200"
                      onClick={() => checkOut(m.id)}
                    >
                      <Icon name="XCircle" className="h-4 w-4" />
                      Out
                    </Button>
                  ) : (
                    <Button
                      variant="gold"
                      className="px-2 py-1.5 text-xs"
                      onClick={() => checkIn(m.id)}
                    >
                      <Icon name="Check" className="h-4 w-4" />
                      Check In
                    </Button>
                  )}
                </Card>
              );
            })}
          </div>
        ))}

      {/* History view */}
      {view === 'history' &&
        (historyFiltered.length === 0 ? (
          <Card>
            <EmptyState
              icon="History"
              title="No attendance records"
              description="No check-ins found for this period."
            />
          </Card>
        ) : (
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-ink-700 bg-ink-900/50 text-left text-xs uppercase tracking-wider text-neutral-500">
                  <tr>
                    <th className="px-4 py-3 font-semibold">Member</th>
                    <th className="hidden px-4 py-3 font-semibold sm:table-cell">
                      Member ID
                    </th>
                    <th className="hidden px-4 py-3 font-semibold md:table-cell">
                      Date
                    </th>
                    <th className="px-4 py-3 font-semibold">Check-in Time</th>
                    <th className="px-4 py-3 font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-ink-700/50">
                  {historyFiltered.slice(0, 200).map((r) => {
                    const m = memberMap.get(r.member_id);
                    const dateStr = r.check_in.slice(0, 10);
                    const timeStr = r.check_in.slice(11, 16);
                    return (
                      <tr key={r.id} className="table-row-hover">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <Avatar
                              photo={m?.photo}
                              name={m?.name ?? '?'}
                              size="sm"
                            />
                            <div className="min-w-0">
                              <p className="truncate font-medium text-neutral-200">
                                {m?.name ?? 'Unknown'}
                              </p>
                              <p className="text-xs text-neutral-500 sm:hidden">
                                {m?.member_no}
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="hidden px-4 py-3 text-neutral-400 sm:table-cell">
                          {m?.member_no ?? '—'}
                        </td>
                        <td className="hidden px-4 py-3 text-neutral-400 md:table-cell">
                          {formatDate(dateStr)}
                        </td>
                        <td className="px-4 py-3 text-neutral-200">
                          {timeStr}
                          <span className="ml-1 text-xs text-neutral-500">
                            {formatDate(dateStr)}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <Badge className="border border-emerald-500/30 bg-emerald-500/15 text-emerald-300">
                            <Icon
                              name="CheckCircle2"
                              className="mr-1 h-3 w-3"
                            />
                            Present
                          </Badge>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {historyFiltered.length > 200 && (
              <p className="border-t border-ink-700 px-4 py-3 text-center text-xs text-neutral-500">
                Showing 200 of {historyFiltered.length} records
              </p>
            )}
          </Card>
        ))}
    </div>
  );
}
