import { useMemo, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useInquiries } from '../lib/hooks';
import {
  Card,
  Icon,
  Button,
  Loading,
  EmptyState,
  Badge,
  Modal,
  StatCard,
} from '../components/ui';
import { formatDate, statusBadge } from '../lib/utils';
import type { Inquiry } from '../lib/types';

const emptyForm = () => ({
  name: '',
  mobile: '',
  notes: '',
  status: 'new' as Inquiry['status'],
  follow_up_date: '',
});

export function InquiriesPage() {
  const { inquiries, loading, reload } = useInquiries();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Inquiry | null>(null);
  const [form, setForm] = useState(emptyForm());
  const [saving, setSaving] = useState(false);
  const [filter, setFilter] = useState('all');

  const stats = useMemo(() => {
    return {
      total: inquiries.length,
      newC: inquiries.filter((i) => i.status === 'new').length,
      contacted: inquiries.filter((i) => i.status === 'contacted').length,
      joined: inquiries.filter((i) => i.status === 'joined').length,
    };
  }, [inquiries]);

  const filtered = useMemo(
    () =>
      filter === 'all'
        ? inquiries
        : inquiries.filter((i) => i.status === filter),
    [inquiries, filter]
  );

  const submit = async () => {
    if (!form.name.trim()) {
      alert('Name is required.');
      return;
    }
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        mobile: form.mobile.trim() || null,
        notes: form.notes.trim() || null,
        status: form.status,
        follow_up_date: form.follow_up_date || null,
      };
      if (editing) {
        const { error } = await supabase
          .from('inquiries')
          .update(payload)
          .eq('id', editing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('inquiries').insert(payload);
        if (error) throw error;
      }
      reload();
      setOpen(false);
      setForm(emptyForm());
      setEditing(null);
    } catch (e: any) {
      alert(e.message);
    } finally {
      setSaving(false);
    }
  };

  const setStatus = async (inq: Inquiry, status: Inquiry['status']) => {
    const { error } = await supabase
      .from('inquiries')
      .update({ status })
      .eq('id', inq.id);
    if (error) alert(error.message);
    else reload();
  };

  const remove = async (inq: Inquiry) => {
    if (!confirm(`Delete inquiry from ${inq.name}?`)) return;
    const { error } = await supabase.from('inquiries').delete().eq('id', inq.id);
    if (error) alert(error.message);
    else reload();
  };

  const openEdit = (i: Inquiry) => {
    setEditing(i);
    setForm({
      name: i.name,
      mobile: i.mobile ?? '',
      notes: i.notes ?? '',
      status: i.status,
      follow_up_date: i.follow_up_date ?? '',
    });
    setOpen(true);
  };

  const openNew = () => {
    setEditing(null);
    setForm(emptyForm());
    setOpen(true);
  };

  if (loading) return <Loading label="Loading inquiries…" />;

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-neutral-100">
            Inquiry Management
          </h1>
          <p className="text-sm text-neutral-500">
            Track walk-in and call inquiries.
          </p>
        </div>
        <Button variant="gold" onClick={openNew}>
          <Icon name="Plus" className="h-4 w-4" />
          New Inquiry
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <StatCard icon="PhoneCall" label="Total" value={stats.total} accent="gold" />
        <StatCard
          icon="AlertCircle"
          label="New"
          value={stats.newC}
          accent="sky"
        />
        <StatCard
          icon="Contact"
          label="Contacted"
          value={stats.contacted}
          accent="amber"
        />
        <StatCard
          icon="CheckCircle2"
          label="Joined"
          value={stats.joined}
          accent="emerald"
        />
      </div>

      <Card className="flex flex-wrap gap-2 p-3">
        {['all', 'new', 'contacted', 'joined', 'lost'].map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold capitalize transition ${
              filter === s
                ? 'bg-gold-500/20 text-gold-200 ring-1 ring-gold-500/30'
                : 'text-neutral-500 hover:bg-ink-800 hover:text-neutral-300'
            }`}
          >
            {s}
          </button>
        ))}
      </Card>

      <Card className="overflow-hidden">
        {filtered.length === 0 ? (
          <EmptyState
            icon="PhoneCall"
            title="No inquiries"
            description="Add a new inquiry to start tracking leads."
            action={
              <Button variant="outline" onClick={openNew}>
                <Icon name="Plus" className="h-4 w-4" />
                Add Inquiry
              </Button>
            }
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-ink-700 bg-ink-900/50 text-left text-xs uppercase tracking-wider text-neutral-500">
                <tr>
                  <th className="px-4 py-3 font-semibold">Name</th>
                  <th className="hidden px-4 py-3 font-semibold sm:table-cell">
                    Mobile
                  </th>
                  <th className="hidden px-4 py-3 font-semibold md:table-cell">
                    Notes
                  </th>
                  <th className="hidden px-4 py-3 font-semibold lg:table-cell">
                    Follow-up
                  </th>
                  <th className="px-4 py-3 font-semibold">Status</th>
                  <th className="px-4 py-3 text-right font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-700/50">
                {filtered.map((i) => (
                  <tr key={i.id} className="table-row-hover">
                    <td className="px-4 py-3">
                      <p className="font-semibold text-neutral-100">{i.name}</p>
                      <p className="text-xs text-neutral-500 sm:hidden">
                        {i.mobile ?? '—'}
                      </p>
                    </td>
                    <td className="hidden px-4 py-3 text-neutral-300 sm:table-cell">
                      {i.mobile ?? '—'}
                    </td>
                    <td className="hidden max-w-xs px-4 py-3 text-neutral-400 md:table-cell">
                      <p className="truncate">{i.notes ?? '—'}</p>
                    </td>
                    <td className="hidden px-4 py-3 text-neutral-400 lg:table-cell">
                      {formatDate(i.follow_up_date)}
                    </td>
                    <td className="px-4 py-3">
                      <Badge className={statusBadge(i.status)}>{i.status}</Badge>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        {i.status === 'new' && (
                          <button
                            onClick={() => setStatus(i, 'contacted')}
                            className="rounded-lg p-2 text-neutral-400 hover:bg-ink-700 hover:text-amber-300"
                            title="Mark contacted"
                          >
                            <Icon name="Contact" className="h-4 w-4" />
                          </button>
                        )}
                        {(i.status === 'new' || i.status === 'contacted') && (
                          <button
                            onClick={() => setStatus(i, 'joined')}
                            className="rounded-lg p-2 text-neutral-400 hover:bg-ink-700 hover:text-emerald-300"
                            title="Mark joined"
                          >
                            <Icon name="CheckCircle2" className="h-4 w-4" />
                          </button>
                        )}
                        <a
                          href={`https://wa.me/91${(i.mobile ?? '').replace(/\D/g, '')}`}
                          target="_blank"
                          rel="noreferrer"
                          className="rounded-lg p-2 text-neutral-400 hover:bg-ink-700 hover:text-emerald-300"
                          title="WhatsApp"
                        >
                          <Icon name="Share2" className="h-4 w-4" />
                        </a>
                        <button
                          onClick={() => openEdit(i)}
                          className="rounded-lg p-2 text-neutral-400 hover:bg-ink-700 hover:text-gold-200"
                          title="Edit"
                        >
                          <Icon name="Pencil" className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => remove(i)}
                          className="rounded-lg p-2 text-neutral-400 hover:bg-ink-700 hover:text-rose-300"
                          title="Delete"
                        >
                          <Icon name="Trash2" className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? 'Edit Inquiry' : 'New Inquiry'}
        size="md"
      >
        <div className="space-y-4">
          <div>
            <label className="label">Name *</label>
            <input
              className="input"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="Inquirer's name"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Mobile</label>
              <input
                className="input"
                value={form.mobile}
                onChange={(e) => setForm({ ...form, mobile: e.target.value })}
                placeholder="10-digit mobile"
                inputMode="numeric"
              />
            </div>
            <div>
              <label className="label">Follow-up Date</label>
              <input
                type="date"
                className="input"
                value={form.follow_up_date}
                onChange={(e) =>
                  setForm({ ...form, follow_up_date: e.target.value })
                }
              />
            </div>
          </div>
          <div>
            <label className="label">Notes</label>
            <textarea
              className="input min-h-[80px]"
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              placeholder="Interest, preferred plan, queries, etc."
            />
          </div>
          <div>
            <label className="label">Status</label>
            <select
              className="input"
              value={form.status}
              onChange={(e) =>
                setForm({ ...form, status: e.target.value as Inquiry['status'] })
              }
            >
              <option value="new">New</option>
              <option value="contacted">Contacted</option>
              <option value="joined">Joined</option>
              <option value="lost">Lost</option>
            </select>
          </div>
          <div className="flex justify-end gap-2 border-t border-ink-700 pt-4">
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button variant="gold" onClick={submit} disabled={saving}>
              {saving ? <Loading /> : <Icon name="Save" className="h-4 w-4" />}
              {editing ? 'Update' : 'Add'} Inquiry
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
