import { useMemo, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useMembers, usePayments, usePlans } from '../lib/hooks';
import {
  Card,
  Icon,
  Button,
  Loading,
  EmptyState,
  Avatar,
  Badge,
  Modal,
} from '../components/ui';
import {
  formatCurrency,
  formatDate,
  daysUntil,
  statusBadge,
  generateReceiptNo,
  todayISO,
  addMonths,
} from '../lib/utils';
import {
  openPrintWindow,
  generateReceiptHTML,
  generateAdmissionFormHTML,
  generateIDCardHTML,
  receiptWhatsAppMessage,
  renewalWhatsAppMessage,
  openWhatsApp,
} from '../lib/print';
import type { Member, Payment, Plan } from '../lib/types';
import type { Role } from '../lib/constants';

const TABS: {
  id: string;
  label: string;
  icon: string;
  filter: (m: Member) => boolean;
}[] = [
  { id: 'members', label: 'All Members', icon: 'Users', filter: () => true },
  {
    id: 'members-active',
    label: 'Active',
    icon: 'CheckCircle2',
    filter: (m) => m.status === 'active',
  },
  {
    id: 'members-expired',
    label: 'Expired',
    icon: 'AlertCircle',
    filter: (m) => m.status === 'expired',
  },
  {
    id: 'members-expiring',
    label: 'Expiring Soon',
    icon: 'Timer',
    filter: (m) => {
      if (m.status !== 'active') return false;
      const d = daysUntil(m.expiry_date);
      return d !== null && d >= 0 && d <= 7;
    },
  },
  {
    id: 'members-due',
    label: 'Due Payments',
    icon: 'Wallet',
    filter: (m) => Number(m.due_amount ?? 0) > 0,
  },
];

export function MembersPage({
  route,
  role,
  onNavigate,
}: {
  route: string;
  role: Role;
  onNavigate: (p: string) => void;
}) {
  const { members, loading, reload } = useMembers();
  const { payments } = usePayments();
  const [q, setQ] = useState('');
  const [selected, setSelected] = useState<Member | null>(null);
  const [renewing, setRenewing] = useState<Member | null>(null);
  const [deleting, setDeleting] = useState<Member | null>(null);
  const [deletingPayments, setDeletingPayments] = useState(false);
  const [activeTab, setActiveTab] = useState(
    TABS.find((t) => t.id === route)?.id ?? 'members'
  );

  const isSuperAdmin = role === 'Super Admin';

  const paymentsByMember = useMemo(() => {
    const map = new Map<string, Payment[]>();
    for (const p of payments) {
      const list = map.get(p.member_id) ?? [];
      list.push(p);
      map.set(p.member_id, list);
    }
    return map;
  }, [payments]);

  const tabCounts = useMemo(() => {
    return {
      all: members.length,
      active: members.filter((m) => m.status === 'active').length,
      expired: members.filter((m) => m.status === 'expired').length,
      expiring: members.filter((m) => {
        if (m.status !== 'active') return false;
        const d = daysUntil(m.expiry_date);
        return d !== null && d >= 0 && d <= 7;
      }).length,
      due: members.filter((m) => Number(m.due_amount ?? 0) > 0).length,
    };
  }, [members]);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    const tab = TABS.find((t) => t.id === activeTab) ?? TABS[0];
    return members.filter((m) => {
      if (!tab.filter(m)) return false;
      if (!term) return true;
      return (
        m.name?.toLowerCase().includes(term) ||
        m.mobile?.toLowerCase().includes(term) ||
        m.member_no?.toLowerCase().includes(term)
      );
    });
  }, [members, q, activeTab]);

  const switchTab = (tabId: string) => {
    setActiveTab(tabId);
    onNavigate(tabId);
  };

  const confirmDelete = async () => {
    if (!deleting) return;
    setDeletingPayments(true);
    const { error } = await supabase.from('members').delete().eq('id', deleting.id);
    setDeletingPayments(false);
    if (error) {
      alert(error.message);
      return;
    }
    setDeleting(null);
    reload();
    if (selected) setSelected(null);
  };

  if (loading) return <Loading label="Loading members…" />;

  const currentTab = TABS.find((t) => t.id === activeTab) ?? TABS[0];

  const tabCountMap: Record<string, number> = {
    members: tabCounts.all,
    'members-active': tabCounts.active,
    'members-expired': tabCounts.expired,
    'members-expiring': tabCounts.expiring,
    'members-due': tabCounts.due,
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-neutral-100">
            Member Management
          </h1>
          <p className="text-sm text-neutral-500">
            {filtered.length} {currentTab.label.toLowerCase()} shown ·{' '}
            {members.length} total members
          </p>
        </div>
        <Button variant="gold" onClick={() => onNavigate('admission')}>
          <Icon name="UserPlus" className="h-4 w-4" />
          New Admission
        </Button>
      </div>

      {/* Tabs */}
      <Card className="flex flex-wrap gap-1.5 p-2">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => switchTab(tab.id)}
            className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold transition ${
              activeTab === tab.id
                ? 'bg-gold-500/20 text-gold-200 ring-1 ring-gold-500/30'
                : 'text-neutral-500 hover:bg-ink-800 hover:text-neutral-300'
            }`}
          >
            <Icon name={tab.icon as any} className="h-4 w-4" />
            {tab.label}
            <span
              className={`rounded-full px-1.5 py-0.5 text-[10px] font-bold ${
                activeTab === tab.id
                  ? 'bg-gold-500/30 text-gold-100'
                  : 'bg-ink-700 text-neutral-400'
              }`}
            >
              {tabCountMap[tab.id]}
            </span>
          </button>
        ))}
      </Card>

      {/* Search */}
      <Card className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Icon
            name="Search"
            className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-500"
          />
          <input
            className="input pl-10"
            placeholder="Search by name, mobile number, or member ID…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
      </Card>

      <Card className="overflow-hidden">
        {filtered.length === 0 ? (
          <EmptyState
            icon="Users"
            title="No members found"
            description={
              q ? 'Try a different search term.' : 'No members match this filter.'
            }
            action={
              !q && (
                <Button
                  variant="outline"
                  onClick={() => onNavigate('admission')}
                >
                  <Icon name="UserPlus" className="h-4 w-4" />
                  Add Member
                </Button>
              )
            }
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-ink-700 bg-ink-900/50 text-left text-xs uppercase tracking-wider text-neutral-500">
                <tr>
                  <th className="px-4 py-3 font-semibold">Member</th>
                  <th className="hidden px-4 py-3 font-semibold sm:table-cell">
                    Contact
                  </th>
                  <th className="hidden px-4 py-3 font-semibold md:table-cell">
                    Plan
                  </th>
                  <th className="hidden px-4 py-3 font-semibold lg:table-cell">
                    Expiry
                  </th>
                  <th className="px-4 py-3 font-semibold">Status</th>
                  <th className="px-4 py-3 text-right font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-700/50">
                {filtered.map((m) => {
                  const d = daysUntil(m.expiry_date);
                  const due = Number(m.due_amount ?? 0);
                  return (
                    <tr key={m.id} className="table-row-hover">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <Avatar photo={m.photo} name={m.name} size="sm" />
                          <div className="min-w-0">
                            <p className="truncate font-semibold text-neutral-100">
                              {m.name}
                            </p>
                            <p className="text-xs text-neutral-500">
                              {m.member_no}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="hidden px-4 py-3 text-neutral-300 sm:table-cell">
                        {m.mobile ?? '—'}
                      </td>
                      <td className="hidden px-4 py-3 text-neutral-300 md:table-cell">
                        {m.category} {m.duration_months}M
                      </td>
                      <td className="hidden px-4 py-3 lg:table-cell">
                        <p className="text-neutral-300">
                          {formatDate(m.expiry_date)}
                        </p>
                        {d !== null && d >= 0 && d <= 7 && m.status === 'active' && (
                          <p className="text-[11px] text-amber-400">
                            expires in {d}d
                          </p>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <Badge className={statusBadge(m.status)}>
                          {m.status}
                        </Badge>
                        {due > 0 && (
                          <Badge className="mt-1 border border-rose-500/30 bg-rose-500/15 text-rose-300">
                            due {formatCurrency(due)}
                          </Badge>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex justify-end gap-1">
                          <button
                            onClick={() =>
                              onNavigate(`member-profile?id=${m.id}`)
                            }
                            className="rounded-lg p-2 text-neutral-400 hover:bg-ink-700 hover:text-gold-200"
                            title="View Profile"
                          >
                            <Icon name="Eye" className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => setRenewing(m)}
                            className="rounded-lg p-2 text-neutral-400 hover:bg-ink-700 hover:text-emerald-300"
                            title="Renew"
                          >
                            <Icon name="RefreshCw" className="h-4 w-4" />
                          </button>
                          {isSuperAdmin && (
                            <button
                              onClick={() => setDeleting(m)}
                              className="rounded-lg p-2 text-neutral-400 hover:bg-ink-700 hover:text-rose-300"
                              title="Delete (Super Admin only)"
                            >
                              <Icon name="Trash2" className="h-4 w-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {selected && (
        <MemberDetailDrawer
          member={selected}
          payments={paymentsByMember.get(selected.id) ?? []}
          onClose={() => setSelected(null)}
          onChanged={reload}
        />
      )}

      {renewing && (
        <RenewalModal
          member={renewing}
          onClose={() => setRenewing(null)}
          onDone={() => {
            setRenewing(null);
            reload();
          }}
        />
      )}

      {deleting && (
        <Modal
          open
          onClose={() => setDeleting(null)}
          title="Delete Member"
          size="sm"
        >
          <div className="space-y-4">
            <div className="flex flex-col items-center gap-3 py-2 text-center">
              <div className="rounded-full bg-rose-500/15 p-3 text-rose-300">
                <Icon name="Trash2" className="h-8 w-8" />
              </div>
              <p className="text-sm text-neutral-300">
                Are you sure you want to permanently delete{' '}
                <span className="font-bold text-neutral-100">
                  {deleting.name}
                </span>{' '}
                ({deleting.member_no})?
              </p>
              <p className="text-xs text-neutral-500">
                This will also remove all payment records for this member. This
                action cannot be undone.
              </p>
            </div>
            <div className="rounded-lg border border-gold-500/20 bg-gold-500/5 px-3 py-2 text-center text-[11px] text-gold-200">
              <Icon name="Crown" className="mr-1 inline h-3.5 w-3.5" />
              Super Admin authorization required for deletion.
            </div>
            <div className="flex justify-end gap-2 border-t border-ink-700 pt-4">
              <Button variant="ghost" onClick={() => setDeleting(null)}>
                Cancel
              </Button>
              <Button
                variant="danger"
                onClick={confirmDelete}
                disabled={deletingPayments}
              >
                {deletingPayments ? (
                  <Loading />
                ) : (
                  <Icon name="Trash2" className="h-4 w-4" />
                )}
                Delete Permanently
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

function MemberDetailDrawer({
  member,
  payments,
  onClose,
  onChanged,
}: {
  member: Member;
  payments: Payment[];
  onClose: () => void;
  onChanged: () => void;
}) {
  const [editing, setEditing] = useState(false);

  return (
    <Modal
      open
      onClose={onClose}
      title={editing ? 'Edit Member' : 'Member Details'}
      size="lg"
    >
      {editing ? (
        <EditForm
          member={member}
          onCancel={() => setEditing(false)}
          onSaved={() => {
            setEditing(false);
            onChanged();
          }}
        />
      ) : (
        <div className="space-y-5">
          <div className="flex flex-col gap-4 sm:flex-row">
            <Avatar photo={member.photo} name={member.name} size="lg" />
            <div className="flex-1">
              <h3 className="font-display text-xl font-bold text-neutral-100">
                {member.name}
              </h3>
              <p className="text-sm text-neutral-500">{member.member_no}</p>
              <div className="mt-2 flex flex-wrap gap-2">
                <Badge className={statusBadge(member.status)}>
                  {member.status}
                </Badge>
                {Number(member.due_amount ?? 0) > 0 && (
                  <Badge className="border border-rose-500/30 bg-rose-500/15 text-rose-300">
                    Due {formatCurrency(member.due_amount)}
                  </Badge>
                )}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-x-6 gap-y-3 rounded-xl border border-ink-700 bg-ink-900/40 p-4 sm:grid-cols-2">
            <Info label="Father" value={member.father_name} />
            <Info label="Gender" value={member.gender} />
            <Info label="Date of Birth" value={formatDate(member.date_of_birth)} />
            <Info label="Mobile" value={member.mobile} />
            <Info label="Emergency Contact" value={member.emergency_contact} />
            <Info label="Address" value={member.address} full />
          </div>

          <div className="grid grid-cols-1 gap-x-6 gap-y-3 rounded-xl border border-ink-700 bg-ink-900/40 p-4 sm:grid-cols-2">
            <Info
              label="Plan"
              value={`${member.category} · ${member.duration_months}M`}
            />
            <Info label="Plan Price" value={formatCurrency(member.plan_price)} />
            <Info
              label="Registration Fee"
              value={formatCurrency(member.registration_fee)}
            />
            <Info label="Start Date" value={formatDate(member.start_date)} />
            <Info label="Expiry Date" value={formatDate(member.expiry_date)} />
            <Info
              label="Medical Condition"
              value={member.medical_condition || 'None'}
            />
            <Info
              label="Cardio Notes"
              value={member.cardio_notes || 'None'}
              full
            />
          </div>

          <div>
            <h4 className="mb-2 text-xs font-bold uppercase tracking-wider text-neutral-500">
              Payment History ({payments.length})
            </h4>
            {payments.length === 0 ? (
              <p className="rounded-lg bg-ink-900/40 px-4 py-3 text-sm text-neutral-500">
                No payments recorded.
              </p>
            ) : (
              <div className="max-h-48 divide-y divide-ink-700/50 overflow-y-auto rounded-lg border border-ink-700">
                {payments.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center justify-between px-4 py-2.5 text-sm"
                  >
                    <div>
                      <p className="font-mono text-xs text-gold-300">
                        {p.receipt_no}
                      </p>
                      <p className="text-xs text-neutral-500">
                        {formatDate(p.paid_date)} · {p.type}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-neutral-200">
                        {formatCurrency(p.amount)}
                      </p>
                      <button
                        onClick={() =>
                          openPrintWindow(generateReceiptHTML(p, member, {}))
                        }
                        className="text-[11px] font-semibold text-gold-300 hover:text-gold-200"
                      >
                        View receipt →
                      </button>
                      <button
                        onClick={() =>
                          openWhatsApp(
                            member.mobile,
                            p.type === 'renewal'
                              ? renewalWhatsAppMessage(p, member)
                              : receiptWhatsAppMessage(p, member)
                          )
                        }
                        className="ml-2 text-[11px] font-semibold text-emerald-300 hover:text-emerald-200"
                      >
                        WhatsApp →
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex flex-wrap gap-2 border-t border-ink-700 pt-4">
            <Button
              variant="gold"
              onClick={() => openPrintWindow(generateIDCardHTML(member))}
            >
              <Icon name="BadgeCheck" className="h-4 w-4" />
              Membership Card
            </Button>
            <Button
              variant="outline"
              onClick={() =>
                openPrintWindow(generateAdmissionFormHTML(member, {}))
              }
            >
              <Icon name="FileText" className="h-4 w-4" />
              Admission Form
            </Button>
            <Button variant="outline" onClick={() => setEditing(true)}>
              <Icon name="Pencil" className="h-4 w-4" />
              Edit
            </Button>
          </div>
        </div>
      )}
    </Modal>
  );
}

function Info({
  label,
  value,
  full,
}: {
  label: string;
  value: string | null | undefined;
  full?: boolean;
}) {
  return (
    <div className={full ? 'sm:col-span-2' : ''}>
      <p className="text-[11px] uppercase tracking-wider text-neutral-500">
        {label}
      </p>
      <p className="mt-0.5 text-sm font-medium text-neutral-200">
        {value || '—'}
      </p>
    </div>
  );
}

function EditForm({
  member,
  onCancel,
  onSaved,
}: {
  member: Member;
  onCancel: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState({
    name: member.name ?? '',
    father_name: member.father_name ?? '',
    gender: member.gender ?? 'Male',
    date_of_birth: member.date_of_birth ?? '',
    mobile: member.mobile ?? '',
    address: member.address ?? '',
    emergency_contact: member.emergency_contact ?? '',
    medical_condition: member.medical_condition ?? '',
    cardio_notes: member.cardio_notes ?? '',
    status: member.status ?? 'active',
  });
  const [saving, setSaving] = useState(false);
  const set = (k: string, v: any) => setForm((f) => ({ ...f, [k]: v }));

  const save = async () => {
    setSaving(true);
    const { error } = await supabase
      .from('members')
      .update({ ...form, updated_at: new Date().toISOString() })
      .eq('id', member.id);
    setSaving(false);
    if (error) {
      alert(error.message);
      return;
    }
    onSaved();
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <EditField
          label="Name"
          value={form.name}
          onChange={(v) => set('name', v)}
        />
        <EditField
          label="Father Name"
          value={form.father_name}
          onChange={(v) => set('father_name', v)}
        />
        <div>
          <label className="label">Gender</label>
          <select
            className="input"
            value={form.gender}
            onChange={(e) => set('gender', e.target.value)}
          >
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
        </div>
        <div>
          <label className="label">Date of Birth</label>
          <input
            type="date"
            className="input"
            value={form.date_of_birth}
            onChange={(e) => set('date_of_birth', e.target.value)}
          />
        </div>
        <EditField
          label="Mobile"
          value={form.mobile}
          onChange={(v) => set('mobile', v)}
        />
        <EditField
          label="Emergency Contact"
          value={form.emergency_contact}
          onChange={(v) => set('emergency_contact', v)}
        />
        <div className="sm:col-span-2">
          <label className="label">Address</label>
          <textarea
            className="input min-h-[50px]"
            value={form.address}
            onChange={(e) => set('address', e.target.value)}
          />
        </div>
        <div className="sm:col-span-2">
          <label className="label">Medical Condition</label>
          <textarea
            className="input min-h-[50px]"
            value={form.medical_condition}
            onChange={(e) => set('medical_condition', e.target.value)}
          />
        </div>
        <div className="sm:col-span-2">
          <label className="label">Cardio Notes</label>
          <textarea
            className="input min-h-[50px]"
            value={form.cardio_notes}
            onChange={(e) => set('cardio_notes', e.target.value)}
          />
        </div>
        <div>
          <label className="label">Status</label>
          <select
            className="input"
            value={form.status}
            onChange={(e) => set('status', e.target.value)}
          >
            <option value="active">Active</option>
            <option value="expired">Expired</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div className="flex justify-end gap-2 border-t border-ink-700 pt-4">
        <Button variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
        <Button
          variant="gold"
          onClick={save}
          disabled={saving || !form.name.trim()}
        >
          {saving ? <Loading /> : <Icon name="Save" className="h-4 w-4" />}
          Save Changes
        </Button>
      </div>
    </div>
  );
}

function EditField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div>
      <label className="label">{label}</label>
      <input
        className="input"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}

function RenewalModal({
  member,
  onClose,
  onDone,
}: {
  member: Member;
  onClose: () => void;
  onDone: () => void;
}) {
  const { plans } = usePlans();
  const [planId, setPlanId] = useState(member.plan_id ?? '');
  const [method, setMethod] = useState('Cash');
  const [startDate, setStartDate] = useState(
    member.expiry_date && daysUntil(member.expiry_date)! >= 0
      ? member.expiry_date
      : todayISO()
  );
  const [amountPaid, setAmountPaid] = useState<string>(
    String(plans.find((p) => p.id === member.plan_id)?.price ?? '')
  );
  const [saving, setSaving] = useState(false);

  const plan = plans.find((p) => p.id === planId) as Plan | undefined;

  const expiry = plan ? addMonths(startDate, plan.duration_months) : '';
  const paid = Number(amountPaid || 0);
  const due = Math.max(0, (plan?.price ?? 0) - paid);

  const save = async () => {
    if (!plan || paid <= 0) return;
    setSaving(true);
    try {
      const receiptNo = await generateReceiptNo();
      const { error: payErr } = await supabase.from('payments').insert({
        member_id: member.id,
        receipt_no: receiptNo,
        type: 'renewal',
        amount: paid,
        due_amount: Math.max(0, Number(plan.price) - paid),
        method,
        received_by: 'Admin',
        note: `${plan.category} ${plan.duration_months}M renewal`,
        paid_date: new Date().toISOString(),
        new_start_date: startDate,
        new_expiry_date: expiry,
      });
      if (payErr) throw payErr;

      const { error: memErr } = await supabase
        .from('members')
        .update({
          plan_id: plan.id,
          category: plan.category,
          duration_months: plan.duration_months,
          plan_price: plan.price,
          start_date: startDate,
          expiry_date: expiry,
          status: 'active',
          due_amount: due,
          updated_at: new Date().toISOString(),
        })
        .eq('id', member.id);
      if (memErr) throw memErr;

      const updatedMember: Member = {
        ...member,
        plan_id: plan.id,
        category: plan.category,
        duration_months: plan.duration_months,
        plan_price: plan.price,
        start_date: startDate,
        expiry_date: expiry,
        status: 'active',
        due_amount: due,
      };
      const lastPay: Payment = {
        id: '',
        member_id: member.id,
        receipt_no: receiptNo,
        type: 'renewal',
        amount: paid,
        due_amount: Math.max(0, Number(plan.price) - paid),
        method,
        received_by: 'Admin',
        note: `${plan.category} ${plan.duration_months}M renewal`,
        paid_date: new Date().toISOString(),
        new_start_date: startDate,
        new_expiry_date: expiry,
        created_at: new Date().toISOString(),
      };
      openPrintWindow(generateReceiptHTML(lastPay, updatedMember, {}));
      openWhatsApp(updatedMember.mobile, renewalWhatsAppMessage(lastPay, updatedMember));
      onDone();
    } catch (e: any) {
      alert(e.message || 'Renewal failed.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal open onClose={onClose} title={`Renew ${member.name}`} size="md">
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-3 rounded-xl border border-ink-700 bg-ink-900/40 p-3 text-sm">
          <Info label="Member No" value={member.member_no} />
          <Info label="Current Expiry" value={formatDate(member.expiry_date)} />
        </div>

        <div>
          <label className="label">Select Plan</label>
          <select
            className="input"
            value={planId}
            onChange={(e) => setPlanId(e.target.value)}
          >
            <option value="">— Choose Plan —</option>
            {plans
              .filter((p) => p.is_active)
              .map((p) => (
                <option key={p.id} value={p.id}>
                  {p.category} · {p.label} — {formatCurrency(p.price)}
                </option>
              ))}
          </select>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Start Date</label>
            <input
              type="date"
              className="input"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
            />
          </div>
          <div>
            <label className="label">New Expiry</label>
            <input className="input bg-ink-800" value={expiry} readOnly />
          </div>
          <div>
            <label className="label">Amount Paid</label>
            <input
              type="number"
              className="input"
              value={amountPaid}
              onChange={(e) => setAmountPaid(e.target.value)}
            />
          </div>
          <div>
            <label className="label">Payment Method</label>
            <select
              className="input"
              value={method}
              onChange={(e) => setMethod(e.target.value)}
            >
              <option value="Cash">Cash</option>
              <option value="UPI">UPI</option>
              <option value="Card">Card</option>
              <option value="Bank Transfer">Bank Transfer</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between rounded-xl border border-gold-500/30 bg-gold-500/5 px-4 py-3 text-sm">
          <div>
            <p className="text-xs text-neutral-500">Plan Price</p>
            <p className="font-bold gold-text">
              {formatCurrency(plan?.price ?? 0)}
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs text-neutral-500">Due</p>
            <p
              className={`font-bold ${
                due > 0 ? 'text-rose-300' : 'text-emerald-300'
              }`}
            >
              {formatCurrency(due)}
            </p>
          </div>
        </div>

        <div className="flex justify-end gap-2 border-t border-ink-700 pt-4">
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant="gold"
            onClick={save}
            disabled={saving || !planId || paid <= 0}
          >
            {saving ? <Loading /> : <Icon name="RefreshCw" className="h-4 w-4" />}
            Renew & Generate Receipt
          </Button>
        </div>
      </div>
    </Modal>
  );
}
