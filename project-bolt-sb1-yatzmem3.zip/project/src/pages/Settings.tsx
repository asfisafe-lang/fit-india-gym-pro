import { useMemo, useState } from 'react';
import { supabase } from '../lib/supabase';
import { usePlans, useSettings } from '../lib/hooks';
import { Card, Icon, Button, Loading } from '../components/ui';
import { formatCurrency, upsertSetting } from '../lib/utils';
import { GYM } from '../lib/constants';
import type { Plan } from '../lib/types';

export function SettingsPage() {
  const { plans, loading, reload } = usePlans();
  const { settings, reload: reloadSettings } = useSettings();
  const [regFee, setRegFee] = useState(String(settings?.registration_fee ?? '500'));
  const [savingFee, setSavingFee] = useState(false);
  const [editingPlan, setEditingPlan] = useState<string | null>(null);
  const [planPrices, setPlanPrices] = useState<Record<string, string>>({});

  const organized = useMemo(() => {
    const cats: Record<string, Plan[]> = { 'Boys/Unisex': [], 'Only Ladies': [] };
    for (const p of plans) {
      if (!cats[p.category]) cats[p.category] = [];
      cats[p.category].push(p);
    }
    return cats;
  }, [plans]);

  const saveRegFee = async () => {
    setSavingFee(true);
    try {
      await upsertSetting('registration_fee', regFee.trim() || '500');
      reloadSettings();
      setSavingFee(false);
    } catch (e: any) {
      alert(e.message);
      setSavingFee(false);
    }
  };

  const savePlanPrice = async (plan: Plan) => {
    const val = planPrices[plan.id];
    if (val === undefined) return;
    const price = Number(val);
    if (isNaN(price) || price < 0) {
      alert('Enter a valid price.');
      return;
    }
    const { error } = await supabase
      .from('plans')
      .update({ price })
      .eq('id', plan.id);
    if (error) {
      alert(error.message);
      return;
    }
    setEditingPlan(null);
    setPlanPrices((p) => {
      const copy = { ...p };
      delete copy[plan.id];
      return copy;
    });
    reload();
  };

  const togglePlanActive = async (plan: Plan) => {
    const { error } = await supabase
      .from('plans')
      .update({ is_active: !plan.is_active })
      .eq('id', plan.id);
    if (error) alert(error.message);
    else reload();
  };

  if (loading) return <Loading label="Loading settings…" />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-neutral-100">
          Settings
        </h1>
        <p className="text-sm text-neutral-500">
          Manage membership plans, registration fees, and gym details.
        </p>
      </div>

      {/* Gym details */}
      <Card className="p-5">
        <h3 className="mb-4 font-display text-base font-semibold gold-text">
          Gym Details
        </h3>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Detail icon="User" label="Owner" value={GYM.owner} />
          <Detail icon="Shield" label="Managed By" value={GYM.managedBy} />
          <Detail icon="Phone" label="Mobile" value={GYM.mobiles.join(' · ')} />
          <Detail
            icon="MapPin"
            label="Address"
            value={GYM.address}
            full
          />
          <Detail icon="Clock" label="Gym Timing" value={GYM.gymTiming} />
          <Detail
            icon="Users"
            label="Ladies Only Timing"
            value={GYM.ladiesTiming}
          />
        </div>
      </Card>

      {/* Registration fee */}
      <Card className="p-5">
        <h3 className="mb-4 font-display text-base font-semibold gold-text">
          Registration Fee
        </h3>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <div className="flex-1">
            <label className="label">Registration Fee Amount (₹)</label>
            <input
              type="number"
              className="input"
              value={regFee}
              onChange={(e) => setRegFee(e.target.value)}
              min="0"
            />
          </div>
          <Button
            variant="gold"
            onClick={saveRegFee}
            disabled={savingFee || regFee === (settings?.registration_fee ?? '500')}
          >
            {savingFee ? <Loading /> : <Icon name="Save" className="h-4 w-4" />}
            Save Fee
          </Button>
        </div>
        <p className="mt-2 text-xs text-neutral-500">
          Current fee:{' '}
          <span className="font-semibold text-gold-300">
            {formatCurrency(Number(settings?.registration_fee ?? 500))}
          </span>{' '}
          · Applied to all new admissions
        </p>
      </Card>

      {/* Plans */}
      <div className="space-y-5">
        <div>
          <h3 className="font-display text-base font-semibold gold-text">
            Membership Plans
          </h3>
          <p className="text-sm text-neutral-500">
            Edit plan prices and toggle active status.
          </p>
        </div>

        {Object.entries(organized).map(([cat, catPlans]) => (
          <Card key={cat} className="overflow-hidden">
            <div className="border-b border-ink-700 bg-ink-900/40 px-5 py-3">
              <h4 className="text-sm font-bold text-neutral-200">
                {cat}
                <span className="ml-2 text-xs font-normal text-neutral-500">
                  ({catPlans.length} plans)
                </span>
              </h4>
            </div>
            <div className="divide-y divide-ink-700/50">
              {catPlans.map((p) => (
                <div
                  key={p.id}
                  className="flex flex-col gap-3 px-5 py-3 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div>
                    <p className="font-semibold text-neutral-200">
                      {p.label}
                      <span className="ml-2 text-xs text-neutral-500">
                        ({p.duration_months} months)
                      </span>
                    </p>
                    <p className="text-xs text-neutral-500">
                      Current: {formatCurrency(p.price)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      className={`px-3 py-1.5 text-xs ${
                        p.is_active
                          ? 'text-emerald-300'
                          : 'text-neutral-500'
                      }`}
                      onClick={() => togglePlanActive(p)}
                    >
                      <Icon
                        name={p.is_active ? 'CheckCircle2' : 'XCircle'}
                        className="h-3.5 w-3.5"
                      />
                      {p.is_active ? 'Active' : 'Inactive'}
                    </Button>
                    {editingPlan === p.id ? (
                      <div className="flex items-center gap-2">
                        <div className="relative">
                          <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-xs text-neutral-500">
                            ₹
                          </span>
                          <input
                            type="number"
                            className="input w-28 py-1.5 pl-7 text-sm"
                            value={planPrices[p.id] ?? String(p.price)}
                            onChange={(e) =>
                              setPlanPrices((prev) => ({
                                ...prev,
                                [p.id]: e.target.value,
                              }))
                            }
                          />
                        </div>
                        <Button
                          variant="gold"
                          className="px-2 py-1.5 text-xs"
                          onClick={() => savePlanPrice(p)}
                        >
                          <Icon name="Check" className="h-3.5 w-3.5" />
                          Save
                        </Button>
                        <Button
                          variant="ghost"
                          className="px-2 py-1.5 text-xs"
                          onClick={() => {
                            setEditingPlan(null);
                            setPlanPrices((prev) => {
                              const c = { ...prev };
                              delete c[p.id];
                              return c;
                            });
                          }}
                        >
                          <Icon name="X" className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    ) : (
                      <Button
                        variant="outline"
                        className="px-3 py-1.5 text-xs"
                        onClick={() => {
                          setEditingPlan(p.id);
                          setPlanPrices((prev) => ({
                            ...prev,
                            [p.id]: String(p.price),
                          }));
                        }}
                      >
                        <Icon name="Pencil" className="h-3.5 w-3.5" />
                        Edit Price
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>

      <Card className="border-gold-500/20 p-5">
        <h3 className="mb-2 font-display text-sm font-semibold gold-text">
          Pricing Summary
        </h3>
        <div className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
          {plans.map((p) => (
            <div
              key={p.id}
              className="rounded-xl border border-ink-700 bg-ink-900/40 p-3"
            >
              <p className="text-[10px] uppercase tracking-wider text-neutral-500">
                {p.category}
              </p>
              <p className="font-semibold text-neutral-200">{p.label}</p>
              <p className="mt-1 font-bold gold-text">
                {formatCurrency(p.price)}
              </p>
              <p className="text-[10px] text-neutral-600">
                Reg: {formatCurrency(Number(settings?.registration_fee ?? 500))}
              </p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function Detail({
  icon,
  label,
  value,
  full,
}: {
  icon: string;
  label: string;
  value: string;
  full?: boolean;
}) {
  return (
    <div
      className={`flex items-start gap-3 rounded-xl border border-ink-700 bg-ink-900/40 p-3 ${
        full ? 'sm:col-span-2' : ''
      }`}
    >
      <div className="rounded-lg bg-gold-500/10 p-2 text-gold-300">
        <Icon name={icon as any} className="h-4 w-4" />
      </div>
      <div className="min-w-0">
        <p className="text-[11px] uppercase tracking-wider text-neutral-500">
          {label}
        </p>
        <p className="mt-0.5 text-sm font-medium text-neutral-200">{value}</p>
      </div>
    </div>
  );
}
