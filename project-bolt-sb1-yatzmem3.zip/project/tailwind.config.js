/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        gold: {
          50: '#fbf6e7',
          100: '#f7ecc6',
          200: '#efd98a',
          300: '#e7c454',
          400: '#d9a83a',
          500: '#c8902a',
          600: '#a9731f',
          700: '#7e551b',
          800: '#533a14',
          900: '#2e200b',
        },
        ink: {
          950: '#0a0a0b',
          900: '#101012',
          850: '#161618',
          800: '#1c1c1f',
          700: '#262629',
          600: '#303035',
          500: '#3d3d44',
          400: '#5a5a62',
        },
      },
      fontFamily: {
        display: ['Cinzel', 'serif'],
        sans: ['Plus Jakarta Sans', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        gold: '0 0 0 1px rgba(201,144,42,0.4), 0 8px 30px rgba(201,144,42,0.15)',
        'gold-glow': '0 0 25px rgba(231,196,84,0.35)',
      },
    },
  },
  plugins: [],
};
