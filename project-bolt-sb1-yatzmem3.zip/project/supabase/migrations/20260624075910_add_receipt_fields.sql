ALTER TABLE payments
  ADD COLUMN IF NOT EXISTS due_amount numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS received_by text DEFAULT 'Admin';
